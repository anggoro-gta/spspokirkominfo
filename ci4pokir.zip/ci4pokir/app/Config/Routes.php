<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
// $routes->get('/', 'Home::index');
// $routes->get('/utama', 'Home::utama', ['filter'=>'role:admin']);

//Routes copy an dari file lain
// We get a performance increase by specifying the default
// route since we don't have to scan directories.
$routes->get('/', 'Home::index');
$routes->get('/gantipassword', 'Home::gantipassword');
$routes->get('/home/updatepassword', 'Home::updatepassword');

//YEARS PICK
$routes->post('/home/saveyears', 'Home::saveyears');

//REAL INDEX AFTER CHOOSE YEARS
$routes->get('/home/realindex', 'Home::realindex');

//salah satu menu admin untuk rekap user
$routes->get('/home/rekapuser', 'Home::rekapuser');

//routes untuk api get grafik
$routes->post('/home/apitahungrafikdata', 'Home::apitahungrafikdata');

//CALCULATOR POKIR
$routes->get('/rekapskpd', 'Calculatorskpd::index', ['filter' => 'role:admin']);
$routes->get('/rekapdprd', 'Calculatordprd::index', ['filter' => 'role:admin']);
$routes->get('/rekapusulandprd', 'Calculatordprd::rekapusulandprd', ['filter' => 'role:admin']);
$routes->get('/stringtonumb', 'Stringtonumb::index', ['filter' => 'role:admin']);
$routes->get('/bkkkediri', 'Bkkkediri::index', ['filter' => 'role:admin']);
$routes->get('/calculatorskpd/detailskpd/(:any)', 'Calculatorskpd::detailskpd/$1', ['filter' => 'role:admin']);
$routes->get('/calculatorskpd/(:any)', 'Calculatorskpd::cetakperskpd/$1', ['filter' => 'role:admin']);
$routes->get('/calculatordprd/detaildprd/(:any)', 'Calculatordprd::detaildprd/$1', ['filter' => 'role:admin']);
// $routes->get('/calculatordprd/printexceldprd/(:any)', 'Calculatordprd::printexceldprd/$1', ['filter' => 'role:admin']);
$routes->get('/calculatordprd/(:any)', 'Calculatordprd::cetakperdprd/$1', ['filter' => 'role:admin']);
$routes->get('/cetakmusrenprov', 'Cetakmusrenprov::index', ['filter' => 'role:admin']);
$routes->get('/cetakmusrennas', 'Cetakmusrennas::index', ['filter' => 'role:admin']);
$routes->get('/rkpdsubsumber', 'Rkpdsubsumber::index', ['filter' => 'role:admin']);
$routes->get('/rkpdsubsumber/detailskpd/(:any)', 'Rkpdsubsumber::detailskpd/$1', ['filter' => 'role:admin']);
$routes->get('/programrpjmd', 'Programrpjmd::index', ['filter' => 'role:admin']);
$routes->get('/apbdprogkeg', 'Progkegapbd::index', ['filter' => 'role:admin']);
$routes->get('/programduaribuduaempat', 'Programduaempat::index', ['filter' => 'role:admin']);

//role user DPRD
$routes->get('/userdprd', 'Userdprd::index', ['filter' => 'role:user-dprd']);
$routes->get('/userdprd/cetakindex', 'Userdprd::cetakindex', ['filter' => 'role:user-dprd']);
$routes->get('/userdprd/cetakusulan/(:any)', 'Userdprd::cetakusulan/$1', ['filter' => 'role:user-dprd']);
$routes->get('/userdprd/saveeditusulan', 'Userdprd::saveeditusulan', ['filter' => 'role:user-dprd']);
$routes->get('/userdprd/addusulandprd', 'Userdprd::addusulandprd', ['filter' => 'role:user-dprd']);
$routes->get('/userdprd/saveaddusulan', 'Userdprd::saveaddusulan', ['filter' => 'role:user-dprd']);
$routes->get('/userdprd/hapususulan', 'Userdprd::hapususulan', ['filter' => 'role:user-dprd']);

//role user SKPD
$routes->get('/userskpd', 'Userskpd::index', ['filter' => 'role:user-skpd']);
$routes->get('/userskpd/cetakskpd/(:any)', 'Userskpd::cetakskpd/$1', ['filter' => 'role:user-skpd']);
$routes->post('/userskpd/saveeditskpd', 'Userskpd::saveeditskpd', ['filter' => 'role:user-skpd']);
$routes->post('/userskpd/saveeditskpdstatususulan', 'Userskpd::saveeditskpdstatususulan', ['filter' => 'role:user-skpd']);
$routes->get('/userskpd/indexcetakskpd', 'Userskpd::indexcetakskpd', ['filter' => 'role:user-skpd']);
$routes->get('/userskpd/apigetstatususulan', 'Userskpd::apigetstatususulan', ['filter' => 'role:user-skpd']);
$routes->post('/userskpd/apigetusulan', 'Userskpd::apigetusulan', ['filter' => 'role:user-skpd']);
$routes->post('/userskpd/apigetusulanstatus', 'Userskpd::apigetusulanstatus', ['filter' => 'role:user-skpd']);

//Menu Admin additional P-RKPD 2024
$routes->get('/prkpd', 'Prkpd::index', ['filter' => 'role:admin']);
$routes->get('/prkpd/print/(:any)', 'Prkpd::print/$1', ['filter' => 'role:admin']);