<?php

namespace App\Controllers;

use Myth\Auth\Password;
use App\Models\usersModel;
use App\Models\tabelpokirModel;

class Home extends BaseController
{
    protected $usersModel;
    protected $sumtahun;

    public function __construct()
    {
        $this->usersModel = new usersModel();
        $this->sumtahun = new tabelpokirModel();
    }

    public function index()
    {
        $session = \Config\Services::session();

        if (isset($_SESSION['years'])) {
            return redirect()->to('/home/realindex');
        } else {
            $data = [
                'tittle' => 'Pilih Tahun'
            ];

            return view('years/yearsview', $data);
        }
    }

    public function saveyears()
    {
        if (isset($_SESSION['years'])) {
            return redirect()->to('/home/realindex');
        } else {
            $session = \Config\Services::session();
            $get_years = $this->request->getVar('inputStatus');

            $newdata = [
                'years'  => $get_years,
                'ok' => 'coba coba'
            ];

            $session->set($newdata);

            return redirect()->to('/home/realindex');
        }
    }

    public function realindex()
    {
        $session = \Config\Services::session();

        if (isset($_SESSION['years'])) {
            $data = [
                'tittle' => 'Home'
            ];

            return view('pages/homenew', $data);
        } else {
            $data = [
                'tittle' => 'Pilih Tahun'
            ];

            return view('years/yearsview', $data);
        }
    }

    public function register()
    {
        $data = [
            'tittle' => 'Register'
        ];

        return view('auth/registerview', $data);
    }

    public function gantipassword()
    {
        if (isset($_SESSION['years'])) {
            // session();
            // $session = \Config\Services::session();
            $data = [
                'tittle' => 'Ganti Password',
                'validation' => \Config\Services::validation(),
            ];

            return view('pages/gantipassword_view', $data);
        } else {
            return redirect()->to('/');
        }
    }

    public function updatepassword()
    {
        date_default_timezone_set('Asia/Jakarta');
        // $kode_user_skpd = user()->kode_user;
        $id_user = user()->id;

        // validation data update
        if (!$this->validate([
            'password1' => [
                'rules' => 'required|min_length[3]|matches[password2]',
                'errors' => [
                    'required' => 'harus ada isinya',
                    'min_length' => 'telalu pendek tidak boleh kurang dari 3 karakter',
                    'matches' => 'tidak cocok dengan password ke dua'
                ]
            ],
            'password2' => [
                'rules' => 'required|min_length[3]|matches[password1]',
                'errors' => [
                    'required' => 'harus ada isinya',
                    'min_length' => 'telalu pendek tidak boleh kurang dari 3 karakter',
                    'matches' => 'tidak cocok dengan password ke satu'
                ]
            ]
        ])) {
            return redirect()->to('gantipassword')->withInput();
        }

        $password = $this->request->getVar('password1');

        $hash = Password::hash($password);

        $this->usersModel->updatepass($hash, $id_user);
        session()->setFlashdata('pesan', 'updatepass');

        return redirect()->to('/home/realindex');
    }

    public function apitahungrafikdata()
    {
        $data = [
            'coba' => [$this->sumtahun->apigetsumpertahun(2023), $this->sumtahun->apigetsumpertahun(2024)]
        ];

        echo json_encode($data);
    }

    //method untuk menampilkan rekap user pada aplikasi ini
    public function rekapuser()
    {
        if (isset($_SESSION['years'])) {
            $arraytemp = [];

            $getusers = $this->usersModel->findAll();

            $count_user = count($getusers);

            for ($i = 0; $i < $count_user; $i++) {
                for ($j = 0; $j < 2; $j++) {
                    $arraytemp[$i][0] = $getusers[$i]['username'];
                    $arraytemp[$i][1] = $getusers[$i]['fullname'];
                }
            }

            $data = [
                'tittle' => 'Rekap User',
                'rekapuser' => $arraytemp
            ];

            return view('datamaster/rekapuser_view', $data);
        } else {
            return redirect()->to('/');
        }
    }
}
