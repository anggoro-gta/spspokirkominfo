<?php

namespace App\Controllers;

use Dompdf\Dompdf;
use App\Models\rkpdsubsumberModel;
use App\Models\mastersubunitskpdModel;
use App\Models\masterskpdrkpdsubsumberModel;

class Rkpdsubsumber extends BaseController
{
    protected $masterskpd;
    protected $rkpdsubsumber;
    protected $mastersubunit;

    protected $dompdf;

    public function __construct()
    {
        $this->masterskpd = new masterskpdrkpdsubsumberModel();
        $this->mastersubunit = new mastersubunitskpdModel();
        $this->rkpdsubsumber = new rkpdsubsumberModel();

        $this->dompdf = new Dompdf();
    }

    public function index()
    {
        $arraytemp = [];

        $getskpd = $this->masterskpd->findAll();
        // $getsubunit = $this->mastersubunit->findAll();

        $jumlahskpd = count($getskpd);

        for ($i = 0; $i < $jumlahskpd; $i++) {
            $getdistinctsumber =  $this->rkpdsubsumber->getdistinct($getskpd[$i]['nama_skpd']);
            $count_getdistinctsumber = count($getdistinctsumber);
            for ($j = 0; $j < $count_getdistinctsumber; $j++) {
                $arraytemp[$i][$j]['skpd'] = $getskpd[$i]['nama_skpd'];
                $arraytemp[$i][$j]['sumberdana'] = $getdistinctsumber[$j]['nama_sumber_dana'];
                $arraytemp[$i][$j]['pagu'] = number_format($this->rkpdsubsumber->hitungjumlahpaguperskpd($getskpd[$i]['nama_skpd'], $getdistinctsumber[$j]['nama_sumber_dana']));
            }
        }

        $data = [
            'tittle' => 'RKPD 2024 sub keg sumber',
            'resultskpd' => $arraytemp
        ];

        return view('rkpdsubsumber/allrkpdsubsumberview', $data);

        // $arraytemp = [];

        // $getskpd = $this->masterskpd->findAll();

        // $jumlahskpd = count($getskpd);

        // for ($i = 0; $i < $jumlahskpd; $i++) {
        //     for ($j = 0; $j < 2; $j++) {
        //         $arraytemp[$i][0] = $getskpd[$i]['nama_skpd'];
        //     }
        // }

        // $data = [
        //     'tittle' => 'RKPD 2024 sub keg sumber',
        //     'resultskpd' => $arraytemp
        // ];

        // return view('rkpdsubsumber/rkpdsubsumberview', $data);
    }


    public function detailskpd($namaskpd)
    {
        $arraydatasubpersumber = [];
        $getdistinctsumber =  $this->rkpdsubsumber->getdistinct($namaskpd);
        $getjumlahpagu = $this->rkpdsubsumber->hitungjumlahpagu($namaskpd);

        $jumlahiterasi = count($getdistinctsumber);

        for ($i = 0; $i < $jumlahiterasi; $i++) {
            for ($j = 0; $j < 3; $j++) {
                $arraydatasubpersumber[$i][0] = $namaskpd; //nama skpd
                $arraydatasubpersumber[$i][1] = $getdistinctsumber[$i]['nama_sumber_dana']; //nama sumber dana
                $arraydatasubpersumber[$i][2] = number_format($this->rkpdsubsumber->hitungjumlahpaguperskpd($namaskpd, $getdistinctsumber[$i]['nama_sumber_dana'])); //nilai pagu
            }
        }

        $totalpagu_number_format = number_format($getjumlahpagu);

        $data = [
            'tittle' => $namaskpd,
            'resultskpd' => $arraydatasubpersumber,
            'totalpagu' => $totalpagu_number_format
        ];

        return view('rkpdsubsumber/perskpdsumberdanaview', $data);
    }
}
