<?php

namespace App\Controllers;

use App\Models\dbmusren_tbmusrenModel;
use Dompdf\Dompdf;

class Cetakmusrenprov extends BaseController
{
    protected $tabelmusren;
    protected $dompdf;

    public function __construct()
    {

        $this->dompdf = new Dompdf();
        $this->tabelmusren = new dbmusren_tbmusrenModel();
    }

    public function index()
    {
        $getallmusrenprov = $this->tabelmusren->findAll();

        $data = [
            'tittle' => 'Musrenbang Provinsi',
            'alldatamusrenprov' => $getallmusrenprov
        ];

        $html =  view('datamaster/cetakmusrenprovinsi', $data);

        $this->dompdf->loadHtml($html);
        $this->dompdf->setPaper('folio', 'landscape');
        $this->dompdf->render();
        $this->dompdf->stream('cetak-usulan-musrenprov-kabkdr.pdf', array(
            "Attachment" => true
        ));
    }
}
