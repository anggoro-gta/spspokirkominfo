<?php

namespace App\Controllers;

use Dompdf\Dompdf;
use App\Models\masterskpdModel;
use App\Models\tabelpokirModel;

class Calculatorskpd extends BaseController
{
    protected $masterskpd;
    protected $jumlahsumskpd;

    protected $dompdf;

    public function __construct()
    {
        $this->masterskpd = new masterskpdModel();
        $this->jumlahsumskpd = new tabelpokirModel();

        $this->dompdf = new Dompdf();
    }

    public function index()
    {
        if (isset($_SESSION['years'])) {
            $arraytemp = [];

            $getskpd = $this->masterskpd->findAll();

            $getsumallskpd = $this->jumlahsumskpd->getsumtotalskpd();

            $jumlahskpd = count($getskpd);

            for ($i = 0; $i < $jumlahskpd; $i++) {
                for ($j = 0; $j < 2; $j++) {
                    $arraytemp[$i][0] = $getskpd[$i]['nama_skpd'];
                    $arraytemp[$i][1] = number_format($this->jumlahsumskpd->getsumperskpd($getskpd[$i]['nama_skpd']));
                    // $arraytemp[$i][1] = number_format($this->jumlahsumskpd->getsumperskpd($getskpd[$i]['nama_skpd']), 2, ",", ".");
                }
            }

            $number_formatall = number_format($getsumallskpd);

            $data = [
                'tittle' => "Rekap SKPD Pokir-" . $_SESSION['years'],
                'resultskpd' => $arraytemp,
                'totalsemua' => $number_formatall
            ];

            return view('datamaster/calculatorskpd', $data);
        } else {
            return redirect()->to('/');
        }
    }

    public function detailskpd($namaskpd)
    {
        if (isset($_SESSION['years'])) {
            $getdetailskpd = $this->jumlahsumskpd->getalldataperskpd($namaskpd);
            $jumlahsumperskpd = $this->jumlahsumskpd->getsumperskpd($namaskpd);
            $jumlahrealisasi = $this->jumlahsumskpd->getsumperskpdrealisasi($namaskpd);
            $jumlahakomodir = $this->jumlahsumskpd->getsumperskpdakomodir($namaskpd);
            $jumlahtdkakomodir = $this->jumlahsumskpd->getsumperskptdkdakomodir($namaskpd);
            $jumlahtdkwarna = $this->jumlahsumskpd->getsumskpdtdkwarna($namaskpd);

            $number_formatskpd = number_format($jumlahsumperskpd);
            $number_format_realisasi = number_format($jumlahrealisasi);
            $number_format_akomodir = number_format($jumlahakomodir);
            $number_format_tdkakomodir = number_format($jumlahtdkakomodir);
            $number_format_tdkwarna = number_format($jumlahtdkwarna);

            $data = [
                'tittle' => $namaskpd,
                'resultdetailskpd' => $getdetailskpd,
                'jumlahskpd' => $number_formatskpd,
                'realisasi' => $number_format_realisasi,
                'akomodir' => $number_format_akomodir,
                'tdkakomodir' => $number_format_tdkakomodir,
                'tdkwarna' => $number_format_tdkwarna
            ];

            return view('datamaster/detailskpd', $data);
        } else {
            return redirect()->to('/');
        }
    }

    public function cetakperskpd($namaskpd)
    {
        if (isset($_SESSION['years'])) {
            $getallperskpd = $this->jumlahsumskpd->getalldataperskpd($namaskpd);
            $jumlahsumperskpd = $this->jumlahsumskpd->getsumperskpd($namaskpd);

            $jumlahrealisasi = $this->jumlahsumskpd->getsumperskpdrealisasi($namaskpd);
            $jumlahakomodir = $this->jumlahsumskpd->getsumperskpdakomodir($namaskpd);
            $jumlahtdkakomodir = $this->jumlahsumskpd->getsumperskptdkdakomodir($namaskpd);
            $jumlahtdkwarna = $this->jumlahsumskpd->getsumskpdtdkwarna($namaskpd);

            $number_format_realisasi = number_format($jumlahrealisasi);
            $number_format_akomodir = number_format($jumlahakomodir);
            $number_format_tdkakomodir = number_format($jumlahtdkakomodir);
            $number_format_tdkwarna = number_format($jumlahtdkwarna);

            $data = [
                'tittle' => 'Cetak SKPD',
                'dataallskpd' => $getallperskpd,
                'sumskpd' => $jumlahsumperskpd,
                'tdkakomodir' => $number_format_tdkakomodir,
                'akomodir' => $number_format_akomodir,
                'realisasi' => $number_format_realisasi,
                'tidakwarna' => $number_format_tdkwarna
            ];

            $html =  view('datamaster/cetakcalculatorskpd', $data);

            $this->dompdf->loadHtml($html);
            $this->dompdf->setPaper('folio', 'landscape');
            $this->dompdf->render();
            $this->dompdf->stream("pokir-" . $_SESSION['years'] . "-" . $namaskpd . ".pdf", array(
                "Attachment" => true
            ));
        } else {
            return redirect()->to('/');
        }
    }
}
