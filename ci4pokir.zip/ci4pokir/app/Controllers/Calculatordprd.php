<?php

namespace App\Controllers;

use Dompdf\Dompdf;
use App\Models\masterdprdModel;
use App\Models\tabelpokirModel;

class Calculatordprd extends BaseController
{
    protected $masterdprd;
    protected $jumlahsumdprd;

    protected $dompdf;

    public function __construct()
    {
        $this->masterdprd = new masterdprdModel();
        $this->jumlahsumdprd = new tabelpokirModel();

        $this->dompdf = new Dompdf();
    }

    public function index()
    {
        if (isset($_SESSION['years'])) {
            $arraytemp = [];

            $getdprd = $this->masterdprd->selectallbyyears();

            $getsumalldprd = $this->jumlahsumdprd->getsumtotaldprd();

            $jumlahdprd = count($getdprd);

            for ($i = 0; $i < $jumlahdprd; $i++) {
                $arraytemp[$i][0] = $getdprd[$i]['nama_dprd'];
                $arraytemp[$i][1] = number_format($this->jumlahsumdprd->getsumperdprd($getdprd[$i]['nama_dprd']));
                $arraytemp[$i][2] = number_format($this->masterdprd->getbatasanpagudprd($getdprd[$i]['nama_dprd']));
                $arraytemp[$i][3] = $this->jumlahsumdprd->getsumperdprd($getdprd[$i]['nama_dprd']) - $this->masterdprd->getbatasanpagudprd($getdprd[$i]['nama_dprd']);
                $arraytemp[$i][4] = $this->masterdprd->getfrkasidprd($getdprd[$i]['nama_dprd']);
                $arraytemp[$i][5] = $this->masterdprd->getketbanggardprd($getdprd[$i]['nama_dprd']);
                // $arraytemp[$i][1] = number_format($this->jumlahsumskpd->getsumperskpd($getskpd[$i]['nama_skpd']), 2, ",", ".");
            }

            $number_formatall = number_format($getsumalldprd);

            $data = [
                'tittle' => "Rekap DPRD Pokir-" . $_SESSION['years'],
                'resultdprd' => $arraytemp,
                'totalsemua' => $number_formatall
            ];

            return view('datamaster/calculatordprd', $data);
        } else {
            return redirect()->to('/');
        }
    }

    public function rekapusulandprd()
    {
        if (isset($_SESSION['years'])) {
            $arraytemp = [];

            $getdprd = $this->masterdprd->findAll();

            $getsumalldprd = $this->jumlahsumdprd->getsumtotaldprd();

            $jumlahdprd = count($getdprd);

            for ($i = 0; $i < $jumlahdprd; $i++) {
                $arraytemp[$i][0] = $getdprd[$i]['nama_dprd'];
                $arraytemp[$i][1] = number_format($this->jumlahsumdprd->getsumperdprd($getdprd[$i]['nama_dprd']));
                $arraytemp[$i][2] = $this->jumlahsumdprd->gettotalsemuausulan($getdprd[$i]['nama_dprd']);
                $arraytemp[$i][3] = $this->jumlahsumdprd->gettotalusulanhijau($getdprd[$i]['nama_dprd']);
                $arraytemp[$i][4] = $this->jumlahsumdprd->gettotalusulankuning($getdprd[$i]['nama_dprd']);
                $arraytemp[$i][5] = $this->jumlahsumdprd->gettotalusulanmerah($getdprd[$i]['nama_dprd']);
                $arraytemp[$i][6] = $this->jumlahsumdprd->gettotalusulanputih($getdprd[$i]['nama_dprd']);
                $arraytemp[$i][7] = $this->masterdprd->getfrkasidprd($getdprd[$i]['nama_dprd']);
                $arraytemp[$i][8] = $this->masterdprd->getketbanggardprd($getdprd[$i]['nama_dprd']);
                // $arraytemp[$i][1] = number_format($this->jumlahsumskpd->getsumperskpd($getskpd[$i]['nama_skpd']), 2, ",", ".");
            }

            $number_formatall = number_format($getsumalldprd);

            $data = [
                'tittle' => "Rekap DPRD Pokir-" . $_SESSION['years'],
                'resultdprd' => $arraytemp,
                'totalsemua' => $number_formatall
            ];

            return view('datamaster/calculatordprdusulan', $data);
        } else {
            return redirect()->to('/');
        }
    }

    public function detaildprd($namadprd)
    {
        if (isset($_SESSION['years'])) {
            $getdetaildprd = $this->jumlahsumdprd->getalldataperdprd($namadprd);
            $jumlahsumperdprd = $this->jumlahsumdprd->getsumperdprd($namadprd);
            $jumlahrealisasi = $this->jumlahsumdprd->getsumperdprdrealisasi($namadprd);
            $jumlahakomodir = $this->jumlahsumdprd->getsumperdprdakomodir($namadprd);
            $jumlahtdkakomodir = $this->jumlahsumdprd->getsumperdprdtdkdakomodir($namadprd);
            $jumlahtdkwarna = $this->jumlahsumdprd->getsumdprdtdkwarna($namadprd);

            $number_formatdprd = number_format($jumlahsumperdprd);
            $number_formatdprd_realisasi = number_format($jumlahrealisasi);
            $number_formatdprd_akomodir = number_format($jumlahakomodir);
            $number_formatdprd_tdkakomodir = number_format($jumlahtdkakomodir);
            $number_formatdprd_tdkwarna = number_format($jumlahtdkwarna);            

            $data = [
                'tittle' => $namadprd,
                'resultdetaildprd' => $getdetaildprd,
                'jumlahdprd' => $number_formatdprd,
                'realisasi' => $number_formatdprd_realisasi,
                'akomodir' => $number_formatdprd_akomodir,
                'tdkakomodir' => $number_formatdprd_tdkakomodir,
                'tidakwarna' => $number_formatdprd_tdkwarna
            ];

            return view('datamaster/detaildprd', $data);
        } else {
            return redirect()->to('/');
        }
    }

    public function cetakperdprd($namadprd)
    {
        if (isset($_SESSION['years'])) {
            $getallperdprd = $this->jumlahsumdprd->getalldataperdprd($namadprd);
            $jumlahsumperdprd = $this->jumlahsumdprd->getsumperdprd($namadprd);

            $jumlahrealisasi = $this->jumlahsumdprd->getsumperdprdrealisasi($namadprd);
            $jumlahakomodir = $this->jumlahsumdprd->getsumperdprdakomodir($namadprd);
            $jumlahtdkakomodir = $this->jumlahsumdprd->getsumperdprdtdkdakomodir($namadprd);
            $jumlahtdkwarna = $this->jumlahsumdprd->getsumdprdtdkwarna($namadprd);

            $jumlahusulan = $this->jumlahsumdprd->gettotalsemuausulan($namadprd);
            $jumlahusulanmerah = $this->jumlahsumdprd->gettotalusulanmerah($namadprd);
            $jumlahusulankuning = $this->jumlahsumdprd->gettotalusulankuning($namadprd);
            $jumlahusulanhijau = $this->jumlahsumdprd->gettotalusulanhijau($namadprd);
            $jumlahusulanputih = $this->jumlahsumdprd->gettotalusulanputih($namadprd);

            $number_format_realisasi = number_format($jumlahrealisasi);
            $number_format_akomodir = number_format($jumlahakomodir);
            $number_format_tdkakomodir = number_format($jumlahtdkakomodir);
            $number_format_tdkwarna = number_format($jumlahtdkwarna);

            $data = [
                'tittle' => 'Cetak DPRD',
                'dataalldprd' => $getallperdprd,
                'sumdprd' => $jumlahsumperdprd,
                'tdkakomodir' => $number_format_tdkakomodir,
                'akomodir' => $number_format_akomodir,
                'realisasi' => $number_format_realisasi,
                'tidakwarna' => $number_format_tdkwarna,
                'jumlahusulan' => $jumlahusulan,
                'jumlahusulanmerah' => $jumlahusulanmerah,
                'jumlahusulankuning' => $jumlahusulankuning,
                'jumlahusulanhijau' => $jumlahusulanhijau,
                'jumlahusulanputih' => $jumlahusulanputih,
            ];

            $html =  view('datamaster/cetakcalculatordprd', $data);

            $this->dompdf->loadHtml($html);
            $this->dompdf->setPaper('folio', 'landscape');
            $this->dompdf->render();
            $this->dompdf->stream("pokir-" . $_SESSION['years'] . "-" . $namadprd . ".pdf", array(
                "Attachment" => true
            ));
        } else {
            return redirect()->to('/');
        }
    }
}
