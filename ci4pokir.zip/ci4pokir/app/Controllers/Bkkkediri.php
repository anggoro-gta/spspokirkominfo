<?php

namespace App\Controllers;

use Dompdf\Dompdf;
use App\Models\mastermusModel;
use App\Models\masterdesakecamatanModel;

class Bkkkediri extends BaseController
{
    protected $masterdesakecamatan;
    protected $desakecamatan;

    protected $dompdf;

    public function __construct()
    {
        $this->masterdesakecamatan = new masterdesakecamatanModel();
        $this->desakecamatan = new mastermusModel();

        $this->dompdf = new Dompdf();
    }

    public function index()
    {
        $arraytemp = [];

        $getdesakecamatan = $this->masterdesakecamatan->findAll();

        // $getsumalldprd = $this->jumlahsumdprd->getsumtotaldprd();

        $jumlahdesakecamatan = count($getdesakecamatan);

        for ($i = 0; $i < $jumlahdesakecamatan; $i++) {
            for ($j = 0; $j < 4; $j++) {
                $arraytemp[$i][0] = $getdesakecamatan[$i]['nama_desa'];
                $arraytemp[$i][1] = $getdesakecamatan[$i]['nama_kecamatan'];
                $arraytemp[$i][2] = $this->desakecamatan->getsumpergabungan($getdesakecamatan[$i]['gabungan']);
                // $arraytemp[$i][2] = $this->desakecamatan->getusulan($getdesakecamatan[$i]['gabungan']);
                // $arraytemp[$i][1] = number_format($this->jumlahsumskpd->getsumperskpd($getskpd[$i]['nama_skpd']), 2, ",", ".");
            }
        }

        // $number_formatall = number_format($getsumalldprd, 2, ",", ".");       

        $data = [
            'tittle' => 'bkk kab. kediri',
            'resultgabungan' => $arraytemp
        ];

        return view('datamaster/viewbkkkediri', $data);
    }

    public function cetakperdprd($namadprd)
    {
        // $getallperdprd = $this->jumlahsumdprd->getalldataperdprd($namadprd);
        // $jumlahsumperdprd = $this->jumlahsumdprd->getsumperdprd($namadprd);

        // $data = [
        //     'tittle' => 'Cetak DPRD',
        //     'dataallskpd' => $getallperdprd,
        //     'sumdprd' => $jumlahsumperdprd
        // ];

        // $html =  view('datamaster/cetakcalculatordprd', $data);

        // $this->dompdf->loadHtml($html);
        // $this->dompdf->setPaper('folio', 'landscape');
        // $this->dompdf->render();
        // $this->dompdf->stream('dprd-cetak.pdf', array(
        //     "Attachment" => true
        // ));
    }
}
