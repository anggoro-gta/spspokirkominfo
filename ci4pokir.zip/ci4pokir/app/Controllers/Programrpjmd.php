<?php

namespace App\Controllers;

use App\Models\masterprogrkpdModel;
use App\Models\masterprogrpjmdModel;
use App\Models\masteridprogdistincModel;

class Programrpjmd extends BaseController
{
    protected $masterprogdistinc;
    protected $masterprogrpjmd;
    protected $masterprogrkpd;

    public function __construct()
    {
        $this->masterprogdistinc = new masteridprogdistincModel();
        $this->masterprogrpjmd = new masterprogrpjmdModel();
        $this->masterprogrkpd = new masterprogrkpdModel();
    }

    public function index()
    {
        $arraytemp = [];

        $getdataprogramrpjmd = $this->masterprogrpjmd->findAll();
        $count_getdataprogramrpjmd = count($getdataprogramrpjmd);

        for ($i = 0; $i < $count_getdataprogramrpjmd; $i++) {
            $tempdatarkpd = $this->masterprogrkpd->getdatarkpdbynamaprogram($getdataprogramrpjmd[$i]['text_prog_rpjmd']);
            $count_tempdatarkpd = count($tempdatarkpd);
            if ($count_tempdatarkpd == 1) {
                $arraytemp[$i]['kode_program'] = $tempdatarkpd[0]['kode_program'];
                $arraytemp[$i]['nama_program_rpjmd'] = $getdataprogramrpjmd[$i]['text_prog_rpjmd'];
                $arraytemp[$i]['nama_program_rkpd'] = $tempdatarkpd[0]['nama_program_rkpd'];
                $arraytemp[$i]['konsistensi'] = 'konsisten';
            } else {
                $arraytemp[$i]['kode_program'] = 'kosong';
                $arraytemp[$i]['nama_program_rpjmd'] = $getdataprogramrpjmd[$i]['text_prog_rpjmd'];
                $arraytemp[$i]['nama_program_rkpd'] = 'kosong';
                $arraytemp[$i]['konsistensi'] = 'tidak konsisten';
            }
        }

        $data = [
            'tittle' => 'Program RPJMD',
            'resultrjpmd' => $arraytemp
        ];

        return view('rpjmd/rpjmdview', $data);
    }
}
