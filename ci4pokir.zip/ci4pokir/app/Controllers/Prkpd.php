<?php

namespace App\Controllers;

use Dompdf\Dompdf;
use App\Models\masterskpdModel;
use App\Models\msprkpdModel;

class Prkpd extends BaseController
{
    protected $masterskpd;
    protected $varurusan;
    protected $varbidangurusan;
    protected $varprogram;
    protected $varnamaopd;

    protected $dompdf;

    public function __construct()
    {
        $this->masterskpd = new masterskpdModel();
        $this->varurusan = new msprkpdModel();
        $this->varbidangurusan = new msprkpdModel();
        $this->varprogram = new msprkpdModel();
        $this->varnamaopd = new masterskpdModel();

        $this->dompdf = new Dompdf();
    }

    public function index()
    {
        if (isset($_SESSION['years'])) {

            $getskpd = $this->masterskpd->findAll();

            $data = [
                'tittle' => "P-RKPD " . $_SESSION['years'],
                'resultskpd' => $getskpd,
            ];

            return view('prkpd/prkpd_index', $data);
        } else {
            return redirect()->to('/');
        }
    }

    public function print($kode_opd)
    {
        if (isset($_SESSION['years'])) {

            $nama_opd = $this->varnamaopd->getnamaopd($kode_opd);

            $get_urusan = $this->varurusan->urusan($kode_opd);
            $get_bidang_urusan = $this->varbidangurusan->bidang_urusan($kode_opd);
            $get_program = $this->varprogram->program($kode_opd);

            $count_urusan = count($get_urusan);
            $count_bidang_urusan = count($get_bidang_urusan);
            $count_program = count($get_program);

            //get details program dan komponen nya
            $arraytempprogram = [];
            for ($i = 0; $i < $count_program; $i++) {
                $arraytempprogram[$i]['kode_bidang_urusan'] = $get_program[$i]['kode_bidang_urusan'];
                $arraytempprogram[$i]['nama_bidang_urusan'] = $get_program[$i]['nama_bidang_urusan'];
                $arraytempprogram[$i]['kode_program'] = $get_program[$i]['kode_program'];
                $arraytempprogram[$i]['nama_program'] = $get_program[$i]['nama_program'];
                $arraytempprogram[$i]['indikator_program'] = "TES ada isinya";
                $arraytempprogram[$i]['volume_program_sebelum'] = $get_program[$i]['volume_program_sebelum'];
                $arraytempprogram[$i]['satuan_program_sebelum'] = $get_program[$i]['satuan_program_sebelum'];
            }

            $count_arraytempprogram = count($arraytempprogram);

            $data = [
                'tittle' => 'Cetak P-RKPD',
                'urusan' => $get_urusan,
                'bidangurusan' => $get_bidang_urusan,
                'arraytempprogram' => $arraytempprogram,
                'counturusan' => $count_urusan,
                'countbidangurusan' => $count_bidang_urusan,
                'countarraytempprogram' => $count_arraytempprogram
            ];

            $html =  view('prkpd/print', $data);

            $this->dompdf->loadHtml($html);
            $this->dompdf->setPaper('folio', 'landscape');
            $this->dompdf->render();
            $this->dompdf->stream($kode_opd . " " . $nama_opd . ".pdf", array(
                "Attachment" => true
            ));
        } else {
            return redirect()->to('/');
        }
    }
}
