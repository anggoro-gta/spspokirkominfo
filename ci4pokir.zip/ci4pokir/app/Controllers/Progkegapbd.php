<?php

namespace App\Controllers;

use App\Models\masterskpdModel;
use App\Models\tabelapbdprogkegModel;

class Progkegapbd extends BaseController
{
    protected $masterskpd;
    protected $tblapbd;

    public function __construct()
    {
        $this->masterskpd = new masterskpdModel();
        $this->tblapbd = new tabelapbdprogkegModel();
    }

    public function index()
    {
        $arraytemp = [];

        $getskpd = $this->masterskpd->findAll();
        // $getsubunit = $this->mastersubunit->findAll();

        $jumlahskpd = count($getskpd);

        for ($i = 0; $i < $jumlahskpd; $i++) {
            $getdistictprog = $this->tblapbd->getdistinct($getskpd[$i]['kode_skpd']);
            $count_getdistictprog =  count($getdistictprog);
            for ($j = 0; $j < $count_getdistictprog; $j++) {
                $arraytemp[$i][$j]['kode_opd'] = $getskpd[$i]['kode_skpd'];
                $arraytemp[$i][$j]['nama_opd'] = $getskpd[$i]['nama_skpd'];
                $arraytemp[$i][$j]['program'] = $getdistictprog[$j]['kode_program'];
                $arraytemp[$i][$j]['nama_program'] = $this->tblapbd->getnamaprog($getdistictprog[$j]['kode_program']);
                $arraytemp[$i][$j]['pagu_total'] = number_format($this->tblapbd->sumbykodeprogdanopd($getdistictprog[$j]['kode_program'], $getskpd[$i]['kode_skpd']));
            }
        }

        $data = [
            'tittle' => 'APBD 2024 rekap program',
            'resultapbd' => $arraytemp
        ];

        return view('apbd/rekapapbdview', $data);
    }
}
