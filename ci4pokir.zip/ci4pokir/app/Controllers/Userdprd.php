<?php

namespace App\Controllers;

use Dompdf\Dompdf;
use App\Models\masterdprdModel;
use App\Models\masterskpdModel;
use App\Models\tabelpokirModel;
use App\Models\stateusulanModel;

use function PHPUnit\Framework\isEmpty;

class Userdprd extends BaseController
{
    protected $getskpdusulan;
    protected $masterskpd;
    protected $masterdprd;
    protected $stateusulan;

    protected $dompdf;

    public function __construct()
    {
        $this->getskpdusulan = new tabelpokirModel();
        $this->masterskpd = new masterskpdModel();
        $this->masterdprd = new masterdprdModel();
        $this->stateusulan = new stateusulanModel();

        $this->dompdf = new Dompdf();
    }

    public function index()
    {
        if (isset($_SESSION['years'])) {

            $lenght_usulan = $this->getskpdusulan->getalldataperdprd(user()->fullname);
            $count_lenght_usulan = count($lenght_usulan);

            $nama_drpd = user()->fullname;

            $get_usulan_drpd = $this->getskpdusulan->getalldataperdprd($nama_drpd);
            $get_total_usulan = $this->getskpdusulan->getsumperdprd($nama_drpd);
            $get_total_realisasi = $this->getskpdusulan->getsumperdprdrealisasi($nama_drpd);
            $get_total_akomodir = $this->getskpdusulan->getsumperdprdakomodir($nama_drpd);
            $get_total_tdk_akomodir = $this->getskpdusulan->getsumperdprdtdkdakomodir($nama_drpd);
            $get_total_tdk_warna = $this->getskpdusulan->getsumdprdtdkwarna($nama_drpd);
            $get_state_usulan = $this->stateusulan->getstateusulan();

            $format_get_total_usulan = number_format($get_total_usulan);
            $format_get_total_realisasi = number_format($get_total_realisasi);
            $format_get_total_akomodir = number_format($get_total_akomodir);
            $format_get_total_tdk_akomodir = number_format($get_total_tdk_akomodir);
            $format_get_total_tdk_warna = number_format($get_total_tdk_warna);

            if ($count_lenght_usulan == 0) {
                $namadprd = user()->fullname;

                $data = [
                    'tittle' => user()->fullname,
                    'usulandprd' => $namadprd,
                    'total' => $format_get_total_usulan,
                    'realisasi' => $format_get_total_realisasi,
                    'akomodir' => $format_get_total_akomodir,
                    'tdk_akomodir' => $format_get_total_tdk_akomodir,
                    'tdk_warna' => $format_get_total_tdk_warna,
                    'state_usulan' => $get_state_usulan
                ];

                return view('dprd/dprdview_kosong', $data);
            } else {
                $data = [
                    'tittle' => user()->fullname,
                    'usulandprd' => $get_usulan_drpd,
                    'total' => $format_get_total_usulan,
                    'realisasi' => $format_get_total_realisasi,
                    'akomodir' => $format_get_total_akomodir,
                    'tdk_akomodir' => $format_get_total_tdk_akomodir,
                    'tdk_warna' => $format_get_total_tdk_warna,
                    'state_usulan' => $get_state_usulan
                ];

                return view('dprd/dprdview', $data);
            }
        } else {
            return redirect()->to('/');
        }
    }

    public function apiusulandrpd()
    {
        $id = $_POST['id_data'];

        $arraytemp_usulan = [];

        $get_data = $this->getskpdusulan->apigetusulanbyid($id);
        $count_get_data = count($get_data);

        for ($i = 0; $i < $count_get_data; $i++) {
            $arraytemp_usulan[$i]['id'] = $get_data[0]['id'];
            $arraytemp_usulan[$i]['kegiatan'] = $get_data[0]['kegiatan'];
            $arraytemp_usulan[$i]['alamat'] = $get_data[0]['alamat'];
            $arraytemp_usulan[$i]['volume'] = $get_data[0]['volume'];
            $arraytemp_usulan[$i]['nilai'] = number_format($get_data[0]['nilai'], 0, ",", ".");
            $arraytemp_usulan[$i]['catatan_tenaga_ahli'] = $get_data[0]['catatan_tenaga_ahli'];
        }

        $data = [
            'data_usulan' => $arraytemp_usulan
        ];

        echo json_encode($data);
    }

    public function saveeditusulan()
    {
        $get_id_usulan = $this->request->getVar('id_usulan');
        $get_usulan = $this->request->getVar('usulan_dprd');
        $get_alamat_usulan = $this->request->getVar('alamat_usulan_dprd');
        $get_volume_usulan = $this->request->getVar('volume_usulan_dprd');
        $get_pagu_usulan = $this->request->getVar('pagu_usulan_dprd');
        $get_catatan_tenaga_ahli = $this->request->getVar('catatan_ta_usulan_dprd');

        $getnumb = preg_replace('/[^0-9]/', '', $get_pagu_usulan);
        $convertpagu = intval($getnumb);

        $this->getskpdusulan->updateusulandprd($get_id_usulan, $get_usulan, $get_alamat_usulan, $get_volume_usulan, $convertpagu, $get_catatan_tenaga_ahli);

        session()->setFlashdata('pesan', 'updateusulandprd');

        return redirect()->to('/userdprd');
    }

    public function addusulandprd()
    {
        if (isset($_SESSION['years'])) {
            $data = [
                'tittle' => 'Tambah Usulan'
            ];

            return view('dprd/dprdaddview', $data);
        } else {
            return redirect()->to('/');
        }
    }

    public function apigetskpd()
    {
        $get_term_skpd = $this->request->getVar('searchTerm');
        $data = [];

        if ($get_term_skpd) {
            $list_skpd = $this->masterskpd->select('id_skpd,nama_skpd')->like('nama_skpd', $get_term_skpd)->orderBy('kode_skpd')->findAll();
        } else {
            $list_skpd = $this->masterskpd->select('id_skpd,nama_skpd')->orderBy('kode_skpd')->findAll();
        }

        foreach ($list_skpd as $value) {
            $data[] = [
                'id' => $value['id_skpd'],
                'text' => $value['nama_skpd']
            ];
        }

        $response['data'] = $data;
        return $this->response->setJSON($response);
    }

    public function saveaddusulan()
    {
        $get_usulan = $this->request->getVar('usulan_dprd');
        $get_alamat_usulan = $this->request->getVar('alamat_usulan_dprd');
        $get_volume_usulan = $this->request->getVar('volume_usulan_dprd');
        $get_pagu_usulan = $this->request->getVar('pagu_usulan_dprd');
        $getnumb = preg_replace('/[^0-9]/', '', $get_pagu_usulan);
        $convertpagu = intval($getnumb);
        $get_keterangan_usulan = $this->request->getVar('keterangan_usulan_dprd');
        $get_skpd = $this->request->getVar('skpdselect');
        $get_nama_skpd = $this->masterskpd->getnamaskpd($get_skpd);
        $get_fraksi = $this->masterdprd->getfrkasidprd(user()->fullname);

        $this->getskpdusulan->addusulandprd($get_usulan, $get_alamat_usulan, $get_volume_usulan, $convertpagu, $get_nama_skpd, $get_fraksi, $get_keterangan_usulan);

        session()->setFlashdata('pesan', 'addusulandprd');

        return redirect()->to('/userdprd');
    }

    public function hapususulan()
    {
        $get_id = $this->request->getVar('id_hidden');

        $this->getskpdusulan->deleteusulandprd($get_id);

        session()->setFlashdata('pesan', 'hapususulandprd');

        return redirect()->to('/userdprd');
    }

    public function cetakindex()
    {
        if (isset($_SESSION['years'])) {
            $data = [
                'tittle' => 'Laporan'
            ];

            return view('dprd/dprdcetakindex', $data);
        } else {
            return redirect()->to('/');
        }
    }

    public function cetakusulan($nama_drpd)
    {
        $getallperdprd = $this->getskpdusulan->getalldataperdprd($nama_drpd);
        $jumlahsumperdprd = $this->getskpdusulan->getsumperdprd($nama_drpd);

        $jumlahrealisasi = $this->getskpdusulan->getsumperdprdrealisasi($nama_drpd);
        $jumlahakomodir = $this->getskpdusulan->getsumperdprdakomodir($nama_drpd);
        $jumlahtdkakomodir = $this->getskpdusulan->getsumperdprdtdkdakomodir($nama_drpd);
        $jumlahtdkwarna = $this->getskpdusulan->getsumdprdtdkwarna($nama_drpd);

        $number_format_realisasi = number_format($jumlahrealisasi);
        $number_format_akomodir = number_format($jumlahakomodir);
        $number_format_tdkakomodir = number_format($jumlahtdkakomodir);
        $number_format_tdkwarna = number_format($jumlahtdkwarna);

        $data = [
            'tittle' => 'Cetak DPRD',
            'dataalldprd' => $getallperdprd,
            'sumdprd' => $jumlahsumperdprd,
            'tdkakomodir' => $number_format_tdkakomodir,
            'akomodir' => $number_format_akomodir,
            'realisasi' => $number_format_realisasi,
            'tidakwarna' => $number_format_tdkwarna
        ];

        $html =  view('dprd/dprdcetakview', $data);

        $this->dompdf->loadHtml($html);
        $this->dompdf->setPaper('folio', 'landscape');
        $this->dompdf->render();
        $this->dompdf->stream("pokir-" . $_SESSION['years'] . "-" . $nama_drpd . ".pdf", array(
            "Attachment" => true
        ));
    }
}
