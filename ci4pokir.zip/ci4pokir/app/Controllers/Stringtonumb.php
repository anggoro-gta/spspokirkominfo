<?php

namespace App\Controllers;

use App\Models\stringtonumbModel;

class Stringtonumb extends BaseController
{
    protected $masternumber;

    public function __construct()
    {
        $this->masternumber = new stringtonumbModel();
    }

    public function index()
    {
        $getdataall = $this->masternumber->findAll();

        $data = [
            'tittle' => 'String to number',
            'data' => $getdataall
        ];

        return view('datamaster/stringtonumbview', $data);
    }
}
