<?php

namespace App\Controllers;

use Dompdf\Dompdf;
use App\Models\msmusnasModel;

class Cetakmusrennas extends BaseController
{
    protected $tabelmusren;
    protected $dompdf;

    public function __construct()
    {

        $this->dompdf = new Dompdf();
        $this->tabelmusren = new msmusnasModel();
    }

    public function index()
    {
        $getallmusrennas = $this->tabelmusren->findAll();

        $data = [
            'tittle' => 'Musrenbang Nasional',
            'alldatamusrennas' => $getallmusrennas
        ];

        $html =  view('datamaster/cetakmusrennas', $data);

        $this->dompdf->loadHtml($html);
        $this->dompdf->setPaper('folio', 'landscape');
        $this->dompdf->render();
        $this->dompdf->stream('cetak-usulan-musrennas-kabkdr.pdf', array(
            "Attachment" => true
        ));
    }
}
