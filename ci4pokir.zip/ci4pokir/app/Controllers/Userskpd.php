<?php

namespace App\Controllers;

use Dompdf\Dompdf;
use App\Models\tabelpokirModel;
use App\Models\stateusulanModel;
use App\Models\statususulanModel;

use function PHPUnit\Framework\countOf;

class Userskpd extends BaseController
{
    protected $getskpdusulan;
    protected $stateusulan;
    protected $statususulan;

    protected $dompdf;

    public function __construct()
    {
        $this->getskpdusulan = new tabelpokirModel();
        $this->stateusulan = new stateusulanModel();
        $this->statususulan = new statususulanModel();

        $this->dompdf = new Dompdf();
    }

    public function index()
    {
        if (isset($_SESSION['years'])) {
            $nama_skpd = user()->fullname;

            $get_usulan = $this->getskpdusulan->getalldataperskpd($nama_skpd);
            $get_total_usulan = $this->getskpdusulan->getsumperskpd($nama_skpd);
            $get_total_realisasi = $this->getskpdusulan->getsumperskpdrealisasi($nama_skpd);
            $get_total_akomodir = $this->getskpdusulan->getsumperskpdakomodir($nama_skpd);
            $get_total_tdk_akomodir = $this->getskpdusulan->getsumperskptdkdakomodir($nama_skpd);
            $get_total_tdk_warna = $this->getskpdusulan->getsumskpdtdkwarna($nama_skpd);
            $get_state_usulan = $this->stateusulan->getstateusulan();

            $format_get_total_usulan = number_format($get_total_usulan);
            $format_get_total_realisasi = number_format($get_total_realisasi);
            $format_get_total_akomodir = number_format($get_total_akomodir);
            $format_get_total_tdk_akomodir = number_format($get_total_tdk_akomodir);
            $format_get_total_tdk_warna = number_format($get_total_tdk_warna);

            $totalusulan = count($get_usulan);

            // menghitung persentase status usulan
            $zero_indeks = 0;
            $get_total_status_usulan = $this->getskpdusulan->getsumindekskelengkapan($nama_skpd);
            $persentase_status_usulan = $get_total_status_usulan / $totalusulan * 100;
            $format_persentase = number_format($persentase_status_usulan, 2, '.');

            if ($totalusulan == 0) {
                $namaskpd = user()->fullname;

                $data = [
                    'tittle' => 'Usulan',
                    'usulan' => $namaskpd,
                    'total' => $format_get_total_usulan,
                    'realisasi' => $format_get_total_realisasi,
                    'akomodir' => $format_get_total_akomodir,
                    'tdk_akomodir' => $format_get_total_tdk_akomodir,
                    'tdk_warna' => $format_get_total_tdk_warna,
                    'state_usulan' => $get_state_usulan,
                    'persentase_status_usulan' => $zero_indeks,
                ];
                return view('skpd/skpdview_kosong', $data);
            } else {
                if ($nama_skpd == 'Sekretariat Daerah') {
                    $data = [
                        'tittle' => 'Usulan',
                        'usulan' => $get_usulan,
                        'total' => $format_get_total_usulan,
                        'realisasi' => $format_get_total_realisasi,
                        'akomodir' => $format_get_total_akomodir,
                        'tdk_akomodir' => $format_get_total_tdk_akomodir,
                        'tdk_warna' => $format_get_total_tdk_warna,
                        'state_usulan' => $get_state_usulan,
                        'persentase_status_usulan' => $format_persentase,
                    ];
                    return view('skpd/skpdview_sekda', $data);
                } else {
                    $data = [
                        'tittle' => 'Usulan',
                        'usulan' => $get_usulan,
                        'total' => $format_get_total_usulan,
                        'realisasi' => $format_get_total_realisasi,
                        'akomodir' => $format_get_total_akomodir,
                        'tdk_akomodir' => $format_get_total_tdk_akomodir,
                        'tdk_warna' => $format_get_total_tdk_warna,
                        'state_usulan' => $get_state_usulan,
                        'persentase_status_usulan' => $format_persentase,
                    ];
                    return view('skpd/skpdview', $data);
                }
            }
        } else {
            return redirect()->to('/');
        }
    }

    public function apigetstatususulan()
    {
        $get_term_status = $this->request->getVar('searchTerm');
        $data = [];

        if ($get_term_status) {
            $list_status = $this->statususulan->select('id,status_usulan')->like('status_usulan', $get_term_status)->orderBy('id')->findAll();
        } else {
            $list_status = $this->statususulan->select('id,status_usulan')->orderBy('id')->findAll();
        }

        foreach ($list_status as $value) {
            $data[] = [
                'id' => $value['id'],
                'text' => $value['status_usulan']
            ];
        }

        $response['data'] = $data;
        return $this->response->setJSON($response);
    }

    public function apigetusulan()
    {
        $id = $_POST['id_data'];

        $arraytemp_usulan = [];

        $get_data = $this->getskpdusulan->apigetusulanbyid($id);
        $count_get_data = count($get_data);

        for ($i = 0; $i < $count_get_data; $i++) {
            $arraytemp_usulan[$i]['id'] = $get_data[0]['id'];
            $arraytemp_usulan[$i]['catatan_skpd'] = $get_data[0]['catatan_skpd'];
            $arraytemp_usulan[$i]['status_usulan'] = $get_data[0]['status_usulan'];
            // $arraytemp_usulan[$i]['volume'] = $get_data[0]['volume'];
            // $arraytemp_usulan[$i]['nilai'] = number_format($get_data[0]['nilai'], 0, ",", ".");
            // $arraytemp_usulan[$i]['catatan_tenaga_ahli'] = $get_data[0]['catatan_tenaga_ahli'];
        }

        $data = [
            'data_usulan' => $arraytemp_usulan
        ];

        echo json_encode($data);
    }

    public function apigetusulanstatus()
    {
        $id = $_POST['id_data'];

        $arraytemp_usulan = [];

        $get_data = $this->getskpdusulan->apigetusulanbyid($id);
        $count_get_data = count($get_data);

        for ($i = 0; $i < $count_get_data; $i++) {
            $arraytemp_usulan[$i]['id'] = $get_data[0]['id'];
            $arraytemp_usulan[$i]['keterangan'] = $get_data[0]['keterangan'];
            $arraytemp_usulan[$i]['status_usulan'] = $get_data[0]['status_usulan'];
            $arraytemp_usulan[$i]['indeks_kelengkapan'] = $get_data[0]['indeks_kelengkapan'];
            // $arraytemp_usulan[$i]['volume'] = $get_data[0]['volume'];
            // $arraytemp_usulan[$i]['nilai'] = number_format($get_data[0]['nilai'], 0, ",", ".");
            // $arraytemp_usulan[$i]['catatan_tenaga_ahli'] = $get_data[0]['catatan_tenaga_ahli'];
        }

        $data = [
            'data_usulan' => $arraytemp_usulan
        ];

        echo json_encode($data);
    }

    public function saveeditskpd()
    {
        $get_id = $this->request->getVar('id_usulan');
        $get_catatan = $this->request->getVar('catatan_skpd');
        $get_status = $this->request->getVar('status_usulan');

        $get_status_int = (int)$get_status;

        $this->getskpdusulan->updatecatatanskpd($get_id, $get_catatan, $get_status_int);


        session()->setFlashdata('pesan', 'updatecatatanskpd');

        return redirect()->to('/userskpd');
    }

    public function saveeditskpdstatususulan()
    {
        $get_id = $this->request->getVar('id_usulan_indeks');
        $get_keterangan = $this->request->getVar('keterangan');
        $get_indeks_kelengkapan = $this->request->getVar('indeks_keleng');
        $get_status = $this->request->getVar('status_usulan_stat');

        $get_status_int = (int)$get_status;
        $get_indeks_kelengkapan_double = (float)$get_indeks_kelengkapan;

        $this->getskpdusulan->updatecatatanskpdindeks($get_id, $get_keterangan, $get_indeks_kelengkapan_double, $get_status_int);


        session()->setFlashdata('pesan', 'updatecatatanskpd');

        return redirect()->to('/userskpd');
    }

    public function indexcetakskpd()
    {
        if (isset($_SESSION['years'])) {
            $data = [
                'tittle' => 'Cetak'
            ];
            return view('skpd/skpdcetakindex', $data);
        } else {
            return redirect()->to('/');
        }
    }

    public function cetakskpd($namaskpd)
    {
        if (isset($_SESSION['years'])) {
            $getallperskpd = $this->getskpdusulan->getalldataperskpd($namaskpd);
            $jumlahsumperskpd = $this->getskpdusulan->getsumperskpd($namaskpd);

            $jumlahrealisasi = $this->getskpdusulan->getsumperskpdrealisasi($namaskpd);
            $jumlahakomodir = $this->getskpdusulan->getsumperskpdakomodir($namaskpd);
            $jumlahtdkakomodir = $this->getskpdusulan->getsumperskptdkdakomodir($namaskpd);
            $jumlahtdkwarna = $this->getskpdusulan->getsumskpdtdkwarna($namaskpd);

            $number_format_realisasi = number_format($jumlahrealisasi);
            $number_format_akomodir = number_format($jumlahakomodir);
            $number_format_tdkakomodir = number_format($jumlahtdkakomodir);
            $number_format_tdkwarna = number_format($jumlahtdkwarna);

            if ($namaskpd == 'Sekretariat Daerah') {
                $data = [
                    'tittle' => 'Cetak SKPD',
                    'dataallskpd' => $getallperskpd,
                    'sumskpd' => $jumlahsumperskpd,
                    'tdkakomodir' => $number_format_tdkakomodir,
                    'akomodir' => $number_format_akomodir,
                    'realisasi' => $number_format_realisasi,
                    'tidakwarna' => $number_format_tdkwarna
                ];

                $html =  view('skpd/skpdcetakview_sekda', $data);

                $this->dompdf->loadHtml($html);
                $this->dompdf->setPaper('folio', 'landscape');
                $this->dompdf->render();
                $this->dompdf->stream("pokir-" . $_SESSION['years'] . "-" . $namaskpd . ".pdf", array(
                    "Attachment" => true
                ));
            } else {
                $data = [
                    'tittle' => 'Cetak SKPD',
                    'dataallskpd' => $getallperskpd,
                    'sumskpd' => $jumlahsumperskpd,
                    'tdkakomodir' => $number_format_tdkakomodir,
                    'akomodir' => $number_format_akomodir,
                    'realisasi' => $number_format_realisasi,
                    'tidakwarna' => $number_format_tdkwarna
                ];

                $html =  view('skpd/skpdcetakview', $data);

                $this->dompdf->loadHtml($html);
                $this->dompdf->setPaper('folio', 'landscape');
                $this->dompdf->render();
                $this->dompdf->stream("pokir-" . $_SESSION['years'] . "-" . $namaskpd . ".pdf", array(
                    "Attachment" => true
                ));
            }
        } else {
            return redirect()->to('/');
        }
    }
}
