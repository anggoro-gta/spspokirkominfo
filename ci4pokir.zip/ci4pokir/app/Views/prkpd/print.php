<!DOCTYPE html>
<html>

<head>
    <link href='https://fonts.googleapis.com/css?family=Roboto' rel='stylesheet'>
    <style>
        body {
            font-family: 'Roboto';
        }

        table,
        td,
        th {
            border: 1px solid #333;
        }

        table {
            font-size: 10px;
            width: 100%;
            border-collapse: collapse;
        }

        td,
        th {
            padding: 2px;
        }

        th {
            background-color: #CCC;
        }

        h1 {
            text-align: center;
        }

        h3 {
            font-size: 12px;
            text-align: center;
        }

        @page {
            margin: 10px;
        }
    </style>
</head>

<body>

    <h3> Penetapan Perubahan Rencana Kerja Pemerintah Daerah (P-RKPD) <br> Kabupaten Kediri <br> Tahun 2024</h3>

    <br>
    <br>

    <table>
        <thead>
            <tr>
                <th rowspan="3" align="left">Kode</th>
                <th rowspan="3">Urusan/ Bidang Urusan/ Program/ Kegiatan/ Sub Kegiatan</th>
                <th rowspan="3">Indikator Program/ Kegiatan/ Sub Kegiatan</th>
                <th rowspan="3">Target Akhir Periode RPJMD</th>
                <th rowspan="3"> Realisasi Capaian RKPD Tahun 2021</th>
                <th rowspan="3">Prakiraan Capaian Target RKPD Tahun 2022</th>
                <th colspan="9">Capaian Kinerja dan Kerangka Pendanaan</th>
                <th rowspan="3">Kelompok Sasaran</th>
                <th colspan="2">Prakiraan Maju Rencana Tahun 2025</th>
                <th rowspan="3">Perangkat Daerah Penanggung Jawab</th>
            </tr>
            <tr>
                <th colspan="2">Target 2024</th>
                <th colspan="3">Pagu Indikatif</th>
                <th rowspan="2">Lokasi</th>
                <th rowspan="2">Sumber Dana</th>
                <th colspan="2">Prioritas</th>
                <th rowspan="2">Target</th>
                <th rowspan="2">Pagu Indikatif</th>                
            </tr>
            <tr>
                <th>Semula</th>
                <th>Menjadi</th>
                <th>RKPD 2024</th>
                <th>APBD 2024</th>
                <th>RKPD 2024 Perubahan</th>
                <th>Nasional</th>
                <th>Daerah</th>                
            </tr>
        </thead>
        <tbody>
            <?php for ($i = 0; $i < $counturusan; $i++) { ?>
                <tr>
                    <td><b><?= $urusan[$i]['kode_urusan']; ?></b></td>
                    <td colspan="18" align="left"><b><?= $urusan[$i]['nama_urusan']; ?></b></td>
                </tr>
                <?php for ($j = 0; $j < $countbidangurusan; $j++) { ?>
                    <?php if ($urusan[$i]['kode_urusan'] == $bidangurusan[$j]['kode_urusan']) { ?>
                        <tr>
                            <td><b><?= $bidangurusan[$j]['kode_bidang_urusan']; ?></b></td>
                            <td colspan="18" align="left"><b><?= $bidangurusan[$j]['nama_bidang_urusan']; ?></b></td>
                        </tr>
                        <?php for ($k = 0; $k < $countarraytempprogram; $k++) { ?>
                            <?php if ($bidangurusan[$j]['kode_bidang_urusan'] == $arraytempprogram[$k]['kode_bidang_urusan']) { ?>
                                <tr>
                                    <td><b><?= $arraytempprogram[$k]['kode_program']; ?></b></td>
                                    <td><b><?= $arraytempprogram[$k]['nama_program']; ?></b></td>
                                    <td><b><?= $arraytempprogram[$k]['indikator_program']; ?></b></td>
                                    <td><b><?= $arraytempprogram[$k]['volume_program_sebelum']; ?></b></td>
                                    <td><b><?= $arraytempprogram[$k]['satuan_program_sebelum']; ?></b></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                            <?php } ?>
                        <?php } ?>
                    <?php } ?>
                <?php } ?>
            <?php } ?>
        </tbody>
    </table>
</body>

</html>