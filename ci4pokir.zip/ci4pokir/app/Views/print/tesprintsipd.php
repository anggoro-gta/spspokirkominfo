<style>
    table,
    td,
    th {
        border: 1px solid #333;
    }

    table {
        width: 100%;
        border-collapse: collapse;
    }

    td,
    th {
        padding: 2px;
    }

    th {
        background-color: #CCC;
    }

    h1 {
        text-align: center;
    }

    @page {
        margin: 10px;
    }
</style>

<h1>SKPD : <?= $sipd[0]['nama_skpd']; ?></h1>
<input type="button" value="Print PDF" onclick="window.open('<?= site_url('printscraping/printsipd'); ?>','blank')">
<br>
<br>

<!-- "pagu_giat" = pagu P-RKPD -->
<div class="table-responsive-normal">
    <div class="mb-2"><strong></strong></div>
    <table class="table table-bordered va-top">
        <thead>
            <tr>
                <th rowspan="2" class="text-center">No.</th>
                <th rowspan="2">Rincian</th>
                <th rowspan="2">Komponen</th>
                <th rowspan="2">Lokasi Kegiatan</th>
                <th colspan="2">Output Kegiatan</th>
                <th rowspan="2">Kebutuhan Dana</th>
            </tr>
            <tr>
                <th>Volume</th>
                <th>Satuan</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td rowspan="52" class="text-center">1.
                </td>
                <td rowspan="52">
                    03.03.01 - Penguatan Balai Penyuluhan Pertanian.
                </td>
                <td rowspan="26">
                    03.03.01.01 - Bantuan Paket Data Bagi Admin Laporan Utama (12 OB).
                </td>
                <td>
                    03.03.01.01.3506.010 - MOJO<br>
                    <table class="table-sm mt-2" style="width: 100%;">
                        <thead>
                            <tr>
                                <th>Sub Komponen</th>
                                <th>Output</th>
                            </tr>
                        </thead>
                        <tbody></tbody>
                    </table>
                </td>
                <td class="text-right">12</td>
                <td>OB</td>
                <td class="text-right">3.000.000,0</td>
            </tr>
            <tr><!----> <!----> <!---->
                <td>
                    03.03.01.01.3506.020 - SEMEN<br>
                    <table class="table-sm mt-2" style="width: 100%;">
                        <thead>
                            <tr>
                                <th>Sub Komponen</th>
                                <th>Output</th>
                            </tr>
                        </thead>
                        <tbody></tbody>
                    </table>
                </td>
                <td class="text-right">12</td>
                <td>OB</td>
                <td class="text-right">3.000.000,0</td>
            </tr>
            <tr><!----> <!----> <!---->
                <td>
                    03.03.01.01.3506.030 - NGADILUWIH<br>
                    <table class="table-sm mt-2" style="width: 100%;">
                        <thead>
                            <tr>
                                <th>Sub Komponen</th>
                                <th>Output</th>
                            </tr>
                        </thead>
                        <tbody></tbody>
                    </table>
                </td>
                <td class="text-right">12</td>
                <td>OB</td>
                <td class="text-right">3.000.000,0</td>
            </tr>
            <tr><!----> <!----> <!---->
                <td>
                    03.03.01.01.3506.040 - KRAS<br>
                    <table class="table-sm mt-2" style="width: 100%;">
                        <thead>
                            <tr>
                                <th>Sub Komponen</th>
                                <th>Output</th>
                            </tr>
                        </thead>
                        <tbody></tbody>
                    </table>
                </td>
                <td class="text-right">12</td>
                <td>OB</td>
                <td class="text-right">3.000.000,0</td>
            </tr>
            <tr><!----> <!----> <!---->
                <td>
                    03.03.01.01.3506.050 - RINGINREJO<br>
                    <table class="table-sm mt-2" style="width: 100%;">
                        <thead>
                            <tr>
                                <th>Sub Komponen</th>
                                <th>Output</th>
                            </tr>
                        </thead>
                        <tbody></tbody>
                    </table>
                </td>
                <td class="text-right">12</td>
                <td>OB</td>
                <td class="text-right">3.000.000,0</td>
            </tr>
            <tr><!----> <!----> <!---->
                <td>
                    03.03.01.01.3506.060 - KANDAT<br>
                    <table class="table-sm mt-2" style="width: 100%;">
                        <thead>
                            <tr>
                                <th>Sub Komponen</th>
                                <th>Output</th>
                            </tr>
                        </thead>
                        <tbody></tbody>
                    </table>
                </td>
                <td class="text-right">12</td>
                <td>OB</td>
                <td class="text-right">3.000.000,0</td>
            </tr>
            <tr><!----> <!----> <!---->
                <td>
                    03.03.01.01.3506.070 - WATES<br>
                    <table class="table-sm mt-2" style="width: 100%;">
                        <thead>
                            <tr>
                                <th>Sub Komponen</th>
                                <th>Output</th>
                            </tr>
                        </thead>
                        <tbody></tbody>
                    </table>
                </td>
                <td class="text-right">12</td>
                <td>OB</td>
                <td class="text-right">3.000.000,0</td>
            </tr>
            <tr><!----> <!----> <!---->
                <td>
                    03.03.01.01.3506.080 - NGANCAR<br>
                    <table class="table-sm mt-2" style="width: 100%;">
                        <thead>
                            <tr>
                                <th>Sub Komponen</th>
                                <th>Output</th>
                            </tr>
                        </thead>
                        <tbody></tbody>
                    </table>
                </td>
                <td class="text-right">12</td>
                <td>OB</td>
                <td class="text-right">3.000.000,0</td>
            </tr>
            <tr><!----> <!----> <!---->
                <td>
                    03.03.01.01.3506.090 - PLOSOKLATEN<br>
                    <table class="table-sm mt-2" style="width: 100%;">
                        <thead>
                            <tr>
                                <th>Sub Komponen</th>
                                <th>Output</th>
                            </tr>
                        </thead>
                        <tbody></tbody>
                    </table>
                </td>
                <td class="text-right">12</td>
                <td>OB</td>
                <td class="text-right">3.000.000,0</td>
            </tr>
            <tr><!----> <!----> <!---->
                <td>
                    03.03.01.01.3506.100 - GURAH<br>
                    <table class="table-sm mt-2" style="width: 100%;">
                        <thead>
                            <tr>
                                <th>Sub Komponen</th>
                                <th>Output</th>
                            </tr>
                        </thead>
                        <tbody></tbody>
                    </table>
                </td>
                <td class="text-right">12</td>
                <td>OB</td>
                <td class="text-right">3.000.000,0</td>
            </tr>
            <tr><!----> <!----> <!---->
                <td>
                    03.03.01.01.3506.110 - PUNCU<br>
                    <table class="table-sm mt-2" style="width: 100%;">
                        <thead>
                            <tr>
                                <th>Sub Komponen</th>
                                <th>Output</th>
                            </tr>
                        </thead>
                        <tbody></tbody>
                    </table>
                </td>
                <td class="text-right">12</td>
                <td>OB</td>
                <td class="text-right">3.000.000,0</td>
            </tr>
            <tr><!----> <!----> <!---->
                <td>
                    03.03.01.01.3506.120 - KEPUNG<br>
                    <table class="table-sm mt-2" style="width: 100%;">
                        <thead>
                            <tr>
                                <th>Sub Komponen</th>
                                <th>Output</th>
                            </tr>
                        </thead>
                        <tbody></tbody>
                    </table>
                </td>
                <td class="text-right">12</td>
                <td>OB</td>
                <td class="text-right">3.000.000,0</td>
            </tr>
            <tr><!----> <!----> <!---->
                <td>
                    03.03.01.01.3506.130 - KANDANGAN<br>
                    <table class="table-sm mt-2" style="width: 100%;">
                        <thead>
                            <tr>
                                <th>Sub Komponen</th>
                                <th>Output</th>
                            </tr>
                        </thead>
                        <tbody></tbody>
                    </table>
                </td>
                <td class="text-right">12</td>
                <td>OB</td>
                <td class="text-right">3.000.000,0</td>
            </tr>
            <tr><!----> <!----> <!---->
                <td>
                    03.03.01.01.3506.140 - PARE<br>
                    <table class="table-sm mt-2" style="width: 100%;">
                        <thead>
                            <tr>
                                <th>Sub Komponen</th>
                                <th>Output</th>
                            </tr>
                        </thead>
                        <tbody></tbody>
                    </table>
                </td>
                <td class="text-right">12</td>
                <td>OB</td>
                <td class="text-right">3.000.000,0</td>
            </tr>
            <tr><!----> <!----> <!---->
                <td>
                    03.03.01.01.3506.141 - BADAS<br>
                    <table class="table-sm mt-2" style="width: 100%;">
                        <thead>
                            <tr>
                                <th>Sub Komponen</th>
                                <th>Output</th>
                            </tr>
                        </thead>
                        <tbody></tbody>
                    </table>
                </td>
                <td class="text-right">12</td>
                <td>OB</td>
                <td class="text-right">3.000.000,0</td>
            </tr>
            <tr><!----> <!----> <!---->
                <td>
                    03.03.01.01.3506.150 - KUNJANG<br>
                    <table class="table-sm mt-2" style="width: 100%;">
                        <thead>
                            <tr>
                                <th>Sub Komponen</th>
                                <th>Output</th>
                            </tr>
                        </thead>
                        <tbody></tbody>
                    </table>
                </td>
                <td class="text-right">12</td>
                <td>OB</td>
                <td class="text-right">3.000.000,0</td>
            </tr>
            <tr><!----> <!----> <!---->
                <td>
                    03.03.01.01.3506.160 - PLEMAHAN<br>
                    <table class="table-sm mt-2" style="width: 100%;">
                        <thead>
                            <tr>
                                <th>Sub Komponen</th>
                                <th>Output</th>
                            </tr>
                        </thead>
                        <tbody></tbody>
                    </table>
                </td>
                <td class="text-right">12</td>
                <td>OB</td>
                <td class="text-right">3.000.000,0</td>
            </tr>
            <tr><!----> <!----> <!---->
                <td>
                    03.03.01.01.3506.170 - PURWOASRI<br>
                    <table class="table-sm mt-2" style="width: 100%;">
                        <thead>
                            <tr>
                                <th>Sub Komponen</th>
                                <th>Output</th>
                            </tr>
                        </thead>
                        <tbody></tbody>
                    </table>
                </td>
                <td class="text-right">12</td>
                <td>OB</td>
                <td class="text-right">3.000.000,0</td>
            </tr>
            <tr><!----> <!----> <!---->
                <td>
                    03.03.01.01.3506.180 - PAPAR<br>
                    <table class="table-sm mt-2" style="width: 100%;">
                        <thead>
                            <tr>
                                <th>Sub Komponen</th>
                                <th>Output</th>
                            </tr>
                        </thead>
                        <tbody></tbody>
                    </table>
                </td>
                <td class="text-right">12</td>
                <td>OB</td>
                <td class="text-right">3.000.000,0</td>
            </tr>
            <tr><!----> <!----> <!---->
                <td>
                    03.03.01.01.3506.190 - PAGU<br>
                    <table class="table-sm mt-2" style="width: 100%;">
                        <thead>
                            <tr>
                                <th>Sub Komponen</th>
                                <th>Output</th>
                            </tr>
                        </thead>
                        <tbody></tbody>
                    </table>
                </td>
                <td class="text-right">12</td>
                <td>OB</td>
                <td class="text-right">3.000.000,0</td>
            </tr>
            <tr><!----> <!----> <!---->
                <td>
                    03.03.01.01.3506.191 - KAYEN KIDUL<br>
                    <table class="table-sm mt-2" style="width: 100%;">
                        <thead>
                            <tr>
                                <th>Sub Komponen</th>
                                <th>Output</th>
                            </tr>
                        </thead>
                        <tbody></tbody>
                    </table>
                </td>
                <td class="text-right">12</td>
                <td>OB</td>
                <td class="text-right">3.000.000,0</td>
            </tr>
            <tr><!----> <!----> <!---->
                <td>
                    03.03.01.01.3506.200 - GAMPENGREJO<br>
                    <table class="table-sm mt-2" style="width: 100%;">
                        <thead>
                            <tr>
                                <th>Sub Komponen</th>
                                <th>Output</th>
                            </tr>
                        </thead>
                        <tbody></tbody>
                    </table>
                </td>
                <td class="text-right">12</td>
                <td>OB</td>
                <td class="text-right">3.000.000,0</td>
            </tr>
            <tr><!----> <!----> <!---->
                <td>
                    03.03.01.01.3506.201 - NGASEM<br>
                    <table class="table-sm mt-2" style="width: 100%;">
                        <thead>
                            <tr>
                                <th>Sub Komponen</th>
                                <th>Output</th>
                            </tr>
                        </thead>
                        <tbody></tbody>
                    </table>
                </td>
                <td class="text-right">12</td>
                <td>OB</td>
                <td class="text-right">3.000.000,0</td>
            </tr>
            <tr><!----> <!----> <!---->
                <td>
                    03.03.01.01.3506.210 - BANYAKAN<br>
                    <table class="table-sm mt-2" style="width: 100%;">
                        <thead>
                            <tr>
                                <th>Sub Komponen</th>
                                <th>Output</th>
                            </tr>
                        </thead>
                        <tbody></tbody>
                    </table>
                </td>
                <td class="text-right">12</td>
                <td>OB</td>
                <td class="text-right">3.000.000,0</td>
            </tr>
            <tr><!----> <!----> <!---->
                <td>
                    03.03.01.01.3506.220 - GROGOL<br>
                    <table class="table-sm mt-2" style="width: 100%;">
                        <thead>
                            <tr>
                                <th>Sub Komponen</th>
                                <th>Output</th>
                            </tr>
                        </thead>
                        <tbody></tbody>
                    </table>
                </td>
                <td class="text-right">12</td>
                <td>OB</td>
                <td class="text-right">3.000.000,0</td>
            </tr>
            <tr><!----> <!----> <!---->
                <td>
                    03.03.01.01.3506.230 - TAROKAN<br>
                    <table class="table-sm mt-2" style="width: 100%;">
                        <thead>
                            <tr>
                                <th>Sub Komponen</th>
                                <th>Output</th>
                            </tr>
                        </thead>
                        <tbody></tbody>
                    </table>
                </td>
                <td class="text-right">12</td>
                <td>OB</td>
                <td class="text-right">3.000.000,0</td>
            </tr>
            <tr><!----> <!---->
                <td rowspan="26">
                    03.03.01.02 - Pelatihan Tematik Pertanian .
                </td>
                <td>
                    03.03.01.02.3506.010 - MOJO<br>
                    <table class="table-sm mt-2" style="width: 100%;">
                        <thead>
                            <tr>
                                <th>Sub Komponen</th>
                                <th>Output</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td style="white-space: nowrap;">001 - Uang Harian </td>
                                <td style="white-space: nowrap;">20 - OH</td>
                            </tr>
                            <tr>
                                <td style="white-space: nowrap;">002 - Konsumsi </td>
                                <td style="white-space: nowrap;">20 - OH</td>
                            </tr>
                            <tr>
                                <td style="white-space: nowrap;">003 - Bahan Praktek </td>
                                <td style="white-space: nowrap;">1 - Paket</td>
                            </tr>
                        </tbody>
                    </table>
                </td>
                <td class="text-right">1</td>
                <td>Kegiatan</td>
                <td class="text-right">4.500.000,0</td>
            </tr>
            <tr><!----> <!----> <!---->
                <td>
                    03.03.01.02.3506.020 - SEMEN<br>
                    <table class="table-sm mt-2" style="width: 100%;">
                        <thead>
                            <tr>
                                <th>Sub Komponen</th>
                                <th>Output</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td style="white-space: nowrap;">001 - Uang Harian </td>
                                <td style="white-space: nowrap;">20 - OH</td>
                            </tr>
                            <tr>
                                <td style="white-space: nowrap;">002 - Konsumsi </td>
                                <td style="white-space: nowrap;">20 - OH</td>
                            </tr>
                            <tr>
                                <td style="white-space: nowrap;">003 - Bahan Praktek </td>
                                <td style="white-space: nowrap;">1 - Paket</td>
                            </tr>
                        </tbody>
                    </table>
                </td>
                <td class="text-right">1</td>
                <td>Kegiatan</td>
                <td class="text-right">4.500.000,0</td>
            </tr>
            <tr><!----> <!----> <!---->
                <td>
                    03.03.01.02.3506.030 - NGADILUWIH<br>
                    <table class="table-sm mt-2" style="width: 100%;">
                        <thead>
                            <tr>
                                <th>Sub Komponen</th>
                                <th>Output</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td style="white-space: nowrap;">001 - Uang Harian </td>
                                <td style="white-space: nowrap;">20 - OH</td>
                            </tr>
                            <tr>
                                <td style="white-space: nowrap;">002 - Konsumsi </td>
                                <td style="white-space: nowrap;">20 - OH</td>
                            </tr>
                            <tr>
                                <td style="white-space: nowrap;">003 - Bahan Praktek </td>
                                <td style="white-space: nowrap;">1 - Paket</td>
                            </tr>
                        </tbody>
                    </table>
                </td>
                <td class="text-right">1</td>
                <td>Kegiatan</td>
                <td class="text-right">4.500.000,0</td>
            </tr>
            <tr><!----> <!----> <!---->
                <td>
                    03.03.01.02.3506.040 - KRAS<br>
                    <table class="table-sm mt-2" style="width: 100%;">
                        <thead>
                            <tr>
                                <th>Sub Komponen</th>
                                <th>Output</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td style="white-space: nowrap;">001 - Uang Harian </td>
                                <td style="white-space: nowrap;">20 - OH</td>
                            </tr>
                            <tr>
                                <td style="white-space: nowrap;">002 - Konsumsi </td>
                                <td style="white-space: nowrap;">20 - OH</td>
                            </tr>
                            <tr>
                                <td style="white-space: nowrap;">003 - Bahan Praktek </td>
                                <td style="white-space: nowrap;">1 - Paket</td>
                            </tr>
                        </tbody>
                    </table>
                </td>
                <td class="text-right">1</td>
                <td>Kegiatan</td>
                <td class="text-right">4.500.000,0</td>
            </tr>
            <tr><!----> <!----> <!---->
                <td>
                    03.03.01.02.3506.050 - RINGINREJO<br>
                    <table class="table-sm mt-2" style="width: 100%;">
                        <thead>
                            <tr>
                                <th>Sub Komponen</th>
                                <th>Output</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td style="white-space: nowrap;">001 - Uang Harian </td>
                                <td style="white-space: nowrap;">20 - OH</td>
                            </tr>
                            <tr>
                                <td style="white-space: nowrap;">002 - Konsumsi </td>
                                <td style="white-space: nowrap;">20 - OH</td>
                            </tr>
                            <tr>
                                <td style="white-space: nowrap;">003 - Bahan Praktek </td>
                                <td style="white-space: nowrap;">1 - Paket</td>
                            </tr>
                        </tbody>
                    </table>
                </td>
                <td class="text-right">1</td>
                <td>Kegiatan</td>
                <td class="text-right">4.500.000,0</td>
            </tr>
            <tr><!----> <!----> <!---->
                <td>
                    03.03.01.02.3506.060 - KANDAT<br>
                    <table class="table-sm mt-2" style="width: 100%;">
                        <thead>
                            <tr>
                                <th>Sub Komponen</th>
                                <th>Output</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td style="white-space: nowrap;">001 - Uang Harian </td>
                                <td style="white-space: nowrap;">20 - OH</td>
                            </tr>
                            <tr>
                                <td style="white-space: nowrap;">002 - Konsumsi </td>
                                <td style="white-space: nowrap;">20 - OH</td>
                            </tr>
                            <tr>
                                <td style="white-space: nowrap;">003 - Bahan Praktek </td>
                                <td style="white-space: nowrap;">1 - Paket</td>
                            </tr>
                        </tbody>
                    </table>
                </td>
                <td class="text-right">1</td>
                <td>Kegiatan</td>
                <td class="text-right">4.500.000,0</td>
            </tr>
            <tr><!----> <!----> <!---->
                <td>
                    03.03.01.02.3506.070 - WATES<br>
                    <table class="table-sm mt-2" style="width: 100%;">
                        <thead>
                            <tr>
                                <th>Sub Komponen</th>
                                <th>Output</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td style="white-space: nowrap;">001 - Uang Harian </td>
                                <td style="white-space: nowrap;">20 - OH</td>
                            </tr>
                            <tr>
                                <td style="white-space: nowrap;">002 - Konsumsi </td>
                                <td style="white-space: nowrap;">20 - OH</td>
                            </tr>
                            <tr>
                                <td style="white-space: nowrap;">003 - Bahan Praktek </td>
                                <td style="white-space: nowrap;">1 - Paket</td>
                            </tr>
                        </tbody>
                    </table>
                </td>
                <td class="text-right">1</td>
                <td>Kegiatan</td>
                <td class="text-right">4.500.000,0</td>
            </tr>
            <tr><!----> <!----> <!---->
                <td>
                    03.03.01.02.3506.080 - NGANCAR<br>
                    <table class="table-sm mt-2" style="width: 100%;">
                        <thead>
                            <tr>
                                <th>Sub Komponen</th>
                                <th>Output</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td style="white-space: nowrap;">001 - Uang Harian </td>
                                <td style="white-space: nowrap;">20 - OH</td>
                            </tr>
                            <tr>
                                <td style="white-space: nowrap;">002 - Konsumsi </td>
                                <td style="white-space: nowrap;">20 - OH</td>
                            </tr>
                            <tr>
                                <td style="white-space: nowrap;">003 - Bahan Praktek </td>
                                <td style="white-space: nowrap;">1 - Paket</td>
                            </tr>
                        </tbody>
                    </table>
                </td>
                <td class="text-right">1</td>
                <td>Kegiatan</td>
                <td class="text-right">4.500.000,0</td>
            </tr>
            <tr><!----> <!----> <!---->
                <td>
                    03.03.01.02.3506.090 - PLOSOKLATEN<br>
                    <table class="table-sm mt-2" style="width: 100%;">
                        <thead>
                            <tr>
                                <th>Sub Komponen</th>
                                <th>Output</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td style="white-space: nowrap;">001 - Uang Harian </td>
                                <td style="white-space: nowrap;">20 - OH</td>
                            </tr>
                            <tr>
                                <td style="white-space: nowrap;">002 - Konsumsi </td>
                                <td style="white-space: nowrap;">20 - OH</td>
                            </tr>
                            <tr>
                                <td style="white-space: nowrap;">003 - Bahan Praktek </td>
                                <td style="white-space: nowrap;">1 - Paket</td>
                            </tr>
                        </tbody>
                    </table>
                </td>
                <td class="text-right">1</td>
                <td>Kegiatan</td>
                <td class="text-right">4.500.000,0</td>
            </tr>
            <tr><!----> <!----> <!---->
                <td>
                    03.03.01.02.3506.100 - GURAH<br>
                    <table class="table-sm mt-2" style="width: 100%;">
                        <thead>
                            <tr>
                                <th>Sub Komponen</th>
                                <th>Output</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td style="white-space: nowrap;">001 - Uang Harian </td>
                                <td style="white-space: nowrap;">20 - OH</td>
                            </tr>
                            <tr>
                                <td style="white-space: nowrap;">002 - Konsumsi </td>
                                <td style="white-space: nowrap;">20 - OH</td>
                            </tr>
                            <tr>
                                <td style="white-space: nowrap;">003 - Bahan Praktek </td>
                                <td style="white-space: nowrap;">1 - Paket</td>
                            </tr>
                        </tbody>
                    </table>
                </td>
                <td class="text-right">1</td>
                <td>Kegiatan</td>
                <td class="text-right">4.500.000,0</td>
            </tr>
            <tr><!----> <!----> <!---->
                <td>
                    03.03.01.02.3506.110 - PUNCU<br>
                    <table class="table-sm mt-2" style="width: 100%;">
                        <thead>
                            <tr>
                                <th>Sub Komponen</th>
                                <th>Output</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td style="white-space: nowrap;">001 - Uang Harian </td>
                                <td style="white-space: nowrap;">20 - OH</td>
                            </tr>
                            <tr>
                                <td style="white-space: nowrap;">002 - Konsumsi </td>
                                <td style="white-space: nowrap;">20 - OH</td>
                            </tr>
                            <tr>
                                <td style="white-space: nowrap;">003 - Bahan Praktek </td>
                                <td style="white-space: nowrap;">1 - Paket</td>
                            </tr>
                        </tbody>
                    </table>
                </td>
                <td class="text-right">1</td>
                <td>Kegiatan</td>
                <td class="text-right">4.500.000,0</td>
            </tr>
            <tr><!----> <!----> <!---->
                <td>
                    03.03.01.02.3506.120 - KEPUNG<br>
                    <table class="table-sm mt-2" style="width: 100%;">
                        <thead>
                            <tr>
                                <th>Sub Komponen</th>
                                <th>Output</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td style="white-space: nowrap;">001 - Uang Harian </td>
                                <td style="white-space: nowrap;">20 - OH</td>
                            </tr>
                            <tr>
                                <td style="white-space: nowrap;">002 - Konsumsi </td>
                                <td style="white-space: nowrap;">20 - OH</td>
                            </tr>
                            <tr>
                                <td style="white-space: nowrap;">003 - Bahan Praktek </td>
                                <td style="white-space: nowrap;">1 - Paket</td>
                            </tr>
                        </tbody>
                    </table>
                </td>
                <td class="text-right">1</td>
                <td>Kegiatan</td>
                <td class="text-right">4.500.000,0</td>
            </tr>
            <tr><!----> <!----> <!---->
                <td>
                    03.03.01.02.3506.130 - KANDANGAN<br>
                    <table class="table-sm mt-2" style="width: 100%;">
                        <thead>
                            <tr>
                                <th>Sub Komponen</th>
                                <th>Output</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td style="white-space: nowrap;">001 - Uang Harian </td>
                                <td style="white-space: nowrap;">20 - OH</td>
                            </tr>
                            <tr>
                                <td style="white-space: nowrap;">002 - Konsumsi </td>
                                <td style="white-space: nowrap;">20 - OH</td>
                            </tr>
                            <tr>
                                <td style="white-space: nowrap;">003 - Bahan Praktek </td>
                                <td style="white-space: nowrap;">1 - Paket</td>
                            </tr>
                        </tbody>
                    </table>
                </td>
                <td class="text-right">1</td>
                <td>Kegiatan</td>
                <td class="text-right">4.500.000,0</td>
            </tr>
            <tr><!----> <!----> <!---->
                <td>
                    03.03.01.02.3506.140 - PARE<br>
                    <table class="table-sm mt-2" style="width: 100%;">
                        <thead>
                            <tr>
                                <th>Sub Komponen</th>
                                <th>Output</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td style="white-space: nowrap;">001 - Uang Harian </td>
                                <td style="white-space: nowrap;">20 - OH</td>
                            </tr>
                            <tr>
                                <td style="white-space: nowrap;">002 - Konsumsi </td>
                                <td style="white-space: nowrap;">20 - OH</td>
                            </tr>
                            <tr>
                                <td style="white-space: nowrap;">003 - Bahan Praktek </td>
                                <td style="white-space: nowrap;">1 - Paket</td>
                            </tr>
                        </tbody>
                    </table>
                </td>
                <td class="text-right">1</td>
                <td>Kegiatan</td>
                <td class="text-right">4.500.000,0</td>
            </tr>
            <tr><!----> <!----> <!---->
                <td>
                    03.03.01.02.3506.141 - BADAS<br>
                    <table class="table-sm mt-2" style="width: 100%;">
                        <thead>
                            <tr>
                                <th>Sub Komponen</th>
                                <th>Output</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td style="white-space: nowrap;">001 - Uang Harian </td>
                                <td style="white-space: nowrap;">20 - OH</td>
                            </tr>
                            <tr>
                                <td style="white-space: nowrap;">002 - Konsumsi </td>
                                <td style="white-space: nowrap;">20 - OH</td>
                            </tr>
                            <tr>
                                <td style="white-space: nowrap;">003 - Bahan Praktek </td>
                                <td style="white-space: nowrap;">1 - Paket</td>
                            </tr>
                        </tbody>
                    </table>
                </td>
                <td class="text-right">1</td>
                <td>Kegiatan</td>
                <td class="text-right">4.500.000,0</td>
            </tr>
            <tr><!----> <!----> <!---->
                <td>
                    03.03.01.02.3506.150 - KUNJANG<br>
                    <table class="table-sm mt-2" style="width: 100%;">
                        <thead>
                            <tr>
                                <th>Sub Komponen</th>
                                <th>Output</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td style="white-space: nowrap;">001 - Uang Harian </td>
                                <td style="white-space: nowrap;">20 - OH</td>
                            </tr>
                            <tr>
                                <td style="white-space: nowrap;">002 - Konsumsi </td>
                                <td style="white-space: nowrap;">20 - OH</td>
                            </tr>
                            <tr>
                                <td style="white-space: nowrap;">003 - Bahan Praktek </td>
                                <td style="white-space: nowrap;">1 - Paket</td>
                            </tr>
                        </tbody>
                    </table>
                </td>
                <td class="text-right">1</td>
                <td>Kegiatan</td>
                <td class="text-right">4.500.000,0</td>
            </tr>
            <tr><!----> <!----> <!---->
                <td>
                    03.03.01.02.3506.160 - PLEMAHAN<br>
                    <table class="table-sm mt-2" style="width: 100%;">
                        <thead>
                            <tr>
                                <th>Sub Komponen</th>
                                <th>Output</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td style="white-space: nowrap;">001 - Uang Harian </td>
                                <td style="white-space: nowrap;">20 - OH</td>
                            </tr>
                            <tr>
                                <td style="white-space: nowrap;">002 - Konsumsi </td>
                                <td style="white-space: nowrap;">20 - OH</td>
                            </tr>
                            <tr>
                                <td style="white-space: nowrap;">003 - Bahan Praktek </td>
                                <td style="white-space: nowrap;">1 - Paket</td>
                            </tr>
                        </tbody>
                    </table>
                </td>
                <td class="text-right">1</td>
                <td>Kegiatan</td>
                <td class="text-right">4.500.000,0</td>
            </tr>
            <tr><!----> <!----> <!---->
                <td>
                    03.03.01.02.3506.170 - PURWOASRI<br>
                    <table class="table-sm mt-2" style="width: 100%;">
                        <thead>
                            <tr>
                                <th>Sub Komponen</th>
                                <th>Output</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td style="white-space: nowrap;">001 - Uang Harian </td>
                                <td style="white-space: nowrap;">20 - OH</td>
                            </tr>
                            <tr>
                                <td style="white-space: nowrap;">002 - Konsumsi </td>
                                <td style="white-space: nowrap;">20 - OH</td>
                            </tr>
                            <tr>
                                <td style="white-space: nowrap;">003 - Bahan Praktek </td>
                                <td style="white-space: nowrap;">1 - Paket</td>
                            </tr>
                        </tbody>
                    </table>
                </td>
                <td class="text-right">1</td>
                <td>Kegiatan</td>
                <td class="text-right">4.500.000,0</td>
            </tr>
            <tr><!----> <!----> <!---->
                <td>
                    03.03.01.02.3506.180 - PAPAR<br>
                    <table class="table-sm mt-2" style="width: 100%;">
                        <thead>
                            <tr>
                                <th>Sub Komponen</th>
                                <th>Output</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td style="white-space: nowrap;">001 - Uang Harian </td>
                                <td style="white-space: nowrap;">20 - OH</td>
                            </tr>
                            <tr>
                                <td style="white-space: nowrap;">002 - Konsumsi </td>
                                <td style="white-space: nowrap;">20 - OH</td>
                            </tr>
                            <tr>
                                <td style="white-space: nowrap;">003 - Bahan Praktek </td>
                                <td style="white-space: nowrap;">1 - Paket</td>
                            </tr>
                        </tbody>
                    </table>
                </td>
                <td class="text-right">1</td>
                <td>Kegiatan</td>
                <td class="text-right">4.500.000,0</td>
            </tr>
            <tr><!----> <!----> <!---->
                <td>
                    03.03.01.02.3506.190 - PAGU<br>
                    <table class="table-sm mt-2" style="width: 100%;">
                        <thead>
                            <tr>
                                <th>Sub Komponen</th>
                                <th>Output</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td style="white-space: nowrap;">001 - Uang Harian </td>
                                <td style="white-space: nowrap;">20 - OH</td>
                            </tr>
                            <tr>
                                <td style="white-space: nowrap;">002 - Konsumsi </td>
                                <td style="white-space: nowrap;">20 - OH</td>
                            </tr>
                            <tr>
                                <td style="white-space: nowrap;">003 - Bahan Praktek </td>
                                <td style="white-space: nowrap;">1 - Paket</td>
                            </tr>
                        </tbody>
                    </table>
                </td>
                <td class="text-right">1</td>
                <td>Kegiatan</td>
                <td class="text-right">4.500.000,0</td>
            </tr>
            <tr><!----> <!----> <!---->
                <td>
                    03.03.01.02.3506.191 - KAYEN KIDUL<br>
                    <table class="table-sm mt-2" style="width: 100%;">
                        <thead>
                            <tr>
                                <th>Sub Komponen</th>
                                <th>Output</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td style="white-space: nowrap;">001 - Uang Harian </td>
                                <td style="white-space: nowrap;">20 - OH</td>
                            </tr>
                            <tr>
                                <td style="white-space: nowrap;">002 - Konsumsi </td>
                                <td style="white-space: nowrap;">20 - OH</td>
                            </tr>
                            <tr>
                                <td style="white-space: nowrap;">003 - Bahan Praktek </td>
                                <td style="white-space: nowrap;">1 - Paket</td>
                            </tr>
                        </tbody>
                    </table>
                </td>
                <td class="text-right">1</td>
                <td>Kegiatan</td>
                <td class="text-right">4.500.000,0</td>
            </tr>
            <tr><!----> <!----> <!---->
                <td>
                    03.03.01.02.3506.200 - GAMPENGREJO<br>
                    <table class="table-sm mt-2" style="width: 100%;">
                        <thead>
                            <tr>
                                <th>Sub Komponen</th>
                                <th>Output</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td style="white-space: nowrap;">001 - Uang Harian </td>
                                <td style="white-space: nowrap;">20 - OH</td>
                            </tr>
                            <tr>
                                <td style="white-space: nowrap;">002 - Konsumsi </td>
                                <td style="white-space: nowrap;">20 - OH</td>
                            </tr>
                            <tr>
                                <td style="white-space: nowrap;">003 - Bahan Praktek </td>
                                <td style="white-space: nowrap;">1 - Paket</td>
                            </tr>
                        </tbody>
                    </table>
                </td>
                <td class="text-right">1</td>
                <td>Kegiatan</td>
                <td class="text-right">4.500.000,0</td>
            </tr>
            <tr><!----> <!----> <!---->
                <td>
                    03.03.01.02.3506.201 - NGASEM<br>
                    <table class="table-sm mt-2" style="width: 100%;">
                        <thead>
                            <tr>
                                <th>Sub Komponen</th>
                                <th>Output</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td style="white-space: nowrap;">001 - Uang Harian </td>
                                <td style="white-space: nowrap;">20 - OH</td>
                            </tr>
                            <tr>
                                <td style="white-space: nowrap;">002 - Konsumsi </td>
                                <td style="white-space: nowrap;">20 - OH</td>
                            </tr>
                            <tr>
                                <td style="white-space: nowrap;">003 - Bahan Praktek </td>
                                <td style="white-space: nowrap;">1 - Paket</td>
                            </tr>
                        </tbody>
                    </table>
                </td>
                <td class="text-right">1</td>
                <td>Kegiatan</td>
                <td class="text-right">4.500.000,0</td>
            </tr>
            <tr><!----> <!----> <!---->
                <td>
                    03.03.01.02.3506.210 - BANYAKAN<br>
                    <table class="table-sm mt-2" style="width: 100%;">
                        <thead>
                            <tr>
                                <th>Sub Komponen</th>
                                <th>Output</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td style="white-space: nowrap;">001 - Uang Harian </td>
                                <td style="white-space: nowrap;">20 - OH</td>
                            </tr>
                            <tr>
                                <td style="white-space: nowrap;">002 - Konsumsi </td>
                                <td style="white-space: nowrap;">20 - OH</td>
                            </tr>
                            <tr>
                                <td style="white-space: nowrap;">003 - Bahan Praktek </td>
                                <td style="white-space: nowrap;">1 - Paket</td>
                            </tr>
                        </tbody>
                    </table>
                </td>
                <td class="text-right">1</td>
                <td>Kegiatan</td>
                <td class="text-right">4.500.000,0</td>
            </tr>
            <tr><!----> <!----> <!---->
                <td>
                    03.03.01.02.3506.220 - GROGOL<br>
                    <table class="table-sm mt-2" style="width: 100%;">
                        <thead>
                            <tr>
                                <th>Sub Komponen</th>
                                <th>Output</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td style="white-space: nowrap;">001 - Uang Harian </td>
                                <td style="white-space: nowrap;">20 - OH</td>
                            </tr>
                            <tr>
                                <td style="white-space: nowrap;">002 - Konsumsi </td>
                                <td style="white-space: nowrap;">20 - OH</td>
                            </tr>
                            <tr>
                                <td style="white-space: nowrap;">003 - Bahan Praktek </td>
                                <td style="white-space: nowrap;">1 - Paket</td>
                            </tr>
                        </tbody>
                    </table>
                </td>
                <td class="text-right">1</td>
                <td>Kegiatan</td>
                <td class="text-right">4.500.000,0</td>
            </tr>
            <tr><!----> <!----> <!---->
                <td>
                    03.03.01.02.3506.230 - TAROKAN<br>
                    <table class="table-sm mt-2" style="width: 100%;">
                        <thead>
                            <tr>
                                <th>Sub Komponen</th>
                                <th>Output</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td style="white-space: nowrap;">001 - Uang Harian </td>
                                <td style="white-space: nowrap;">20 - OH</td>
                            </tr>
                            <tr>
                                <td style="white-space: nowrap;">002 - Konsumsi </td>
                                <td style="white-space: nowrap;">20 - OH</td>
                            </tr>
                            <tr>
                                <td style="white-space: nowrap;">003 - Bahan Praktek </td>
                                <td style="white-space: nowrap;">1 - Paket</td>
                            </tr>
                        </tbody>
                    </table>
                </td>
                <td class="text-right">1</td>
                <td>Kegiatan</td>
                <td class="text-right">4.500.000,0</td>
            </tr>
        </tbody>
        <tbody>
            <tr>
                <td rowspan="5" class="text-center">2.
                </td>
                <td rowspan="5">
                    03.03.02 - Sekolah Lapang Tematik.
                </td>
                <td rowspan="1">
                    03.03.02.01 - Sosialisasi .
                </td>
                <td>
                    03.03.02.01.00079 - Dinas Pertanian Dan Perkebunan - Kab. Kediri<br>
                    <table class="table-sm mt-2" style="width: 100%;">
                        <thead>
                            <tr>
                                <th>Sub Komponen</th>
                                <th>Output</th>
                            </tr>
                        </thead>
                        <tbody></tbody>
                    </table>
                </td>
                <td class="text-right">1</td>
                <td>Paket</td>
                <td class="text-right">15.600.000,0</td>
            </tr>
            <tr><!----> <!---->
                <td rowspan="1">
                    03.03.02.02 - Rembug Tani .
                </td>
                <td>
                    03.03.02.02.00079 - Dinas Pertanian Dan Perkebunan - Kab. Kediri<br>
                    <table class="table-sm mt-2" style="width: 100%;">
                        <thead>
                            <tr>
                                <th>Sub Komponen</th>
                                <th>Output</th>
                            </tr>
                        </thead>
                        <tbody></tbody>
                    </table>
                </td>
                <td class="text-right">1</td>
                <td>Paket</td>
                <td class="text-right">15.600.000,0</td>
            </tr>
            <tr><!----> <!---->
                <td rowspan="1">
                    03.03.02.03 - Kursus Tani .
                </td>
                <td>
                    03.03.02.03.00079 - Dinas Pertanian Dan Perkebunan - Kab. Kediri<br>
                    <table class="table-sm mt-2" style="width: 100%;">
                        <thead>
                            <tr>
                                <th>Sub Komponen</th>
                                <th>Output</th>
                            </tr>
                        </thead>
                        <tbody></tbody>
                    </table>
                </td>
                <td class="text-right">1</td>
                <td>Paket</td>
                <td class="text-right">48.000.000,0</td>
            </tr>
            <tr><!----> <!---->
                <td rowspan="1">
                    03.03.02.04 - Farm Field Day .
                </td>
                <td>
                    03.03.02.04.00079 - Dinas Pertanian Dan Perkebunan - Kab. Kediri<br>
                    <table class="table-sm mt-2" style="width: 100%;">
                        <thead>
                            <tr>
                                <th>Sub Komponen</th>
                                <th>Output</th>
                            </tr>
                        </thead>
                        <tbody></tbody>
                    </table>
                </td>
                <td class="text-right">1</td>
                <td>Paket</td>
                <td class="text-right">15.600.000,0</td>
            </tr>
            <tr><!----> <!---->
                <td rowspan="1">
                    03.03.02.05 - Pengawalan dan Pendampingan .
                </td>
                <td>
                    03.03.02.05.00079 - Dinas Pertanian Dan Perkebunan - Kab. Kediri<br>
                    <table class="table-sm mt-2" style="width: 100%;">
                        <thead>
                            <tr>
                                <th>Sub Komponen</th>
                                <th>Output</th>
                            </tr>
                        </thead>
                        <tbody></tbody>
                    </table>
                </td>
                <td class="text-right">1</td>
                <td>Paket</td>
                <td class="text-right">5.200.000,0</td>
            </tr>
        </tbody>
        <tbody>
            <tr class="bg-gray-lighter">
                <td colspan="6" class="text-right"><strong>Total</strong></td>
                <td class="text-right">295.000.000,0</td>
            </tr>
        </tbody>
    </table>
</div>