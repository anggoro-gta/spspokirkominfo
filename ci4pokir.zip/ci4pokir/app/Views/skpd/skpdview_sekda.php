<?= $this->extend('layouts/template'); ?>

<?= $this->section('content'); ?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">

        <!-- Small boxes (Stat box) -->
        <div class="row">
            <div class="col-lg-3 col-6">
                <!-- small box -->
                <div class="small-box bg-info">
                    <div class="inner">
                        <h3 id="header-calskpd" style="font-size: 2.1vw"><sup style="font-size: 10px">Rp</sup><?= $total; ?></h3>
                        <p>Total</p>
                    </div>
                    <a href="#" class="small-box-footer">Details <i class="fas fa-arrow-circle-right"></i></a>
                </div>
            </div>
            <!-- ./col -->
            <div class="col-lg-3 col-6">
                <!-- small box -->
                <div class="small-box bg-success">
                    <div class="inner">
                        <h3 id="header-calskpd" style="font-size: 2.1vw"><sup style="font-size: 10px">Rp</sup><?= $realisasi; ?></h3>
                        <p>lengkap</p>
                    </div>
                    <a href="#" class="small-box-footer">Details <i class="fas fa-arrow-circle-right"></i></a>
                </div>
            </div>
            <!-- ./col -->
            <div class="col-lg-3 col-6">
                <!-- small box -->
                <div class="small-box bg-warning">
                    <div class="inner">
                        <h3 id="header-calskpd" style="font-size: 2.1vw"><sup style="font-size: 10px">Rp</sup><?= $akomodir; ?></h3>
                        <p>kurang lengkap</p>
                    </div>
                    <a href="#" class="small-box-footer">Details <i class="fas fa-arrow-circle-right"></i></a>
                </div>
            </div>
            <!-- ./col -->
            <div class="col-lg-3 col-6">
                <!-- small box -->
                <div class="small-box bg-danger">
                    <div class="inner">
                        <h3 id="header-calskpd" style="font-size: 2.1vw"><sup style="font-size: 10px">Rp</sup><?= $tdk_akomodir; ?></h3>
                        <p>tidak lengkap</p>
                    </div>
                    <a href="#" class="small-box-footer">Details <i class="fas fa-arrow-circle-right"></i></a>
                </div>
            </div>
            <!-- ./col -->
            <div class="col-lg-3 col-6">
                <!-- small box -->
                <div class="small-box bg-info">
                    <div class="inner">
                        <h3 id="header-calskpd" style="font-size: 2.1vw"><?= $persentase_status_usulan; ?></h3>
                        <p>Persentase</p>
                    </div>
                    <a href="#" class="small-box-footer">Details <i class="fas fa-arrow-circle-right"></i></a>
                </div>
            </div>
        </div>

        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1><?= $usulan[0]['skpd']; ?></h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="#">Data</a></li>
                        <li class="breadcrumb-item active">Pokir</li>
                    </ol>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>
    <!-- Main content -->

    <?php $hitungdprd = count($usulan); ?>

    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <!-- <a href="#"><button type="button" class="btn btn-block btn-primary"><i class="fas fa-plus-circle"></i> Tambah Data User</button></a> -->
                    <div class="card">
                        <!-- /.card-header -->
                        <div class="card-body">
                            <table id="example1" class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>klasifikasi</th>
                                        <th>Usulan</th>
                                        <th>Alamat</th>
                                        <th>Volume</th>
                                        <th>Pagu</th>
                                        <th>Pengusul</th>
                                        <th>Fraksi</th>
                                        <th>Keterangan</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php for ($i = 0; $i < $hitungdprd; $i++) : ?>
                                        <tr>
                                            <?php if ($usulan[$i]['status_usulan'] == 3) {
                                            ?>
                                                <td bgcolor="red"><?= $i + 1; ?></td>
                                                <?php if ($usulan[$i]['note_sekda'] == 'perekonomian') { ?>
                                                    <td bgcolor="red">perekonomian</td>
                                                <?php } else { ?>
                                                    <td bgcolor="red">kesra</td>
                                                <?php } ?>
                                                <td bgcolor="red"><?= $usulan[$i]['kegiatan']; ?></td>
                                                <td bgcolor="red"><?= $usulan[$i]['alamat']; ?></td>
                                                <td bgcolor="red"><?= $usulan[$i]['volume']; ?></td>
                                                <td align="right" bgcolor="red"><?= number_format($usulan[$i]['nilai']); ?></td>
                                                <td bgcolor="red"><?= $usulan[$i]['pengusul']; ?></td>
                                                <td bgcolor="red"><?= $usulan[$i]['fraksi']; ?></td>
                                                <td bgcolor="red"><?= $usulan[$i]['keterangan']; ?></td>
                                                <td bgcolor="red">
                                                    <?php if ($state_usulan == '1') { ?>
                                                        <form action="">
                                                            <a onclick="showdetailsss('<?= $usulan[$i]['id']; ?>')" class="btn btn-info btn-sm" href="#" data-toggle="modal">
                                                                <i class="fa fa-exclamation-triangle">
                                                                </i>
                                                                Verifikasi
                                                            </a>
                                                        </form>
                                                        <br>
                                                        <form action="">
                                                            <a onclick="showdetailstatus('<?= $usulan[$i]['id']; ?>')" class="btn btn-success btn-sm" href="#" data-toggle="modal">
                                                                <i class="fas fa-edit">
                                                                </i>
                                                                edit status
                                                            </a>
                                                        </form>
                                                    <?php } else { ?>
                                                    <?php } ?>
                                                </td>
                                            <?php } else if ($usulan[$i]['status_usulan'] == 2) { ?>
                                                <td bgcolor="yellow"><?= $i + 1; ?></td>
                                                <?php if ($usulan[$i]['note_sekda'] == 'perekonomian') { ?>
                                                    <td bgcolor="yellow">perekonomian</td>
                                                <?php } else { ?>
                                                    <td bgcolor="yellow">kesra</td>
                                                <?php } ?>
                                                <td bgcolor="yellow"><?= $usulan[$i]['kegiatan']; ?></td>
                                                <td bgcolor="yellow"><?= $usulan[$i]['alamat']; ?></td>
                                                <td bgcolor="yellow"><?= $usulan[$i]['volume']; ?></td>
                                                <td align="right" bgcolor="yellow"><?= number_format($usulan[$i]['nilai']); ?></td>
                                                <td bgcolor="yellow"><?= $usulan[$i]['pengusul']; ?></td>
                                                <td bgcolor="yellow"><?= $usulan[$i]['fraksi']; ?></td>
                                                <td bgcolor="yellow"><?= $usulan[$i]['keterangan']; ?></td>
                                                <td bgcolor="yellow">
                                                    <?php if ($state_usulan == '1') { ?>
                                                        <form action="">
                                                            <a onclick="showdetailsss('<?= $usulan[$i]['id']; ?>')" class="btn btn-info btn-sm" href="#" data-toggle="modal">
                                                                <i class="fa fa-exclamation-triangle">
                                                                </i>
                                                                Verifikasi
                                                            </a>
                                                        </form>
                                                        <br>
                                                        <form action="">
                                                            <a onclick="showdetailstatus('<?= $usulan[$i]['id']; ?>')" class="btn btn-success btn-sm" href="#" data-toggle="modal">
                                                                <i class="fas fa-edit">
                                                                </i>
                                                                edit status
                                                            </a>
                                                        </form>
                                                    <?php } else { ?>
                                                    <?php } ?>
                                                </td>
                                            <?php } else if ($usulan[$i]['status_usulan'] == 1) { ?>
                                                <td bgcolor="green"><?= $i + 1; ?></td>
                                                <?php if ($usulan[$i]['note_sekda'] == 'perekonomian') { ?>
                                                    <td bgcolor="green">perekonomian</td>
                                                <?php } else { ?>
                                                    <td bgcolor="green">kesra</td>
                                                <?php } ?>
                                                <td bgcolor="green"><?= $usulan[$i]['kegiatan']; ?></td>
                                                <td bgcolor="green"><?= $usulan[$i]['alamat']; ?></td>
                                                <td bgcolor="green"><?= $usulan[$i]['volume']; ?></td>
                                                <td align="right" bgcolor="green"><?= number_format($usulan[$i]['nilai']); ?></td>
                                                <td bgcolor="green"><?= $usulan[$i]['pengusul']; ?></td>
                                                <td bgcolor="green"><?= $usulan[$i]['fraksi']; ?></td>
                                                <td bgcolor="green"><?= $usulan[$i]['keterangan']; ?></td>
                                                <td bgcolor="green">
                                                    <?php if ($state_usulan == '1') { ?>
                                                        <form action="">
                                                            <a onclick="showdetailsss('<?= $usulan[$i]['id']; ?>')" class="btn btn-info btn-sm" href="#" data-toggle="modal">
                                                                <i class="fa fa-exclamation-triangle">
                                                                </i>
                                                                Verifikasi
                                                            </a>
                                                        </form>
                                                        <br>
                                                        <form action="">
                                                            <a onclick="showdetailstatus('<?= $usulan[$i]['id']; ?>')" class="btn btn-success btn-sm" href="#" data-toggle="modal">
                                                                <i class="fas fa-edit">
                                                                </i>
                                                                edit status
                                                            </a>
                                                        </form>
                                                    <?php } else { ?>
                                                    <?php } ?>
                                                </td>
                                            <?php } else if ($usulan[$i]['status_usulan'] == 99) { ?>
                                                <td bgcolor="white"><?= $i + 1; ?></td>
                                                <?php if ($usulan[$i]['note_sekda'] == 'perekonomian') { ?>
                                                    <td bgcolor="white">perekonomian</td>
                                                <?php } else { ?>
                                                    <td bgcolor="white">kesra</td>
                                                <?php } ?>
                                                <td bgcolor="white"><?= $usulan[$i]['kegiatan']; ?></td>
                                                <td bgcolor="white"><?= $usulan[$i]['alamat']; ?></td>
                                                <td bgcolor="white"><?= $usulan[$i]['volume']; ?></td>
                                                <td align="right" bgcolor="white"><?= number_format($usulan[$i]['nilai']); ?></td>
                                                <td bgcolor="white"><?= $usulan[$i]['pengusul']; ?></td>
                                                <td bgcolor="white"><?= $usulan[$i]['fraksi']; ?></td>
                                                <td bgcolor="white"><?= $usulan[$i]['keterangan']; ?></td>
                                                <td bgcolor="white">
                                                    <?php if ($state_usulan == '1') { ?>
                                                        <form action="">
                                                            <a onclick="showdetailsss('<?= $usulan[$i]['id']; ?>')" class="btn btn-info btn-sm" href="#" data-toggle="modal">
                                                                <i class="fa fa-exclamation-triangle">
                                                                </i>
                                                                Verifikasi
                                                            </a>
                                                        </form>
                                                        <br>
                                                        <form action="">
                                                            <a onclick="showdetailstatus('<?= $usulan[$i]['id']; ?>')" class="btn btn-success btn-sm" href="#" data-toggle="modal">
                                                                <i class="fas fa-edit">
                                                                </i>
                                                                edit status
                                                            </a>
                                                        </form>
                                                    <?php } else { ?>
                                                    <?php } ?>
                                                </td>
                                            <?php } ?>
                                        </tr>
                                    <?php endfor; ?>
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <th>#</th>
                                        <th>klasifikasi</th>
                                        <th>Usulan</th>
                                        <th>Alamat</th>
                                        <th>Volume</th>
                                        <th>Pagu</th>
                                        <th>Pengusul</th>
                                        <th>Fraksi</th>
                                        <th>Keterangan</th>
                                        <th>Aksi</th>
                                    </tr>
                                </tfoot>
                            </table>

                            <div class="card-header">
                                <h3 class="card-title">Information Table</h3>
                            </div>
                            <!-- /.card-header -->
                            <div class="card-body table-responsive p-0">
                                <table class="table table-hover text-nowrap">
                                    <thead>
                                        <tr>
                                            <th>Warna</th>
                                            <th>Keterangan</th>
                                            <th>Total</th>

                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td bgcolor="red" width="5px"></td>
                                            <td>tidak lengkap(merah)</td>
                                            <td align="right"><?= $tdk_akomodir; ?></td>
                                        </tr>
                                        <tr>
                                            <td bgcolor="yellow" width="5px"></td>
                                            <td>kurang lengkap (kuning)</td>
                                            <td align="right"><?= $akomodir; ?></td>
                                        </tr>
                                        <tr>
                                            <td bgcolor="green" width="5px"></td>
                                            <td>lengkap (hijau)</td>
                                            <td align="right"><?= $realisasi; ?></td>
                                        </tr>
                                        <tr>
                                            <td bgcolor="white" width="5px"></td>
                                            <td>Belum ada kejelasan</td>
                                            <td align="right"><?= $tdk_warna; ?></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                            <!-- /.card-body -->

                        </div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                </div>
                <!-- /.col -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
    </section>
    <!-- /.content -->

    <!-- MODAL VERIFIKASI  -->
    <div class="modal fade" id="modal-isian-edit">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Verifikasi Usulan</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>

                <form action="/userskpd/saveeditskpd" method="post" enctype="multipart/form-data">
                    <?= csrf_field(); ?>
                    <div class="card-body">
                        <input type="hidden" class="form-control" id="id_usulan" name="id_usulan" required>
                        <div class="form-group">
                            <label>Catatan SKPD</label>
                            <input type="text" class="form-control" id="catatan_skpd" name="catatan_skpd" required>
                        </div>
                        <div class="form-group">
                            <label>Status Usulan</label>
                            <select class="form-control select2 selectstatus" name="status_usulan" id="status_usulan" style="width: 100%;" required>

                            </select>
                        </div>
                    </div>
                    <!-- /.card-body -->

                    <div class="modal-footer justify-content-between">
                        <!-- <button type="button" class="btn btn-default" data-dismiss="modal">Close</button> -->
                        <button type="submit" class="btn btn-primary"><i class="fas fa-edit"></i> Ubah</button>
                        <!-- <button type="button" class="btn btn-primary">Save changes</button> -->
                    </div>
                </form>
            </div>
            <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </div>
    <!-- /.modal -->

    <!-- MODAL EDIT STATUS  -->
    <div class="modal fade" id="modal-isian-status">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Ubah Status Usulan</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>

                <form action="/userskpd/saveeditskpdstatususulan" method="post" enctype="multipart/form-data">
                    <?= csrf_field(); ?>
                    <div class="card-body">
                        <input type="hidden" class="form-control" id="id_usulan_indeks" name="id_usulan_indeks" required>
                        <div class="form-group">
                            <label>Keterangan</label>
                            <input type="text" class="form-control" id="keterangan" name="keterangan" placeholder="isi keterangan nya" required>
                        </div>
                        <div class="form-group">
                            <label>Indeks Kelengkapan</label>
                            <input type="text" class="form-control" id="indeks_keleng" name="indeks_keleng" placeholder="0-1" required>
                        </div>
                        <div class="form-group">
                            <label>Status Usulan</label>
                            <select class="form-control select2 selectstatusverifikasi" name="status_usulan_stat" id="status_usulan_stat" style="width: 100%;" required>

                            </select>
                        </div>
                    </div>
                    <!-- /.card-body -->

                    <div class="modal-footer justify-content-between">
                        <!-- <button type="button" class="btn btn-default" data-dismiss="modal">Close</button> -->
                        <button type="submit" class="btn btn-primary"><i class="fas fa-edit"></i> Ubah</button>
                        <!-- <button type="button" class="btn btn-primary">Save changes</button> -->
                    </div>
                </form>
            </div>
            <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </div>
    <!-- /.modal -->

</div>
<!-- /.content-wrapper -->

<!-- Back to top button -->
<button type="button" class="btn btn-danger btn-floating btn-lg" id="btn-back-to-top">
    <i class="fas fa-arrow-up"></i>
</button>
<?= $this->endSection(); ?>

<?= $this->section('javascriptkhusus'); ?>
<script>
    $(function() {
        $("#example1").DataTable({
            // "lengthChange": true,
            "responsive": true,
            "autoWidth": false,
            "ordering": false,
            "buttons": ["copy", "csv", "excel", "pdf", "print", "colvis"],
            "lengthMenu": [
                [10, 25, 50, -1],
                [10, 25, 50, "All"]
            ]
        }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
    });

    const liskpd = document.querySelector('.li-skpd');
    const ahrefskpd = document.querySelector('.ahref-skpd');
    const ahrefuserskpd = document.querySelector('.ahref-skpdusul');

    liskpd.classList.add("menu-open");
    ahrefskpd.classList.add("active");
    ahrefuserskpd.classList.add("active");

    const url = window.location.origin;

    // SELECT2 VERIFIKASI
    $('#status_usulan').select2({
        placeholder: "Pilih Status",
        ajax: {
            url: url + "/userskpd/apigetstatususulan",
            dataType: 'json',
            delay: 250,
            data: function(data) {
                return {
                    searchTerm: data.term
                };
            },
            processResults: function(data) {
                return {
                    results: data.data
                };
            },
            cache: true
        }
    });

    // SELECT2 STATUS USULAN
    $('#status_usulan_stat').select2({
        placeholder: "Pilih Status",
        ajax: {
            url: url + "/userskpd/apigetstatususulan",
            dataType: 'json',
            delay: 250,
            data: function(data) {
                return {
                    searchTerm: data.term
                };
            },
            processResults: function(data) {
                return {
                    results: data.data
                };
            },
            cache: true
        }
    });
</script>

<!-- SCRIPT MODAL VERIFIKASI -->
<script>
    function showdetail(id) {
        const url = window.location.origin;

        const formData = {
            id_data: id,
        };

        $.ajax({
            type: "POST",
            url: url + "/userskpd/apigetusulan",
            data: formData,
            dataType: "json",
            headers: {
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Methods": "POST"
            },
        }).done(function(data) {
            document.getElementById("id_usulan").value = id;
            document.getElementById("catatan_skpd").value = data.data_usulan[0]['catatan_skpd'];
            document.getElementById("status_usulan").innerHTML = "<option>" + data.data_usulan[0]['status_usulan'] + "</option>";
        });
        $('#modal-isian-edit').modal('show');
    }
</script>

<!-- SCRIPT MODAL STATUS -->
<script>
    function showdetailstatus(id) {
        const url = window.location.origin;

        const formData = {
            id_data: id,
        };

        $.ajax({
            type: "POST",
            url: url + "/userskpd/apigetusulanstatus",
            data: formData,
            dataType: "json",
            headers: {
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Methods": "POST"
            },
        }).done(function(data) {
            document.getElementById("id_usulan_indeks").value = id;
            document.getElementById("keterangan").value = data.data_usulan[0]['keterangan'];
            document.getElementById("indeks_keleng").value = data.data_usulan[0]['indeks_kelengkapan'];
            document.getElementById("status_usulan_stat").innerHTML = "<option>" + data.data_usulan[0]['status_usulan'] + "</option>";
        });
        $('#modal-isian-status').modal('show');
    }
</script>

<script>
    //Get the button
    const mybutton = document.getElementById("btn-back-to-top");

    // When the user scrolls down 20px from the top of the document, show the button
    window.onscroll = function() {
        scrollFunction();
    };

    function scrollFunction() {
        if (
            document.body.scrollTop > 20 ||
            document.documentElement.scrollTop > 20
        ) {
            mybutton.style.display = "block";
        } else {
            mybutton.style.display = "none";
        }
    }
    // When the user clicks on the button, scroll to the top of the document
    mybutton.addEventListener("click", backToTop);

    function backToTop() {
        document.body.scrollTop = 0;
        document.documentElement.scrollTop = 0;
    }
</script>

<?php if (session()->getFlashdata('pesan') == 'updatecatatanskpd') : ?>
    <script>
        $(function() {
            const Toast = Swal.mixin({
                toast: true,
                position: 'top-end',
                showConfirmButton: false,
                timer: 3000
            });
            Toast.fire({
                icon: 'success',
                title: 'berhasil memverifikasi usulan'
            });
        });
    </script>
<?php endif; ?>

<?= $this->endSection(); ?>