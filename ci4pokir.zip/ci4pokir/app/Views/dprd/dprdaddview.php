<?= $this->extend('layouts/template'); ?>

<?= $this->section('content'); ?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Tambah Usulan</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="#">Tambah</a></li>
                        <li class="breadcrumb-item active">Tambah Usulan</li>
                    </ol>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>
    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <!-- SELECT2 EXAMPLE -->
            <div class="card card-default">
                <div class="card-header">
                    <h3 class="card-title">Tambah Usulan DPRD</h3>

                    <div class="card-tools">
                        <button type="button" class="btn btn-tool" data-card-widget="collapse">
                            <i class="fas fa-minus"></i>
                        </button>
                        <!-- <button type="button" class="btn btn-tool" data-card-widget="remove">
                            <i class="fas fa-times"></i>
                        </button> -->
                    </div>
                </div>
                <!-- /.card-header -->
                <form action="/userdprd/saveaddusulan" method="post" enctype="multipart/form-data">
                    <?= csrf_field(); ?>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-12">

                                <div class="form-group">
                                    <label>Usulan</label>
                                    <input type="text" class="form-control" name="usulan_dprd" id="usulan_dprd" placeholder="Isi Usulan Anda..." value="" required>
                                </div>

                                <div class="form-group">
                                    <label>Alamat</label>
                                    <input type="text" class="form-control" name="alamat_usulan_dprd" id="alamat_usulan_dprd" placeholder="Isi Alamat Usulan Anda..." value="" required>
                                </div>

                                <div class="form-group">
                                    <label>Volume</label>
                                    <input type="text" class="form-control" name="volume_usulan_dprd" id="volume_usulan_dprd" placeholder="Isi Volume Usulan Anda..." value="" required>
                                </div>

                                <div class="form-group">
                                    <label>Pagu</label>
                                    <input type="text" class="form-control" name="pagu_usulan_dprd" id="pagu_usulan_dprd" placeholder="Isi Pagu Usulan Anda..." value="" onkeyup="formatinput()" required>
                                </div>

                                <div class="form-group">
                                    <label>Keterangan</label>
                                    <input type="text" class="form-control" name="keterangan_usulan_dprd" id="keterangan_usulan_dprd" placeholder="Isi Ketarangan Usulan Anda..." value="" required>
                                </div>

                                <div class="form-group">
                                    <label>SKPD</label>
                                    <select class="form-control select2 selectskpd" name="skpdselect" id="skpdselect" style="width: 100%;" required>
                                        <option value=""></option>
                                    </select>
                                </div>

                            </div>
                        </div>
                        <!-- /.row -->
                    </div>
                    <div class="card-footer">
                        <button type="submit" class="btn btn-primary"><i class="fa fa-plus-circle"></i> Tambah</button>
                    </div>
                </form>
                <div class="card-footer">
                    <a href="/userdprd"><button type="button" class="btn btn-success"><i class="fas fa-arrow-circle-left"></i> Kembali</button></a>
                </div>
                <!-- /.card-body -->
            </div>
            <!-- /.card -->
        </div>
        <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
</div>
<!-- /.content-wrapper -->
<?= $this->endSection(); ?>

<?= $this->section('javascriptkhusus'); ?>
<script>
    const lidprd = document.querySelector('.li-dprd');
    const ahrefdprd = document.querySelector('.ahref-dprd');
    const ahrefuserdprd = document.querySelector('.ahref-user-dprd');

    lidprd.classList.add("menu-open");
    ahrefdprd.classList.add("active");
    ahrefuserdprd.classList.add("active");

    const url = window.location.origin;

    $('#skpdselect').select2({
        placeholder: "Pilih SKPD",
        ajax: {
            url: url + "/userdprd/apigetskpd",
            dataType: 'json',
            delay: 250,
            data: function(data) {
                return {
                    searchTerm: data.term
                };
            },
            processResults: function(data) {
                return {
                    results: data.data
                };
            },
            cache: true
        }
    });
</script>

<script>
    function formatrupiah(angka, prefix) {
        var number_string = angka.replace(/[^,\d]/g, '').toString(),
            split = number_string.split(','),
            sisa = split[0].length % 3,
            rupiah = split[0].substr(0, sisa),
            ribuan = split[0].substr(sisa).match(/\d{3}/gi);

        if (ribuan) {
            var separator = sisa ? '.' : '';
            rupiah += separator + ribuan.join('.');
        }

        rupiah = split[1] != undefined ? rupiah + ',' + split[1] : rupiah;
        return prefix == undefined ? rupiah : (rupiah ? 'Rp. ' + rupiah : '');
    }

    function formatinputrupiah() {
        var inputrupiah = document.getElementById('pagu_usulan_dprd');
        inputrupiah.value = formatrupiah(inputrupiah.value, 'Rp. ');
    }

    function formatinput() {
        var inputrupiah = document.getElementById('pagu_usulan_dprd');
        inputrupiah.value = formatrupiah(inputrupiah.value);
    }
</script>
<?= $this->endSection(); ?>