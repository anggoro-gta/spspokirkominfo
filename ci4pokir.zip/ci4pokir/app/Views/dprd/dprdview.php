<?= $this->extend('layouts/template'); ?>

<?= $this->section('content'); ?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">

        <!-- Small boxes (Stat box) -->
        <div class="row">
            <div class="col-lg-3 col-6">
                <!-- small box -->
                <div class="small-box bg-info">
                    <div class="inner">
                        <h3 id="header-calskpd" style="font-size: 2.1vw"><sup style="font-size: 10px">Rp</sup><?= $total; ?></h3>
                        <p>Total</p>
                    </div>
                    <a href="#" class="small-box-footer">Details <i class="fas fa-arrow-circle-right"></i></a>
                </div>
            </div>
            <!-- ./col -->
            <div class="col-lg-3 col-6">
                <!-- small box -->
                <div class="small-box bg-success">
                    <div class="inner">
                        <h3 id="header-calskpd" style="font-size: 2.1vw"><sup style="font-size: 10px">Rp</sup><?= $realisasi; ?></h3>
                        <p>Sudah Realisasi</p>
                    </div>
                    <a href="#" class="small-box-footer">Details <i class="fas fa-arrow-circle-right"></i></a>
                </div>
            </div>
            <!-- ./col -->
            <div class="col-lg-3 col-6">
                <!-- small box -->
                <div class="small-box bg-warning">
                    <div class="inner">
                        <h3 id="header-calskpd" style="font-size: 2.1vw"><sup style="font-size: 10px">Rp</sup><?= $akomodir; ?></h3>
                        <p>Diakomodir</p>
                    </div>
                    <a href="#" class="small-box-footer">Details <i class="fas fa-arrow-circle-right"></i></a>
                </div>
            </div>
            <!-- ./col -->
            <div class="col-lg-3 col-6">
                <!-- small box -->
                <div class="small-box bg-danger">
                    <div class="inner">
                        <h3 id="header-calskpd" style="font-size: 2.1vw"><sup style="font-size: 10px">Rp</sup><?= $tdk_akomodir; ?></h3>
                        <p>Tidak Diakomodir</p>
                    </div>
                    <a href="#" class="small-box-footer">Details <i class="fas fa-arrow-circle-right"></i></a>
                </div>
            </div>
            <!-- ./col -->
        </div>

        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1><?= $usulandprd[0]['pengusul']; ?></h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="#">Data</a></li>
                        <li class="breadcrumb-item active">Pokir</li>
                    </ol>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>
    <!-- Main content -->

    <?php $hitungdprd = count($usulandprd); ?>

    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <!-- <a href="#"><button type="button" class="btn btn-block btn-primary"><i class="fas fa-plus-circle"></i> Tambah Data User</button></a> -->
                    <div class="card">
                        <!-- /.card-header -->
                        <div class="card-header">
                            <?php if ($state_usulan == '1') { ?>
                                <a href="/userdprd/addusulandprd"><button type="submit" class="btn btn-primary"><i class="fa fa-plus-circle"></i> Tambah Usulan DPRD</button></a>
                            <?php } else { ?>
                            <?php } ?>
                        </div>
                        <div class="card-body">
                            <table id="example1" class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Usulan</th>
                                        <th>Alamat</th>
                                        <th>Volume</th>
                                        <th>SKPD</th>
                                        <th>Pagu</th>
                                        <th>Keterangan</th>
                                        <th>note SKPD</th>
                                        <th>Note TA</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php for ($i = 0; $i < $hitungdprd; $i++) : ?>
                                        <tr>
                                            <?php if ($usulandprd[$i]['status_usulan'] == 3) {
                                            ?>
                                                <td bgcolor="red"><?= $i + 1; ?></td>
                                                <td bgcolor="red"><?= $usulandprd[$i]['kegiatan']; ?></td>
                                                <td bgcolor="red"><?= $usulandprd[$i]['alamat']; ?></td>
                                                <td bgcolor="red"><?= $usulandprd[$i]['volume']; ?></td>
                                                <td bgcolor="red"><?= $usulandprd[$i]['skpd']; ?></td>
                                                <td align="right" bgcolor="red"><?= number_format($usulandprd[$i]['nilai']); ?></td>
                                                <td bgcolor="red"><?= $usulandprd[$i]['keterangan']; ?></td>
                                                <td bgcolor="red"><?= $usulandprd[$i]['catatan_skpd']; ?></td>
                                                <td bgcolor="red"><?= $usulandprd[$i]['catatan_tenaga_ahli']; ?></td>
                                                <td bgcolor="red">
                                                    <?php if ($state_usulan == '1') { ?>
                                                        <form action="">
                                                            <a onclick="showdetail('<?= $usulandprd[$i]['id']; ?>')" class="btn btn-info btn-sm" href="#" data-toggle="modal">
                                                                <i class="fas fa-pencil-alt">
                                                                </i>
                                                                Edit
                                                            </a>
                                                        </form>
                                                        <form action="/userdprd/hapususulan" method="post" enctype="multipart/form-data">
                                                            <?= csrf_field(); ?>
                                                            <input type="hidden" name="id_hidden" value="<?= $usulandprd[$i]['id']; ?>">
                                                            <button type="submit" id="button_delete" class="btn btn-danger btn-sm" onclick="return confirm('Apakah anda yakin menghapus data ini?');"><i class="fas fa-trash"></i> Hapus</button>
                                                        </form>
                                                    <?php } else { ?>
                                                    <?php } ?>
                                                </td>
                                            <?php } else if ($usulandprd[$i]['status_usulan'] == 2) { ?>
                                                <td bgcolor="yellow"><?= $i + 1; ?></td>
                                                <td bgcolor="yellow"><?= $usulandprd[$i]['kegiatan']; ?></td>
                                                <td bgcolor="yellow"><?= $usulandprd[$i]['alamat']; ?></td>
                                                <td bgcolor="yellow"><?= $usulandprd[$i]['volume']; ?></td>
                                                <td bgcolor="yellow"><?= $usulandprd[$i]['skpd']; ?></td>
                                                <td align="right" bgcolor="yellow"><?= number_format($usulandprd[$i]['nilai']); ?></td>
                                                <td bgcolor="yellow"><?= $usulandprd[$i]['keterangan']; ?></td>
                                                <td bgcolor="yellow"><?= $usulandprd[$i]['catatan_skpd']; ?></td>
                                                <td bgcolor="yellow"><?= $usulandprd[$i]['catatan_tenaga_ahli']; ?></td>
                                                <td bgcolor="yellow">
                                                    <?php if ($state_usulan == '1') { ?>
                                                        <form action="">
                                                            <a onclick="showdetail('<?= $usulandprd[$i]['id']; ?>')" class="btn btn-info btn-sm" href="#" data-toggle="modal">
                                                                <i class="fas fa-pencil-alt">
                                                                </i>
                                                                Edit
                                                            </a>
                                                        </form>
                                                        <form action="/userdprd/hapususulan" method="post" enctype="multipart/form-data">
                                                            <?= csrf_field(); ?>
                                                            <input type="hidden" name="id_hidden" value="<?= $usulandprd[$i]['id']; ?>">
                                                            <button type="submit" id="button_delete" class="btn btn-danger btn-sm" onclick="return confirm('Apakah anda yakin menghapus data ini?');"><i class="fas fa-trash"></i> Hapus</button>
                                                        </form>
                                                    <?php } else { ?>
                                                    <?php } ?>
                                                </td>
                                            <?php } else if ($usulandprd[$i]['status_usulan'] == 1) { ?>
                                                <td bgcolor="green"><?= $i + 1; ?></td>
                                                <td bgcolor="green"><?= $usulandprd[$i]['kegiatan']; ?></td>
                                                <td bgcolor="green"><?= $usulandprd[$i]['alamat']; ?></td>
                                                <td bgcolor="green"><?= $usulandprd[$i]['volume']; ?></td>
                                                <td bgcolor="green"><?= $usulandprd[$i]['skpd']; ?></td>
                                                <td align="right" bgcolor="green"><?= number_format($usulandprd[$i]['nilai']); ?></td>
                                                <td bgcolor="green"><?= $usulandprd[$i]['keterangan']; ?></td>
                                                <td bgcolor="green"><?= $usulandprd[$i]['catatan_skpd']; ?></td>
                                                <td bgcolor="green"><?= $usulandprd[$i]['catatan_tenaga_ahli']; ?></td>
                                                <td bgcolor="green">
                                                    <?php if ($state_usulan == '1') { ?>
                                                        <form action="">
                                                            <a onclick="showdetail('<?= $usulandprd[$i]['id']; ?>')" class="btn btn-info btn-sm" href="#" data-toggle="modal">
                                                                <i class="fas fa-pencil-alt">
                                                                </i>
                                                                Edit
                                                            </a>
                                                        </form>
                                                        <form action="/userdprd/hapususulan" method="post" enctype="multipart/form-data">
                                                            <?= csrf_field(); ?>
                                                            <input type="hidden" name="id_hidden" value="<?= $usulandprd[$i]['id']; ?>">
                                                            <button type="submit" id="button_delete" class="btn btn-danger btn-sm" onclick="return confirm('Apakah anda yakin menghapus data ini?');"><i class="fas fa-trash"></i> Hapus</button>
                                                        </form>
                                                    <?php } else { ?>
                                                    <?php } ?>
                                                </td>
                                            <?php } else if ($usulandprd[$i]['status_usulan'] == 99) { ?>
                                                <td bgcolor="white"><?= $i + 1; ?></td>
                                                <td bgcolor="white"><?= $usulandprd[$i]['kegiatan']; ?></td>
                                                <td bgcolor="white"><?= $usulandprd[$i]['alamat']; ?></td>
                                                <td bgcolor="white"><?= $usulandprd[$i]['volume']; ?></td>
                                                <td bgcolor="white"><?= $usulandprd[$i]['skpd']; ?></td>
                                                <td align="right" bgcolor="white"><?= number_format($usulandprd[$i]['nilai']); ?></td>
                                                <td bgcolor="white"><?= $usulandprd[$i]['keterangan']; ?></td>
                                                <td bgcolor="white"><?= $usulandprd[$i]['catatan_skpd']; ?></td>
                                                <td bgcolor="white"><?= $usulandprd[$i]['catatan_tenaga_ahli']; ?></td>
                                                <td bgcolor="white">
                                                    <?php if ($state_usulan == '1') { ?>
                                                        <form action="">
                                                            <a onclick="showdetail('<?= $usulandprd[$i]['id']; ?>')" class="btn btn-info btn-sm" href="#" data-toggle="modal">
                                                                <i class="fas fa-pencil-alt">
                                                                </i>
                                                                Edit
                                                            </a>
                                                        </form>
                                                        <form action="/userdprd/hapususulan" method="post" enctype="multipart/form-data">
                                                            <?= csrf_field(); ?>
                                                            <input type="hidden" name="id_hidden" value="<?= $usulandprd[$i]['id']; ?>">
                                                            <button type="submit" id="button_delete" class="btn btn-danger btn-sm" onclick="return confirm('Apakah anda yakin menghapus data ini?');"><i class="fas fa-trash"></i> Hapus</button>
                                                        </form>
                                                    <?php } else { ?>
                                                    <?php } ?>
                                                </td>
                                            <?php } ?>
                                        </tr>
                                    <?php endfor; ?>
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <th>#</th>
                                        <th>Usulan</th>
                                        <th>Alamat</th>
                                        <th>Volume</th>
                                        <th>SKPD</th>
                                        <th>Pagu</th>
                                        <th>Keterangan</th>
                                        <th>note SKPD</th>
                                        <th>Note TA</th>
                                        <th>Aksi</th>
                                    </tr>
                                </tfoot>
                            </table>

                            <div class="card-header">
                                <h3 class="card-title">Information Table</h3>
                            </div>
                            <!-- /.card-header -->
                            <div class="card-body table-responsive p-0">
                                <table class="table table-hover text-nowrap">
                                    <thead>
                                        <tr>
                                            <th>Warna</th>
                                            <th>Keterangan</th>
                                            <th>Total</th>

                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td bgcolor="red" width="5px"></td>
                                            <td>tidak diakomodir</td>
                                            <td align="right"><?= $tdk_akomodir; ?></td>
                                        </tr>
                                        <tr>
                                            <td bgcolor="yellow" width="5px"></td>
                                            <td>diakomodir</td>
                                            <td align="right"><?= $akomodir; ?></td>
                                        </tr>
                                        <tr>
                                            <td bgcolor="green" width="5px"></td>
                                            <td>sudah realisasi</td>
                                            <td align="right"><?= $realisasi; ?></td>
                                        </tr>
                                        <tr>
                                            <td bgcolor="white" width="5px"></td>
                                            <td>Belum ada kejelasan</td>
                                            <td align="right"><?= $tdk_warna; ?></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                            <!-- /.card-body -->

                        </div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                </div>
                <!-- /.col -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
    </section>
    <!-- /.content -->

    <div class="modal fade" id="modal-isian-edit">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Edit Usulan</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>

                <form action="/userdprd/saveeditusulan" method="post" enctype="multipart/form-data">
                    <?= csrf_field(); ?>
                    <div class="card-body">
                        <input type="hidden" class="form-control" id="id_usulan" name="id_usulan" required>
                        <div class="form-group">
                            <label>Usulan</label>
                            <input type="text" class="form-control" id="usulan_dprd" name="usulan_dprd" required>
                        </div>
                        <div class="form-group">
                            <label>Alamat</label>
                            <input type="text" class="form-control" id="alamat_usulan_dprd" name="alamat_usulan_dprd" required>
                        </div>
                        <div class="form-group">
                            <label>Volume</label>
                            <input type="text" class="form-control" id="volume_usulan_dprd" name="volume_usulan_dprd" required>
                        </div>
                        <div class="form-group">
                            <label>pagu</label>
                            <input type="text" class="form-control" id="pagu_usulan_dprd" name="pagu_usulan_dprd" onkeyup="formatinput()" required>
                        </div>
                        <div class="form-group">
                            <label>Catatan Tenaga Ahli</label>
                            <input type="text" class="form-control" id="catatan_ta_usulan_dprd" name="catatan_ta_usulan_dprd" required>
                        </div>
                    </div>
                    <!-- /.card-body -->

                    <div class="modal-footer justify-content-between">
                        <!-- <button type="button" class="btn btn-default" data-dismiss="modal">Close</button> -->
                        <button type="submit" class="btn btn-primary"><i class="fas fa-edit"></i> Ubah</button>
                        <!-- <button type="button" class="btn btn-primary">Save changes</button> -->
                    </div>
                </form>
            </div>
            <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </div>
    <!-- /.modal -->

</div>
<!-- /.content-wrapper -->

<!-- Back to top button -->
<button type="button" class="btn btn-danger btn-floating btn-lg" id="btn-back-to-top">
    <i class="fas fa-arrow-up"></i>
</button>
<?= $this->endSection(); ?>

<?= $this->section('javascriptkhusus'); ?>
<script>
    $(function() {
        $("#example1").DataTable({
            // "lengthChange": true,
            "responsive": true,
            "autoWidth": false,
            "ordering": false,
            "buttons": ["copy", "csv", "excel", "pdf", "print", "colvis"],
            "lengthMenu": [
                [10, 25, 50, -1],
                [10, 25, 50, "All"]
            ]
        }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
    });

    const lidprd = document.querySelector('.li-dprd');
    const ahrefdprd = document.querySelector('.ahref-dprd');
    const ahrefuserdprd = document.querySelector('.ahref-user-dprd');

    lidprd.classList.add("menu-open");
    ahrefdprd.classList.add("active");
    ahrefuserdprd.classList.add("active");
</script>

<script>
    function formatrupiah(angka, prefix) {
        var number_string = angka.replace(/[^,\d]/g, '').toString(),
            split = number_string.split(','),
            sisa = split[0].length % 3,
            rupiah = split[0].substr(0, sisa),
            ribuan = split[0].substr(sisa).match(/\d{3}/gi);

        if (ribuan) {
            var separator = sisa ? '.' : '';
            rupiah += separator + ribuan.join('.');
        }

        rupiah = split[1] != undefined ? rupiah + ',' + split[1] : rupiah;
        return prefix == undefined ? rupiah : (rupiah ? 'Rp. ' + rupiah : '');
    }

    function formatinputrupiah() {
        var inputrupiah = document.getElementById('pagu_usulan_dprd');
        inputrupiah.value = formatrupiah(inputrupiah.value, 'Rp. ');
    }

    function formatinput() {
        var inputrupiah = document.getElementById('pagu_usulan_dprd');
        inputrupiah.value = formatrupiah(inputrupiah.value);
    }
</script>

<script>
    function showdetail(id) {
        const url = window.location.origin;

        const formData = {
            id_data: id,
        };

        $.ajax({
            type: "POST",
            url: url + "/userdprd/apiusulandrpd",
            data: formData,
            dataType: "json",
            headers: {
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Methods": "POST"
            },
        }).done(function(data) {
            document.getElementById("id_usulan").value = id;
            document.getElementById("usulan_dprd").value = data.data_usulan[0]['kegiatan'];
            document.getElementById("alamat_usulan_dprd").value = data.data_usulan[0]['alamat'];
            document.getElementById("volume_usulan_dprd").value = data.data_usulan[0]['volume'];
            document.getElementById("pagu_usulan_dprd").value = data.data_usulan[0]['nilai'];
            document.getElementById("catatan_ta_usulan_dprd").value = data.data_usulan[0]['catatan_tenaga_ahli'];
        });
        $('#modal-isian-edit').modal('show');
    }
</script>

<script>
    //Get the button
    const mybutton = document.getElementById("btn-back-to-top");

    // When the user scrolls down 20px from the top of the document, show the button
    window.onscroll = function() {
        scrollFunction();
    };

    function scrollFunction() {
        if (
            document.body.scrollTop > 20 ||
            document.documentElement.scrollTop > 20
        ) {
            mybutton.style.display = "block";
        } else {
            mybutton.style.display = "none";
        }
    }
    // When the user clicks on the button, scroll to the top of the document
    mybutton.addEventListener("click", backToTop);

    function backToTop() {
        document.body.scrollTop = 0;
        document.documentElement.scrollTop = 0;
    }
</script>

<?php if (session()->getFlashdata('pesan') == 'updateusulandprd') : ?>
    <script>
        $(function() {
            const Toast = Swal.mixin({
                toast: true,
                position: 'top-end',
                showConfirmButton: false,
                timer: 3000
            });
            Toast.fire({
                icon: 'success',
                title: 'Usulan berhasil dirubah'
            });
        });
    </script>
<?php endif; ?>

<?php if (session()->getFlashdata('pesan') == 'addusulandprd') : ?>
    <script>
        $(function() {
            const Toast = Swal.mixin({
                toast: true,
                position: 'top-end',
                showConfirmButton: false,
                timer: 3000
            });
            Toast.fire({
                icon: 'success',
                title: 'Usulan berhasil ditambahkan'
            });
        });
    </script>
<?php endif; ?>

<?php if (session()->getFlashdata('pesan') == 'hapususulandprd') : ?>
    <script>
        $(function() {
            const Toast = Swal.mixin({
                toast: true,
                position: 'top-end',
                showConfirmButton: false,
                timer: 3000
            });
            Toast.fire({
                icon: 'success',
                title: 'Usulan berhasil dihapus'
            });
        });
    </script>
<?php endif; ?>

<?= $this->endSection(); ?>