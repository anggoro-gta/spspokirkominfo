<?= $this->extend('layouts/template'); ?>

<?= $this->section('content'); ?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">

        <!-- Small boxes (Stat box) -->
        <div class="row">
            <div class="col-lg-3 col-6">
                <!-- small box -->
                <div class="small-box bg-info">
                    <div class="inner">
                        <h3 id="header-calskpd" style="font-size: 2.1vw"><sup style="font-size: 10px">Rp</sup><?= $total; ?></h3>
                        <p>Total</p>
                    </div>
                    <a href="#" class="small-box-footer">Details <i class="fas fa-arrow-circle-right"></i></a>
                </div>
            </div>
            <!-- ./col -->
            <div class="col-lg-3 col-6">
                <!-- small box -->
                <div class="small-box bg-success">
                    <div class="inner">
                        <h3 id="header-calskpd" style="font-size: 2.1vw"><sup style="font-size: 10px">Rp</sup><?= $realisasi; ?></h3>
                        <p>Sudah Realisasi</p>
                    </div>
                    <a href="#" class="small-box-footer">Details <i class="fas fa-arrow-circle-right"></i></a>
                </div>
            </div>
            <!-- ./col -->
            <div class="col-lg-3 col-6">
                <!-- small box -->
                <div class="small-box bg-warning">
                    <div class="inner">
                        <h3 id="header-calskpd" style="font-size: 2.1vw"><sup style="font-size: 10px">Rp</sup><?= $akomodir; ?></h3>
                        <p>Diakomodir</p>
                    </div>
                    <a href="#" class="small-box-footer">Details <i class="fas fa-arrow-circle-right"></i></a>
                </div>
            </div>
            <!-- ./col -->
            <div class="col-lg-3 col-6">
                <!-- small box -->
                <div class="small-box bg-danger">
                    <div class="inner">
                        <h3 id="header-calskpd" style="font-size: 2.1vw"><sup style="font-size: 10px">Rp</sup><?= $tdk_akomodir; ?></h3>
                        <p>Tidak Diakomodir</p>
                    </div>
                    <a href="#" class="small-box-footer">Details <i class="fas fa-arrow-circle-right"></i></a>
                </div>
            </div>
            <!-- ./col -->
        </div>

        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1><?= $usulandprd; ?></h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="#">Data</a></li>
                        <li class="breadcrumb-item active">Pokir</li>
                    </ol>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>
    <!-- Main content -->

    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <!-- <a href="#"><button type="button" class="btn btn-block btn-primary"><i class="fas fa-plus-circle"></i> Tambah Data User</button></a> -->
                    <div class="card">
                        <!-- /.card-header -->
                        <div class="card-header">
                            <?php if ($state_usulan == '1') { ?>
                                <a href="/userdprd/addusulandprd"><button type="submit" class="btn btn-primary"><i class="fa fa-plus-circle"></i> Tambah Usulan DPRD</button></a>
                            <?php } else { ?>
                            <?php } ?>
                        </div>
                        <div class="card-body">
                            <table id="example1" class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Usulan</th>
                                        <th>Alamat</th>
                                        <th>Volume</th>
                                        <th>SKPD</th>
                                        <th>Pagu</th>
                                        <th>Fraksi</th>
                                        <th>Keterangan</th>
                                        <th>note SKPD</th>
                                        <th>Note TA</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>

                                <tfoot>
                                    <tr>
                                        <th>#</th>
                                        <th>Usulan</th>
                                        <th>Alamat</th>
                                        <th>Volume</th>
                                        <th>SKPD</th>
                                        <th>Pagu</th>
                                        <th>Fraksi</th>
                                        <th>Keterangan</th>
                                        <th>note SKPD</th>
                                        <th>Note TA</th>
                                        <th>Aksi</th>
                                    </tr>
                                </tfoot>
                            </table>

                            <div class="card-header">
                                <h3 class="card-title">Information Table</h3>
                            </div>
                            <!-- /.card-header -->
                            <div class="card-body table-responsive p-0">
                                <table class="table table-hover text-nowrap">
                                    <thead>
                                        <tr>
                                            <th>Warna</th>
                                            <th>Keterangan</th>
                                            <th>Total</th>

                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td bgcolor="red" width="5px"></td>
                                            <td>tidak diakomodir</td>
                                            <td align="right"><?= $tdk_akomodir; ?></td>
                                        </tr>
                                        <tr>
                                            <td bgcolor="yellow" width="5px"></td>
                                            <td>diakomodir</td>
                                            <td align="right"><?= $akomodir; ?></td>
                                        </tr>
                                        <tr>
                                            <td bgcolor="green" width="5px"></td>
                                            <td>sudah realisasi</td>
                                            <td align="right"><?= $realisasi; ?></td>
                                        </tr>
                                        <tr>
                                            <td bgcolor="white" width="5px"></td>
                                            <td>Belum ada kejelasan</td>
                                            <td align="right"><?= $tdk_warna; ?></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                            <!-- /.card-body -->

                        </div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                </div>
                <!-- /.col -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
    </section>
    <!-- /.content -->

</div>
<!-- /.content-wrapper -->

<!-- Back to top button -->
<button type="button" class="btn btn-danger btn-floating btn-lg" id="btn-back-to-top">
    <i class="fas fa-arrow-up"></i>
</button>
<?= $this->endSection(); ?>

<?= $this->section('javascriptkhusus'); ?>
<script>
    $(function() {
        $("#example1").DataTable({
            // "lengthChange": true,
            "responsive": true,
            "autoWidth": false,
            "ordering": false,
            "buttons": ["copy", "csv", "excel", "pdf", "print", "colvis"],
            "lengthMenu": [
                [10, 25, 50, -1],
                [10, 25, 50, "All"]
            ]
        }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
    });

    const lidprd = document.querySelector('.li-dprd');
    const ahrefdprd = document.querySelector('.ahref-dprd');
    const ahrefuserdprd = document.querySelector('.ahref-user-dprd');

    lidprd.classList.add("menu-open");
    ahrefdprd.classList.add("active");
    ahrefuserdprd.classList.add("active");
</script>

<script>
    //Get the button
    const mybutton = document.getElementById("btn-back-to-top");

    // When the user scrolls down 20px from the top of the document, show the button
    window.onscroll = function() {
        scrollFunction();
    };

    function scrollFunction() {
        if (
            document.body.scrollTop > 20 ||
            document.documentElement.scrollTop > 20
        ) {
            mybutton.style.display = "block";
        } else {
            mybutton.style.display = "none";
        }
    }
    // When the user clicks on the button, scroll to the top of the document
    mybutton.addEventListener("click", backToTop);

    function backToTop() {
        document.body.scrollTop = 0;
        document.documentElement.scrollTop = 0;
    }
</script>

<?= $this->endSection(); ?>