<!-- Navbar -->
<nav class="main-header navbar navbar-expand navbar-white navbar-light">
    <!-- Left navbar links -->
    <ul class="navbar-nav">
        <li class="nav-item">
            <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
        </li>
        <li class="nav-item d-none d-sm-inline-block">
            <?php if (isset($_SESSION['years'])) { ?>
                <a href="#" class="nav-link">Tahun Anggaran <?= $_SESSION['years']; ?></a>
            <?php } else { ?>
                <a href="#" class="nav-link">Home</a>
            <?php } ?>
        </li>
        <!-- <li class="nav-item d-none d-sm-inline-block">
            <a href="#" class="nav-link">Contact</a>
        </li> -->
    </ul>

    <!-- Right navbar links -->
    <ul class="navbar-nav ml-auto">
        <li class="nav-item">
            <a class="nav-link" data-widget="fullscreen" href="#" role="button">
                <i class="fas fa-expand-arrows-alt"></i>
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" data-widget="control-sidebar" data-slide="true" href="#" role="button">
                <i class="fas fa-th-large"></i>
            </a>
        </li>
    </ul>
</nav>
<!-- /.navbar -->

<!-- Main Sidebar Container -->
<aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="#" class="brand-link">
        <img src="<?= base_url(); ?>/assets/dist/img/iconnew.png" alt="AdminLTE Logo" class="brand-image img-circle elevation-3" style="opacity: .8">
        <span class="brand-text font-weight-light">SPSPokir</span>
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
        <!-- Sidebar user (optional) -->
        <div class="user-panel mt-3 pb-3 mb-3 d-flex">
            <div class="image">
                <img src="<?= base_url(); ?>/assets/dist/img/<?= user()->user_image; ?>" class="img-circle elevation-2" alt="User Image">
            </div>
            <div class="info">
                <a href="#" class="d-block"><?= user()->fullname; ?></a>
            </div>
        </div>

        <!-- Sidebar year-->
        <div class="user-panel mt-3 pb-3 mb-3 d-flex">
            <div class="info">
                <?php if (isset($_SESSION['years'])) { ?>
                    <a href="#" class="d-block">Tahun Anggaran <?= $_SESSION['years']; ?></a>
                <?php } else { ?>
                    <a href="#" class="d-block">Home</a>
                <?php } ?>
            </div>
        </div>

        <!-- Sidebar Menu -->
        <nav class="mt-2">
            <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
                <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->
                <li class="nav-item li-dashboard">
                    <a href="#" class="nav-link ahref-dashboard">
                        <i class="nav-icon fas fa-tachometer-alt"></i>
                        <p>
                            Dashboard
                            <i class="right fas fa-angle-left"></i>
                        </p>
                    </a>
                    <ul class="nav nav-treeview">
                        <li class="nav-item">
                            <a href="/home/realindex" class="nav-link ahref-home">
                                <i class="far fa-circle nav-icon"></i>
                                <p>Home</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="/gantipassword" class="nav-link ahref-gantipassword">
                                <i class="far fa-circle nav-icon"></i>
                                <p>Ganti Password</p>
                            </a>
                        </li>
                    </ul>
                </li>
                <?php if (in_groups('admin')) : ?>
                    <li class="nav-item li-datamaster">
                        <a href="#" class="nav-link ahref-datamaster">
                            <i class="nav-icon fas fa-th"></i>
                            <p>
                                Data
                                <i class="fas fa-angle-left right"></i>
                            </p>
                        </a>
                        <ul class="nav nav-treeview">
                            <li class="nav-item">
                                <a href="/home/rekapuser" class="nav-link ahrefuser">
                                    <i class="far fa-circle nav-icon"></i>
                                    <p>User</p>
                                </a>
                            </li>
                        </ul>
                        <ul class="nav nav-treeview">
                            <li class="nav-item">
                                <a href="/rekapskpd" class="nav-link ahref-calculatorskpd">
                                    <i class="far fa-circle nav-icon"></i>
                                    <p>Calculator SKPD</p>
                                </a>
                            </li>
                        </ul>
                        <ul class="nav nav-treeview">
                            <li class="nav-item">
                                <a href="/rekapdprd" class="nav-link ahref-calculatordprd">
                                    <i class="far fa-circle nav-icon"></i>
                                    <p>Calculator DPRD</p>
                                </a>
                            </li>
                        </ul>

                        <ul class="nav nav-treeview">
                            <li class="nav-item">
                                <a href="/rekapusulandprd" class="nav-link ahrefrekapusulan">
                                    <i class="far fa-circle nav-icon"></i>
                                    <p>Rekap Usulan DPRD</p>
                                </a>
                            </li>
                        </ul>

                        <!-- <ul class="nav nav-treeview">
                            <li class="nav-item">
                                <a href="/prkpd" class="nav-link ahrefprkpd">
                                    <i class="far fa-circle nav-icon"></i>
                                    <p>P-RKPD 2024</p>
                                </a>
                            </li>
                        </ul> -->

                        <!-- <ul class="nav nav-treeview">
                            <li class="nav-item">
                                <a href="/stringtonumb" class="nav-link ahref-stringtonumb">
                                    <i class="far fa-circle nav-icon"></i>
                                    <p>String to number</p>
                                </a>
                            </li>
                        </ul> -->
                        <!--
                        <ul class="nav nav-treeview">
                            <li class="nav-item">
                                <a href="/bkkkediri" class="nav-link ahref-bkkkediri">
                                    <i class="far fa-circle nav-icon"></i>
                                    <p>BKK Kediri</p>
                                </a>
                            </li>
                        </ul>-->
                        <!-- <ul class="nav nav-treeview">
                            <li class="nav-item">
                                <a href="/rkpdsubsumber" class="nav-link ahref-rkpd2024">
                                    <i class="far fa-circle nav-icon"></i>
                                    <p>RKPD 2024</p>
                                </a>
                            </li>
                        </ul> -->
                        <!-- <ul class="nav nav-treeview">
                            <li class="nav-item">
                                <a href="/apbdprogkeg" class="nav-link ahref-rekapprogapbd">
                                    <i class="far fa-circle nav-icon"></i>
                                    <p>APBD 2024</p>
                                </a>
                            </li>
                        </ul> -->

                        <!-- <ul class="nav nav-treeview">
                            <li class="nav-item">
                                <a href="/programduaribuduaempat" class="nav-link ahrefprogramduaempat">
                                    <i class="far fa-circle nav-icon"></i>
                                    <p>Program 2024</p>
                                </a>
                            </li>
                        </ul> -->

                        <!--<ul class="nav nav-treeview">
                            <li class="nav-item">
                                <a href="/programrpjmd" class="nav-link ahref-progrpjmd">
                                    <i class="far fa-circle nav-icon"></i>
                                    <p>Program RPJMD</p>
                                </a>
                            </li>
                        </ul> -->

                        <!-- hidden sementara
                        <ul class="nav nav-treeview">
                            <li class="nav-item">
                                <a href="/cetakmusrenprov" class="nav-link ahref-stringtonumb">
                                    <i class="far fa-circle nav-icon"></i>
                                    <p>Cetak musrenbangprov</p>
                                </a>
                            </li>
                        </ul>
                        <ul class="nav nav-treeview">
                            <li class="nav-item">
                                <a href="/cetakmusrennas" class="nav-link ahref-stringtonumb">
                                    <i class="far fa-circle nav-icon"></i>
                                    <p>Cetak musrenbangnas</p>
                                </a>
                            </li>
                        </ul>
                         batas akhir hidden sementara -->


                        <!-- <ul class="nav nav-treeview">
                            <li class="nav-item">
                                <a href="/masterusers" class="nav-link ahref-users">
                                    <i class="far fa-circle nav-icon"></i>
                                    <p>Data Users</p>
                                </a>
                            </li>
                        </ul>
                        <ul class="nav nav-treeview">
                            <li class="nav-item">
                                <a href="/mastervisi" class="nav-link ahref-visi">
                                    <i class="far fa-circle nav-icon"></i>
                                    <p>Visi</p>
                                </a>
                            </li>
                        </ul>
                        <ul class="nav nav-treeview">
                            <li class="nav-item">
                                <a href="/mastermisi" class="nav-link ahref-misi">
                                    <i class="far fa-circle nav-icon"></i>
                                    <p>Misi</p>
                                </a>
                            </li>
                        </ul>
                        <ul class="nav nav-treeview">
                            <li class="nav-item">
                                <a href="/mastertujuan" class="nav-link ahref-tujuan">
                                    <i class="far fa-circle nav-icon"></i>
                                    <p>Tujuan</p>
                                </a>
                            </li>
                        </ul>
                        <ul class="nav nav-treeview">
                            <li class="nav-item">
                                <a href="/mastersasaran" class="nav-link ahref-sasaran">
                                    <i class="far fa-circle nav-icon"></i>
                                    <p>Sasaran</p>
                                </a>
                            </li>
                        </ul> -->
                    </li>

                <?php endif; ?>

                <?php if (in_groups('user-biasa')) : ?>
                <?php endif; ?>

                <?php if (in_groups('user-dprd')) : ?>
                    <li class="nav-item li-dprd">
                        <a href="#" class="nav-link ahref-dprd">
                            <i class="nav-icon fas fa-edit"></i>
                            <p>
                                Usulan
                                <i class="fas fa-angle-left right"></i>
                            </p>
                        </a>
                        <ul class="nav nav-treeview">
                            <li class="nav-item">
                                <a href="/userdprd" class="nav-link ahref-user-dprd">
                                    <i class="far fa-circle nav-icon"></i>
                                    <p>Pokir</p>
                                </a>
                            </li>
                        </ul>
                        <!-- <ul class="nav nav-treeview">
                            <li class="nav-item">
                                <a href="/entrysasaranpd" class="nav-link ahref-entrysaspd">
                                    <i class="far fa-circle nav-icon"></i>
                                    <p>Entri Sasaran PD</p>
                                </a>
                            </li>
                        </ul> -->
                    </li>

                    <li class="nav-item licetak">
                        <a href="#" class="nav-link ahrefcetak">
                            <i class="nav-icon fas fa-print"></i>
                            <p>
                                Cetak
                                <i class="fas fa-angle-left right"></i>
                            </p>
                        </a>
                        <ul class="nav nav-treeview">
                            <li class="nav-item">
                                <a href="/userdprd/cetakindex" class="nav-link ahrefmenucetak">
                                    <i class="far fa-circle nav-icon"></i>
                                    <p>Laporan</p>
                                </a>
                            </li>
                        </ul>
                        <!-- <ul class="nav nav-treeview">
                            <li class="nav-item">
                                <a href="/printsipd" class="nav-link" target="_blank">
                                    <i class="far fa-circle nav-icon"></i>
                                    <p>Print SIPD Scraping</p>
                                </a>
                            </li>
                        </ul>
                        <ul class="nav nav-treeview">
                            <li class="nav-item">
                                <a href="/viewprintpdfsasaranpd" class="nav-link" target="_blank">
                                    <i class="far fa-circle nav-icon"></i>
                                    <p>Print Sasaran PD</p>
                                </a>
                            </li>
                        </ul> -->
                    </li>
                <?php endif; ?>

                <?php if (in_groups('user-skpd')) : ?>
                    <li class="nav-item li-skpd">
                        <a href="#" class="nav-link ahref-skpd">
                            <i class="nav-icon fas fa-edit"></i>
                            <p>
                                Usulan
                                <i class="fas fa-angle-left right"></i>
                            </p>
                        </a>
                        <ul class="nav nav-treeview">
                            <li class="nav-item">
                                <a href="/userskpd" class="nav-link ahref-skpdusul">
                                    <i class="far fa-circle nav-icon"></i>
                                    <p>Pokir</p>
                                </a>
                            </li>
                        </ul>
                    </li>

                    <li class="nav-item li-skpdcetak">
                        <a href="#" class="nav-link ahref-skpdcetak">
                            <i class="nav-icon fas fa-print"></i>
                            <p>
                                Cetak
                                <i class="fas fa-angle-left right"></i>
                            </p>
                        </a>
                        <ul class="nav nav-treeview">
                            <li class="nav-item">
                                <a href="/userskpd/indexcetakskpd" class="nav-link ahref-skpdusulcetak">
                                    <i class="far fa-circle nav-icon"></i>
                                    <p>Laporan</p>
                                </a>
                            </li>
                        </ul>
                    </li>
                <?php endif; ?>

                <!-- <li class="nav-item li-tables">
                    <a href="#" class="nav-link a-href-tables">
                        <i class="nav-icon fas fa-table"></i>
                        <p>
                            Tables
                            <i class="fas fa-angle-left right"></i>
                        </p>
                    </a>
                    <ul class="nav nav-treeview">
                        <li class="nav-item">
                            <a href="/table" class="nav-link a-href-tables">
                                <i class="far fa-circle nav-icon"></i>
                                <p>Tabel</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="/komik" class="nav-link a-href-komik">
                                <i class="far fa-circle nav-icon"></i>
                                <p>Komik</p>
                            </a>
                        </li>
                    </ul>
                </li> -->

                <li class="nav-item">
                    <a href="<?= base_url('logout'); ?>" class="nav-link">
                        <i class="nav-icon fas fa-sign-out-alt"></i>
                        <p>
                            log out
                            <!-- <i class="fas fa-angle-left right"></i> -->
                        </p>
                    </a>
                </li>
            </ul>
        </nav>
        <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
</aside>