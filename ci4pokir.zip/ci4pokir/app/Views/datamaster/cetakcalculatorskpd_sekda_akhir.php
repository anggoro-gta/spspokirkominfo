<style>
    table,
    td,
    th {
        border: 1px solid #333;
    }

    table {
        width: 100%;
        border-collapse: collapse;
    }

    td,
    th {
        padding: 2px;
    }

    th {
        background-color: #CCC;
    }

    h1 {
        text-align: center;
    }

    @page {
        margin: 10px;
    }
</style>

<table>
    <thead>
        <tr>
            <th>Warna</th>
            <th>Status</th>
            <th>Total</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td width="10%" bgcolor="red"></td>
            <td>tidak diakomodir</td>
            <td align="right"><?= $tdkakomodir; ?></td>
        </tr>
        <tr>
            <td width="10%" bgcolor="yellow"></td>
            <td>diakomodir</td>
            <td align="right"><?= $akomodir; ?></td>
        </tr>
        <tr>
            <td width="10%" bgcolor="green"></td>
            <td>sudah realisasi</td>
            <td align="right"><?= $realisasi; ?></td>
        </tr>
        <tr>
            <td width="10%" bgcolor="white"></td>
            <td>belum ada kejelasan</td>
            <td align="right"><?= $tidakwarna; ?></td>
        </tr>
    </tbody>
</table>