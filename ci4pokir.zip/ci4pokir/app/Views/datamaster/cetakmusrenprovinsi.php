<style>
    table,
    td,
    th {
        border: 1px solid #333;
    }

    table {
        width: 100%;
        border-collapse: collapse;
    }

    td,
    th {
        padding: 2px;
    }

    th {
        background-color: #CCC;
    }

    h1 {
        text-align: center;
    }

    @page {
        margin: 10px;
    }
</style>

<h1>Usulan Kabupaten Kediri dalam rangka Musrenbang Provinsi Jawa Timur</h1>

<br>
<br>

<table>
    <thead>
        <tr>
            <th>No</th>
            <th>id usulan</th>
            <th>tanggal_usul</th>
            <th>usulan</th>
            <th>alamat</th>
            <th>usulan ke</th>
            <th>OPD Provinsi</th>
        </tr>
    </thead>
    <tbody>
        <?php $hitung =  count($alldatamusrenprov); ?>
        <?php for ($i = 0; $i < $hitung; $i++) : ?>
            <tr>
                <td><?= $i + 1; ?></td>
                <td><?= $alldatamusrenprov[$i]['id_usulan']; ?></td>
                <td><?= $alldatamusrenprov[$i]['tanggal_usul']; ?></td>
                <td><?= $alldatamusrenprov[$i]['masalah']; ?></td>
                <td><?= $alldatamusrenprov[$i]['alamat_lokasi']; ?></td>
                <td><?= $alldatamusrenprov[$i]['usulan_ke']; ?></td>
                <td><?= $alldatamusrenprov[$i]['opd_tujuan_awal']; ?></td>
            </tr>
        <?php endfor; ?>
        <tr>
            <td colspan="7" align="right"><b>Printed from sipd-ri.kemendagri.go.id</b></td>
        </tr>
    </tbody>
</table>