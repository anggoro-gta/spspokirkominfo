<style>
    table,
    td,
    th {
        border: 1px solid #333;
    }

    table {
        width: 100%;
        border-collapse: collapse;
    }

    td,
    th {
        padding: 2px;
    }

    th {
        background-color: #CCC;
    }

    h1 {
        text-align: center;
    }

    @page {
        margin: 10px;
    }
</style>

<h2 align="center"><?= $dataallskpd[0]['skpd']; ?></h2>
<h2 align="center">Tahun Anggaran <?= $_SESSION['years']; ?></h2>

<br>
<br>

<table>
    <thead>
        <tr>
            <th>No</th>
            <th>kegiatan</th>
            <th>alamat</th>
            <th>volume</th>
            <th>nilai</th>
            <th>pengusul</th>
            <th>fraksi</th>
            <th>keterangan</th>
            <th>Note TA</th>
        </tr>
    </thead>
    <tbody>
        <?php $hitung =  count($dataallskpd); ?>
        <?php for ($i = 0; $i < $hitung; $i++) : ?>
            <tr>
                <?php if ($dataallskpd[$i]['status_usulan'] == 3) {
                ?>
                    <td bgcolor="red"><?= $i + 1; ?></td>
                    <td bgcolor="red"><?= $dataallskpd[$i]['kegiatan']; ?></td>
                    <td bgcolor="red"><?= $dataallskpd[$i]['alamat']; ?></td>
                    <td bgcolor="red"><?= $dataallskpd[$i]['volume']; ?></td>
                    <td bgcolor="red" align="right"><?= number_format($dataallskpd[$i]['nilai'], 0, ",", "."); ?></td>
                    <td bgcolor="red"><?= $dataallskpd[$i]['pengusul']; ?></td>
                    <td bgcolor="red"><?= $dataallskpd[$i]['fraksi']; ?></td>
                    <td bgcolor="red"><?= $dataallskpd[$i]['keterangan']; ?></td>
                    <td bgcolor="red"><?= $dataallskpd[$i]['catatan_tenaga_ahli']; ?></td>
                <?php } else if ($dataallskpd[$i]['status_usulan'] == 2) { ?>
                    <td bgcolor="yellow"><?= $i + 1; ?></td>
                    <td bgcolor="yellow"><?= $dataallskpd[$i]['kegiatan']; ?></td>
                    <td bgcolor="yellow"><?= $dataallskpd[$i]['alamat']; ?></td>
                    <td bgcolor="yellow"><?= $dataallskpd[$i]['volume']; ?></td>
                    <td bgcolor="yellow" align="right"><?= number_format($dataallskpd[$i]['nilai'], 0, ",", "."); ?></td>
                    <td bgcolor="yellow"><?= $dataallskpd[$i]['pengusul']; ?></td>
                    <td bgcolor="yellow"><?= $dataallskpd[$i]['fraksi']; ?></td>
                    <td bgcolor="yellow"><?= $dataallskpd[$i]['keterangan']; ?></td>
                    <td bgcolor="yellow"><?= $dataallskpd[$i]['catatan_tenaga_ahli']; ?></td>
                <?php } else if ($dataallskpd[$i]['status_usulan'] == 1) { ?>
                    <td bgcolor="green"><?= $i + 1; ?></td>
                    <td bgcolor="green"><?= $dataallskpd[$i]['kegiatan']; ?></td>
                    <td bgcolor="green"><?= $dataallskpd[$i]['alamat']; ?></td>
                    <td bgcolor="green"><?= $dataallskpd[$i]['volume']; ?></td>
                    <td bgcolor="green" align="right"><?= number_format($dataallskpd[$i]['nilai'], 0, ",", "."); ?></td>
                    <td bgcolor="green"><?= $dataallskpd[$i]['pengusul']; ?></td>
                    <td bgcolor="green"><?= $dataallskpd[$i]['fraksi']; ?></td>
                    <td bgcolor="green"><?= $dataallskpd[$i]['keterangan']; ?></td>
                    <td bgcolor="green"><?= $dataallskpd[$i]['catatan_tenaga_ahli']; ?></td>
                <?php } else if ($dataallskpd[$i]['status_usulan'] == 99) { ?>
                    <td bgcolor="white"><?= $i + 1; ?></td>
                    <td bgcolor="white"><?= $dataallskpd[$i]['kegiatan']; ?></td>
                    <td bgcolor="white"><?= $dataallskpd[$i]['alamat']; ?></td>
                    <td bgcolor="white"><?= $dataallskpd[$i]['volume']; ?></td>
                    <td bgcolor="white" align="right"><?= number_format($dataallskpd[$i]['nilai'], 0, ",", "."); ?></td>
                    <td bgcolor="white"><?= $dataallskpd[$i]['pengusul']; ?></td>
                    <td bgcolor="white"><?= $dataallskpd[$i]['fraksi']; ?></td>
                    <td bgcolor="white"><?= $dataallskpd[$i]['keterangan']; ?></td>
                    <td bgcolor="white"><?= $dataallskpd[$i]['catatan_tenaga_ahli']; ?></td>
                <?php } ?>
            </tr>
        <?php endfor; ?>
        <tr>
            <td colspan="4" align="right"><b>Total</b></td>
            <td align="right"><b><?= number_format($sumskpd, 0, ",", "."); ?></b></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
        </tr>
    </tbody>
</table>

<br>
<br>

<table>
    <thead>
        <tr>
            <th>Warna</th>
            <th>Status</th>
            <th>Total</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td width="10%" bgcolor="red"></td>
            <td>tidak diakomodir</td>
            <td align="right"><?= $tdkakomodir; ?></td>
        </tr>
        <tr>
            <td width="10%" bgcolor="yellow"></td>
            <td>diakomodir</td>
            <td align="right"><?= $akomodir; ?></td>
        </tr>
        <tr>
            <td width="10%" bgcolor="green"></td>
            <td>sudah realisasi</td>
            <td align="right"><?= $realisasi; ?></td>
        </tr>
        <tr>
            <td width="10%" bgcolor="white"></td>
            <td>belum ada kejelasan</td>
            <td align="right"><?= $tidakwarna; ?></td>
        </tr>
    </tbody>
</table>