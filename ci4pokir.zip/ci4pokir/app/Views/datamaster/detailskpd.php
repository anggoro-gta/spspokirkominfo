<?= $this->extend('layouts/template'); ?>

<?= $this->section('content'); ?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">

        <!-- Small boxes (Stat box) -->
        <div class="row">
            <div class="col-lg-3 col-6">
                <!-- small box -->
                <div class="small-box bg-info">
                    <div class="inner">
                        <h3 id="header-calskpd" style="font-size: 2.1vw"><sup style="font-size: 10px">Rp</sup><?= $jumlahskpd; ?></h3>

                        <p>Total</p>
                    </div>
                    <a href="#" class="small-box-footer">Details <i class="fas fa-arrow-circle-right"></i></a>
                </div>
            </div>
            <!-- ./col -->
            <div class="col-lg-3 col-6">
                <!-- small box -->
                <div class="small-box bg-success">
                    <div class="inner">
                        <h3 id="header-calskpd" style="font-size: 2.1vw"><sup style="font-size: 10px">Rp</sup><?= $realisasi; ?></h3>

                        <p>Sudah Realisasi</p>
                    </div>
                    <a href="#" class="small-box-footer">Details <i class="fas fa-arrow-circle-right"></i></a>
                </div>
            </div>
            <!-- ./col -->
            <div class="col-lg-3 col-6">
                <!-- small box -->
                <div class="small-box bg-warning">
                    <div class="inner">
                        <h3 id="header-calskpd" style="font-size: 2.1vw"><sup style="font-size: 10px">Rp</sup><?= $akomodir; ?></h3>

                        <p>Diakomodir</p>
                    </div>
                    <a href="#" class="small-box-footer">Details <i class="fas fa-arrow-circle-right"></i></a>
                </div>
            </div>
            <!-- ./col -->
            <div class="col-lg-3 col-6">
                <!-- small box -->
                <div class="small-box bg-danger">
                    <div class="inner">
                        <h3 id="header-calskpd" style="font-size: 2.1vw"><sup style="font-size: 10px">Rp</sup><?= $tdkakomodir; ?></h3>

                        <p>Tidak Diakomodir</p>
                    </div>
                    <a href="#" class="small-box-footer">Details <i class="fas fa-arrow-circle-right"></i></a>
                </div>
            </div>
            <!-- ./col -->
        </div>

        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1><?= $resultdetailskpd[0]['skpd']; ?></h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="#">Data</a></li>
                        <li class="breadcrumb-item active">Calculator SKPD</li>
                    </ol>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>
    <!-- Main content -->

    <?php $hitungskpd = count($resultdetailskpd); ?>

    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <!-- <a href="#"><button type="button" class="btn btn-block btn-primary"><i class="fas fa-plus-circle"></i> Tambah Data User</button></a> -->
                    <div class="card">
                        <!-- /.card-header -->
                        <div class="card-body">
                            <table id="example1" class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>id usulan</th>
                                        <th>Kegiatan</th>
                                        <th>Alamat</th>
                                        <th>Volume</th>
                                        <th>Nilai</th>
                                        <th>Pengusul</th>
                                        <th>SKPD</th>
                                        <th>tahun</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php for ($i = 0; $i < $hitungskpd; $i++) : ?>
                                        <tr>
                                            <?php if ($resultdetailskpd[$i]['status_usulan'] == 3) {
                                            ?>
                                                <td bgcolor="red"><?= $i + 1; ?></td>
                                                <td bgcolor="red"><?= $resultdetailskpd[$i]['id_usulan']; ?></td>
                                                <td bgcolor="red"><?= $resultdetailskpd[$i]['kegiatan']; ?></td>
                                                <td bgcolor="red"><?= $resultdetailskpd[$i]['alamat']; ?></td>
                                                <td bgcolor="red"><?= $resultdetailskpd[$i]['volume']; ?></td>
                                                <td align="right" bgcolor="red"><?= number_format($resultdetailskpd[$i]['nilai']); ?></td>
                                                <td bgcolor="red"><?= $resultdetailskpd[$i]['pengusul']; ?></td>
                                                <td bgcolor="red"><?= $resultdetailskpd[$i]['skpd']; ?></td>
                                                <td bgcolor="red"><?= $resultdetailskpd[$i]['tahun_anggaran']; ?></td>
                                            <?php } else if ($resultdetailskpd[$i]['status_usulan'] == 2) { ?>
                                                <td bgcolor="yellow"><?= $i + 1; ?></td>
                                                <td bgcolor="yellow"><?= $resultdetailskpd[$i]['id_usulan']; ?></td>
                                                <td bgcolor="yellow"><?= $resultdetailskpd[$i]['kegiatan']; ?></td>
                                                <td bgcolor="yellow"><?= $resultdetailskpd[$i]['alamat']; ?></td>
                                                <td bgcolor="yellow"><?= $resultdetailskpd[$i]['volume']; ?></td>
                                                <td align="right" bgcolor="yellow"><?= number_format($resultdetailskpd[$i]['nilai']); ?></td>
                                                <td bgcolor="yellow"><?= $resultdetailskpd[$i]['pengusul']; ?></td>
                                                <td bgcolor="yellow"><?= $resultdetailskpd[$i]['skpd']; ?></td>
                                                <td bgcolor="yellow"><?= $resultdetailskpd[$i]['tahun_anggaran']; ?></td>
                                            <?php } else if ($resultdetailskpd[$i]['status_usulan'] == 1) { ?>
                                                <td bgcolor="green"><?= $i + 1; ?></td>
                                                <td bgcolor="green"><?= $resultdetailskpd[$i]['id_usulan']; ?></td>
                                                <td bgcolor="green"><?= $resultdetailskpd[$i]['kegiatan']; ?></td>
                                                <td bgcolor="green"><?= $resultdetailskpd[$i]['alamat']; ?></td>
                                                <td bgcolor="green"><?= $resultdetailskpd[$i]['volume']; ?></td>
                                                <td align="right" bgcolor="green"><?= number_format($resultdetailskpd[$i]['nilai']); ?></td>
                                                <td bgcolor="green"><?= $resultdetailskpd[$i]['pengusul']; ?></td>
                                                <td bgcolor="green"><?= $resultdetailskpd[$i]['skpd']; ?></td>
                                                <td bgcolor="green"><?= $resultdetailskpd[$i]['tahun_anggaran']; ?></td>
                                            <?php } else if ($resultdetailskpd[$i]['status_usulan'] == 99) { ?>
                                                <td bgcolor="white"><?= $i + 1; ?></td>
                                                <td bgcolor="white"><?= $resultdetailskpd[$i]['id_usulan']; ?></td>
                                                <td bgcolor="white"><?= $resultdetailskpd[$i]['kegiatan']; ?></td>
                                                <td bgcolor="white"><?= $resultdetailskpd[$i]['alamat']; ?></td>
                                                <td bgcolor="white"><?= $resultdetailskpd[$i]['volume']; ?></td>
                                                <td align="right" bgcolor="white"><?= number_format($resultdetailskpd[$i]['nilai']); ?></td>
                                                <td bgcolor="white"><?= $resultdetailskpd[$i]['pengusul']; ?></td>
                                                <td bgcolor="white"><?= $resultdetailskpd[$i]['skpd']; ?></td>
                                                <td bgcolor="white"><?= $resultdetailskpd[$i]['tahun_anggaran']; ?></td>
                                            <?php } ?>
                                        </tr>
                                    <?php endfor; ?>
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <th>#</th>
                                        <th>id usulan</th>
                                        <th>Kegiatan</th>
                                        <th>Alamat</th>
                                        <th>Volume</th>
                                        <th>Nilai</th>
                                        <th>Pengusul</th>
                                        <th>SKPD</th>
                                        <th>tahun</th>
                                    </tr>
                                </tfoot>
                            </table>

                            <div class="card-header">
                                <h3 class="card-title">Information Table</h3>
                            </div>
                            <!-- /.card-header -->
                            <div class="card-body table-responsive p-0">
                                <table class="table table-hover text-nowrap">
                                    <thead>
                                        <tr>
                                            <th>Warna</th>
                                            <th>Keterangan</th>
                                            <th>Total</th>

                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td bgcolor="red" width="5px"></td>
                                            <td>tidak diakomodir</td>
                                            <td align="right"><?= $tdkakomodir; ?></td>
                                        </tr>
                                        <tr>
                                            <td bgcolor="yellow" width="5px"></td>
                                            <td>diakomodir</td>
                                            <td align="right"><?= $akomodir; ?></td>
                                        </tr>
                                        <tr>
                                            <td bgcolor="green" width="5px"></td>
                                            <td>sudah realisasi</td>
                                            <td align="right"><?= $realisasi; ?></td>
                                        </tr>
                                        <tr>
                                            <td bgcolor="white" width="5px"></td>
                                            <td>Belum ada kejelasan</td>
                                            <td align="right"><?= $tdkwarna; ?></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                            <!-- /.card-body -->

                        </div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                </div>
                <!-- /.col -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
    </section>
    <!-- /.content -->

</div>
<!-- /.content-wrapper -->

<!-- Back to top button -->
<button type="button" class="btn btn-danger btn-floating btn-lg" id="btn-back-to-top">
    <i class="fas fa-arrow-up"></i>
</button>
<?= $this->endSection(); ?>

<?= $this->section('javascriptkhusus'); ?>
<script>
    $(function() {
        $("#example1").DataTable({
            // "lengthChange": true,
            "responsive": true,
            "autoWidth": false,
            "ordering": false,
            "buttons": ["copy", "csv", "excel", "pdf", "print", "colvis"],
            "lengthMenu": [
                [10, 25, 50, -1],
                [10, 25, 50, "All"]
            ]
        }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
    });

    const lidatamaster = document.querySelector('.li-datamaster');
    const ahrefdatamaster = document.querySelector('.ahref-datamaster');
    const ahrefcalculatorskpd = document.querySelector('.ahref-calculatorskpd');

    lidatamaster.classList.add("menu-open");
    ahrefdatamaster.classList.add("active");
    ahrefcalculatorskpd.classList.add("active");
</script>

<script>
    //Get the button
    const mybutton = document.getElementById("btn-back-to-top");

    // When the user scrolls down 20px from the top of the document, show the button
    window.onscroll = function() {
        scrollFunction();
    };

    function scrollFunction() {
        if (
            document.body.scrollTop > 20 ||
            document.documentElement.scrollTop > 20
        ) {
            mybutton.style.display = "block";
        } else {
            mybutton.style.display = "none";
        }
    }
    // When the user clicks on the button, scroll to the top of the document
    mybutton.addEventListener("click", backToTop);

    function backToTop() {
        document.body.scrollTop = 0;
        document.documentElement.scrollTop = 0;
    }
</script>
<?= $this->endSection(); ?>