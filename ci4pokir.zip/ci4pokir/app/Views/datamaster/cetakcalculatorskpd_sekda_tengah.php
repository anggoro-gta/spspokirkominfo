<style>
    table,
    td,
    th {
        border: 1px solid #333;
    }

    table {
        width: 100%;
        border-collapse: collapse;
    }

    td,
    th {
        padding: 2px;
    }

    th {
        background-color: #CCC;
    }

    h1 {
        text-align: center;
    }

    @page {
        margin: 10px;
    }
</style>

<table>
    <thead>
        <tr>
            <th>No</th>
            <th>kegiatan</th>
            <th>alamat</th>
            <th>volume</th>
            <th>nilai</th>
            <th>pengusul</th>
            <th>fraksi</th>
            <th>keterangan</th>
            <th>Note TA</th>
            <th>Klasifikasi</th>
        </tr>
    </thead>
    <tbody>
        <?php $hitung =  count($dataallskpd); ?>
        <?php $j = 316; ?>
        <?php for ($i = 0; $i < $hitung; $i++) : ?>
            <?php $j++; ?>
            <tr>
                <?php if ($dataallskpd[$i]['status_usulan'] == 3) {
                ?>
                    <td bgcolor="red"><?= $j; ?></td>
                    <td bgcolor="red"><?= $dataallskpd[$i]['kegiatan']; ?></td>
                    <td bgcolor="red"><?= $dataallskpd[$i]['alamat']; ?></td>
                    <td bgcolor="red"><?= $dataallskpd[$i]['volume']; ?></td>
                    <td bgcolor="red" align="right"><?= number_format($dataallskpd[$i]['nilai'], 0, ",", "."); ?></td>
                    <td bgcolor="red"><?= $dataallskpd[$i]['pengusul']; ?></td>
                    <td bgcolor="red"><?= $dataallskpd[$i]['fraksi']; ?></td>
                    <td bgcolor="red"><?= $dataallskpd[$i]['keterangan']; ?></td>
                    <td bgcolor="red"><?= $dataallskpd[$i]['catatan_tenaga_ahli']; ?></td>
                    <?php if ($dataallskpd[$i]['note_sekda'] == 'perekonomian') { ?>
                        <td bgcolor="red">perekonomian</td>
                    <?php } else { ?>
                        <td bgcolor="red">kesra</td>
                    <?php } ?>
                <?php } else if ($dataallskpd[$i]['status_usulan'] == 2) { ?>
                    <td bgcolor="yellow"><?= $j; ?></td>
                    <td bgcolor="yellow"><?= $dataallskpd[$i]['kegiatan']; ?></td>
                    <td bgcolor="yellow"><?= $dataallskpd[$i]['alamat']; ?></td>
                    <td bgcolor="yellow"><?= $dataallskpd[$i]['volume']; ?></td>
                    <td bgcolor="yellow" align="right"><?= number_format($dataallskpd[$i]['nilai'], 0, ",", "."); ?></td>
                    <td bgcolor="yellow"><?= $dataallskpd[$i]['pengusul']; ?></td>
                    <td bgcolor="yellow"><?= $dataallskpd[$i]['fraksi']; ?></td>
                    <td bgcolor="yellow"><?= $dataallskpd[$i]['keterangan']; ?></td>
                    <td bgcolor="yellow"><?= $dataallskpd[$i]['catatan_tenaga_ahli']; ?></td>
                    <?php if ($dataallskpd[$i]['note_sekda'] == 'perekonomian') { ?>
                        <td bgcolor="yellow">perekonomian</td>
                    <?php } else { ?>
                        <td bgcolor="yellow">kesra</td>
                    <?php } ?>
                <?php } else if ($dataallskpd[$i]['status_usulan'] == 1) { ?>
                    <td bgcolor="green"><?= $j; ?></td>
                    <td bgcolor="green"><?= $dataallskpd[$i]['kegiatan']; ?></td>
                    <td bgcolor="green"><?= $dataallskpd[$i]['alamat']; ?></td>
                    <td bgcolor="green"><?= $dataallskpd[$i]['volume']; ?></td>
                    <td bgcolor="green" align="right"><?= number_format($dataallskpd[$i]['nilai'], 0, ",", "."); ?></td>
                    <td bgcolor="green"><?= $dataallskpd[$i]['pengusul']; ?></td>
                    <td bgcolor="green"><?= $dataallskpd[$i]['fraksi']; ?></td>
                    <td bgcolor="green"><?= $dataallskpd[$i]['keterangan']; ?></td>
                    <td bgcolor="green"><?= $dataallskpd[$i]['catatan_tenaga_ahli']; ?></td>
                    <?php if ($dataallskpd[$i]['note_sekda'] == 'perekonomian') { ?>
                        <td bgcolor="green">perekonomian</td>
                    <?php } else { ?>
                        <td bgcolor="green">kesra</td>
                    <?php } ?>
                <?php } else if ($dataallskpd[$i]['status_usulan'] == 99) { ?>
                    <td bgcolor="white"><?= $j; ?></td>
                    <td bgcolor="white"><?= $dataallskpd[$i]['kegiatan']; ?></td>
                    <td bgcolor="white"><?= $dataallskpd[$i]['alamat']; ?></td>
                    <td bgcolor="white"><?= $dataallskpd[$i]['volume']; ?></td>
                    <td bgcolor="white" align="right"><?= number_format($dataallskpd[$i]['nilai'], 0, ",", "."); ?></td>
                    <td bgcolor="white"><?= $dataallskpd[$i]['pengusul']; ?></td>
                    <td bgcolor="white"><?= $dataallskpd[$i]['fraksi']; ?></td>
                    <td bgcolor="white"><?= $dataallskpd[$i]['keterangan']; ?></td>
                    <td bgcolor="white"><?= $dataallskpd[$i]['catatan_tenaga_ahli']; ?></td>
                    <?php if ($dataallskpd[$i]['note_sekda'] == 'perekonomian') { ?>
                        <td bgcolor="white">perekonomian</td>
                    <?php } else { ?>
                        <td bgcolor="white">kesra</td>
                    <?php } ?>
                <?php } ?>
            </tr>
        <?php endfor; ?>
        <tr>
            <td colspan="4" align="right"><b>Total</b></td>
            <td align="right"><b><?= number_format($sumskpd, 0, ",", "."); ?></b></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
        </tr>
    </tbody>
</table>