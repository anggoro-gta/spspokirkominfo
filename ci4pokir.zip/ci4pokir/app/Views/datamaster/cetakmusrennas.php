<style>
    table,
    td,
    th {
        border: 1px solid #333;
    }

    table {
        width: 100%;
        border-collapse: collapse;
    }

    td,
    th {
        padding: 2px;
    }

    th {
        background-color: #CCC;
    }

    h1 {
        text-align: center;
    }

    @page {
        margin: 10px;
    }
</style>

<h1>Usulan Pembangunan Kab. Kediri Tahun 2024 Sumber Dana APBN</h1>

<br>
<br>

<table>
    <thead>
        <tr>
            <th>No</th>
            <th>nama usulan</th>
            <th>lokasi</th>
            <th>target</th>
            <th>satuan</th>
            <th>nilai</th>
            <th>keterangan</th>
            <th>bidang</th>
        </tr>
    </thead>
    <tbody>
        <?php $hitung =  count($alldatamusrennas); ?>
        <?php for ($i = 0; $i < $hitung; $i++) : ?>
            <tr>
                <td><?= $i + 1; ?></td>
                <td><?= $alldatamusrennas[$i]['nama_usulan']; ?></td>
                <td><?= $alldatamusrennas[$i]['lokasi']; ?></td>
                <td><?= $alldatamusrennas[$i]['target']; ?></td>
                <td><?= $alldatamusrennas[$i]['satuan']; ?></td>
                <td align="right"><?= number_format($alldatamusrennas[$i]['nilai'], 0, ",", "."); ?></td>
                <td><?= $alldatamusrennas[$i]['keterangan']; ?></td>
                <td><?= $alldatamusrennas[$i]['bidang']; ?></td>
            </tr>
        <?php endfor; ?>
        <tr>
            <td colspan="8" align="right"><b>Printed from gta-project</b></td>
        </tr>
    </tbody>
</table>