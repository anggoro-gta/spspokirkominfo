<?php

namespace App\Models;

use CodeIgniter\Model;

class tabelpokirModel extends Model
{
    protected $table = 'tabel_pokir';
    protected $useTimestamps = true;


    public function getalldataperdprd($nama_dprd)
    {
        $db = \Config\Database::connect();
        $builder = $db->table('tabel_pokir');

        $yearsvar = $_SESSION['years'];

        // $builder->select();

        $array = ['pengusul' => $nama_dprd, 'tahun_anggaran' => $yearsvar];
        $builder->where($array);
        $query = $builder->get();

        $total = $query->getResultArray();

        return $total;
    }

    public function getalldataperskpd($nama_skpd)
    {
        $db = \Config\Database::connect();
        $builder = $db->table('tabel_pokir');

        $yearsvar = $_SESSION['years'];

        // $builder->select();

        $array = ['skpd' => $nama_skpd, 'tahun_anggaran' => $yearsvar];
        $builder->where($array);
        $query = $builder->get();

        $total = $query->getResultArray();

        return $total;
    }

    //sementara ada cek per DPRD untuk pokir P-RKPD 2024
    public function getsumperskpd($nama_skpd)
    {
        $db = \Config\Database::connect();
        $yearsvar = $_SESSION['years'];
        $builder = $db->table('tabel_pokir');

        $builder->selectSum('nilai');

        $array = ['skpd' => $nama_skpd, 'tahun_anggaran' => $yearsvar];
        $builder->where($array);
        $query = $builder->get();

        $total = $query->getResultArray();

        $count = count($total);

        $dataresults = 0;
        for ($i = 0; $i < $count; $i++) {
            $dataresults = $total[$i]['nilai'];
        }
        return $dataresults;
    }

    public function getsumperskpdrealisasi($nama_skpd)
    {
        $db = \Config\Database::connect();
        $builder = $db->table('tabel_pokir');

        $yearsvar = $_SESSION['years'];

        $builder->selectSum('nilai');

        $array = ['skpd' => $nama_skpd, 'tahun_anggaran' => $yearsvar, 'status_usulan' => 1];
        $builder->where($array);
        $query = $builder->get();

        $total = $query->getResultArray();

        $count = count($total);

        $dataresults = 0;
        for ($i = 0; $i < $count; $i++) {
            $dataresults = $total[$i]['nilai'];
        }
        return $dataresults;
    }

    public function getsumperskpdakomodir($nama_skpd)
    {
        $db = \Config\Database::connect();
        $builder = $db->table('tabel_pokir');

        $yearsvar = $_SESSION['years'];

        $builder->selectSum('nilai');

        $array = ['skpd' => $nama_skpd, 'tahun_anggaran' => $yearsvar, 'status_usulan' => 2];
        $builder->where($array);
        $query = $builder->get();

        $total = $query->getResultArray();

        $count = count($total);

        $dataresults = 0;
        for ($i = 0; $i < $count; $i++) {
            $dataresults = $total[$i]['nilai'];
        }
        return $dataresults;
    }

    public function getsumperskptdkdakomodir($nama_skpd)
    {
        $db = \Config\Database::connect();
        $builder = $db->table('tabel_pokir');

        $yearsvar = $_SESSION['years'];

        $builder->selectSum('nilai');

        $array = ['skpd' => $nama_skpd, 'tahun_anggaran' => $yearsvar, 'status_usulan' => 3];
        $builder->where($array);
        $query = $builder->get();

        $total = $query->getResultArray();

        $count = count($total);

        $dataresults = 0;
        for ($i = 0; $i < $count; $i++) {
            $dataresults = $total[$i]['nilai'];
        }
        return $dataresults;
    }

    public function getsumskpdtdkwarna($nama_skpd)
    {
        $db = \Config\Database::connect();
        $builder = $db->table('tabel_pokir');

        $yearsvar = $_SESSION['years'];

        $builder->selectSum('nilai');

        $array = ['skpd' => $nama_skpd, 'tahun_anggaran' => $yearsvar, 'status_usulan' => 99];
        $builder->where($array);
        $query = $builder->get();

        $total = $query->getResultArray();

        $count = count($total);

        $dataresults = 0;
        for ($i = 0; $i < $count; $i++) {
            $dataresults = $total[$i]['nilai'];
        }
        return $dataresults;
    }

    public function getsumperdprd($nama_dprd)
    {
        $db = \Config\Database::connect();
        $builder = $db->table('tabel_pokir');

        $yearsvar = $_SESSION['years'];

        $builder->selectSum('nilai');

        $array = ['pengusul' => $nama_dprd, 'tahun_anggaran' => $yearsvar];
        $builder->where($array);
        $query = $builder->get();

        $total = $query->getResultArray();
        // return $query->getResultArray();

        $count = count($total);

        $dataresults = 0;
        for ($i = 0; $i < $count; $i++) {
            $dataresults = $total[$i]['nilai'];
        }
        return $dataresults;
    }

    public function getsumperdprdrealisasi($nama_dprd)
    {
        $db = \Config\Database::connect();
        $builder = $db->table('tabel_pokir');

        $yearsvar = $_SESSION['years'];

        $builder->selectSum('nilai');

        $array = ['pengusul' => $nama_dprd, 'tahun_anggaran' => $yearsvar, 'status_usulan' => 1];
        $builder->where($array);
        $query = $builder->get();

        $total = $query->getResultArray();

        $count = count($total);

        $dataresults = 0;
        for ($i = 0; $i < $count; $i++) {
            $dataresults = $total[$i]['nilai'];
        }
        return $dataresults;
    }

    public function getsumperdprdakomodir($nama_dprd)
    {
        $db = \Config\Database::connect();
        $builder = $db->table('tabel_pokir');

        $yearsvar = $_SESSION['years'];

        $builder->selectSum('nilai');

        $array = ['pengusul' => $nama_dprd, 'tahun_anggaran' => $yearsvar, 'status_usulan' => 2];
        $builder->where($array);
        $query = $builder->get();

        $total = $query->getResultArray();

        $count = count($total);

        $dataresults = 0;
        for ($i = 0; $i < $count; $i++) {
            $dataresults = $total[$i]['nilai'];
        }
        return $dataresults;
    }

    public function getsumperdprdtdkdakomodir($nama_dprd)
    {
        $db = \Config\Database::connect();
        $builder = $db->table('tabel_pokir');

        $yearsvar = $_SESSION['years'];

        $builder->selectSum('nilai');

        $array = ['pengusul' => $nama_dprd, 'tahun_anggaran' => $yearsvar, 'status_usulan' => 3];
        $builder->where($array);
        $query = $builder->get();

        $total = $query->getResultArray();

        $count = count($total);

        $dataresults = 0;
        for ($i = 0; $i < $count; $i++) {
            $dataresults = $total[$i]['nilai'];
        }
        return $dataresults;
    }

    public function getsumdprdtdkwarna($nama_dprd)
    {
        $db = \Config\Database::connect();
        $builder = $db->table('tabel_pokir');

        $yearsvar = $_SESSION['years'];

        $builder->selectSum('nilai');

        $array = ['pengusul' => $nama_dprd, 'tahun_anggaran' => $yearsvar, 'status_usulan' => 99];
        $builder->where($array);
        $query = $builder->get();

        $total = $query->getResultArray();

        $count = count($total);

        $dataresults = 0;
        for ($i = 0; $i < $count; $i++) {
            $dataresults = $total[$i]['nilai'];
        }
        return $dataresults;
    }

    public function getsumtotaldprd()
    {
        $db = \Config\Database::connect();
        $builder = $db->table('tabel_pokir');

        $yearsvar = $_SESSION['years'];

        $builder->selectSum('nilai');

        $array = ['tahun_anggaran' => $yearsvar];
        $builder->where($array);
        $query = $builder->get();

        $total = $query->getResultArray();

        $count = count($total);

        $dataresults = 0;
        for ($i = 0; $i < $count; $i++) {
            $dataresults = $total[$i]['nilai'];
        }
        return $dataresults;
    }

    public function getsumtotalskpd()
    {
        $yearsvar = $_SESSION['years'];

        $db = \Config\Database::connect();
        $builder = $db->table('tabel_pokir');

        $builder->selectSum('nilai');

        $array = ['tahun_anggaran' => $yearsvar];
        $builder->where($array);
        $query = $builder->get();

        $total = $query->getResultArray();

        $count = count($total);

        $dataresults = 0;
        for ($i = 0; $i < $count; $i++) {
            $dataresults = $total[$i]['nilai'];
        }
        return $dataresults;
    }

    //update usulan DPRD
    public function updateusulandprd($id, $usulan, $alamat_usulan, $volume_usulan, $pagu_usulan, $catatan_tenaga_ahli)
    {
        date_default_timezone_set('Asia/Jakarta');
        $updatedate = date("Y-m-d H:i:s");
        $db = \Config\Database::connect();
        $builder = $db->table('tabel_pokir');
        $data = [
            'kegiatan'  => $usulan,
            'alamat' => $alamat_usulan,
            'volume' => $volume_usulan,
            'nilai' => $pagu_usulan,
            'update_date' => $updatedate,
            'catatan_tenaga_ahli' => $catatan_tenaga_ahli,
        ];

        $builder->where('id', $id);
        $builder->update($data);
    }

    //API get usulan by ID
    public function apigetusulanbyid($id)
    {
        $db = \Config\Database::connect();
        $builder = $db->table('tabel_pokir');

        $yearsvar = $_SESSION['years'];

        // $builder->select();

        $array = ['id' => $id, 'tahun_anggaran' => $yearsvar];
        $builder->where($array);
        $query = $builder->get();

        $total = $query->getResultArray();

        return $total;
    }

    //add usulan DPRD
    public function addusulandprd($kegiatan, $alamat, $volume, $nilai, $skpd, $fraksi, $keterangan)
    {
        date_default_timezone_set('Asia/Jakarta');
        $dateformat = date("Y-m-d H:i:s");
        $yearsvar = $_SESSION['years'];
        $status_usulan = 99;
        $pengusul = user()->fullname;
        $db = \Config\Database::connect();
        $builder = $db->table('tabel_pokir');
        $data = [
            'kegiatan'  => $kegiatan,
            'alamat'  => $alamat,
            'volume' => $volume,
            'nilai'  => $nilai,
            'pengusul' => $pengusul,
            'skpd' => $skpd,
            'fraksi' => $fraksi,
            'tahun_anggaran' => $yearsvar,
            'keterangan' => $keterangan,
            'status_usulan' => $status_usulan,
            'create_date' => $dateformat,
        ];
        $builder->insert($data);
    }

    //detele usulan DPRD
    public function deleteusulandprd($id)
    {
        $db = \Config\Database::connect();
        $builder = $db->table('tabel_pokir');
        $builder->delete(['id' => $id]);
    }

    //update catatan SKPD pada tabel Pokir DPRD
    public function updatecatatanskpd($id, $catatan, $status)
    {
        date_default_timezone_set('Asia/Jakarta');
        $updatedate = date("Y-m-d H:i:s");
        $db = \Config\Database::connect();
        $builder = $db->table('tabel_pokir');
        $data = [
            'status_usulan'  => $status,
            'catatan_skpd' => $catatan,
            'update_date' => $updatedate,
        ];

        $builder->where('id', $id);
        $builder->update($data);
    }

    //update catatan SKPD pada tabel Pokir DPRD(indeks kelengkapan)
    public function updatecatatanskpdindeks($id, $keterangan, $indeks_kelengkapan, $status)
    {
        date_default_timezone_set('Asia/Jakarta');
        $updatedate = date("Y-m-d H:i:s");
        $db = \Config\Database::connect();
        $builder = $db->table('tabel_pokir');
        $data = [
            'indeks_kelengkapan' => $indeks_kelengkapan,
            'keterangan'  => $keterangan,
            'status_usulan' => $status,
            'update_date' => $updatedate,
        ];

        $builder->where('id', $id);
        $builder->update($data);
    }

    //API get select sum per tahun anggaran
    public function apigetsumpertahun($tahun_anggaran)
    {
        $db = \Config\Database::connect();
        $builder = $db->table('tabel_pokir');

        $builder->selectSum('nilai');

        $array = ['tahun_anggaran' => $tahun_anggaran];
        $builder->where($array);
        $query = $builder->get();

        $total = $query->getResultArray();

        $count = count($total);

        $dataresults = 0;
        for ($i = 0; $i < $count; $i++) {
            $dataresults = $total[$i]['nilai'];
        }
        return $dataresults;
    }

    //jumlah indeks kelengkapan
    public function getsumindekskelengkapan($nama_skpd)
    {
        $db = \Config\Database::connect();
        $yearsvar = $_SESSION['years'];
        $builder = $db->table('tabel_pokir');

        $builder->selectSum('indeks_kelengkapan');

        $array = ['skpd' => $nama_skpd, 'tahun_anggaran' => $yearsvar];
        $builder->where($array);
        $query = $builder->get();

        $total = $query->getResultArray();

        $count = count($total);

        $dataresults = 0;
        for ($i = 0; $i < $count; $i++) {
            $dataresults = $total[$i]['indeks_kelengkapan'];
        }
        return $dataresults;
    }

    //get total usulan semuanya
    public function gettotalsemuausulan($nama_dprd)
    {
        $db = \Config\Database::connect();
        $yearsvar = $_SESSION['years'];
        $builder = $db->table('tabel_pokir');

        $builder->select('*');

        $array = ['pengusul' => $nama_dprd, 'tahun_anggaran' => $yearsvar];
        $builder->where($array);
        $query = $builder->get();

        $total = $query->getResultArray();

        $count = count($total);

        return $count;
    }

    //get total usulan khusus merah
    public function gettotalusulanmerah($nama_dprd)
    {
        $db = \Config\Database::connect();
        $yearsvar = $_SESSION['years'];
        $warna_merah = 3;
        $builder = $db->table('tabel_pokir');

        $builder->select('*');

        $array = ['pengusul' => $nama_dprd, 'tahun_anggaran' => $yearsvar, 'status_usulan' => $warna_merah];
        $builder->where($array);
        $query = $builder->get();

        $total = $query->getResultArray();

        $count = count($total);

        return $count;
    }

    //get total usulan khusus kuning
    public function gettotalusulankuning($nama_dprd)
    {
        $db = \Config\Database::connect();
        $yearsvar = $_SESSION['years'];
        $warna_merah = 2;
        $builder = $db->table('tabel_pokir');

        $builder->select('*');

        $array = ['pengusul' => $nama_dprd, 'tahun_anggaran' => $yearsvar, 'status_usulan' => $warna_merah];
        $builder->where($array);
        $query = $builder->get();

        $total = $query->getResultArray();

        $count = count($total);

        return $count;
    }

    //get total usulan khusus hijau
    public function gettotalusulanhijau($nama_dprd)
    {
        $db = \Config\Database::connect();
        $yearsvar = $_SESSION['years'];
        $warna_merah = 1;
        $builder = $db->table('tabel_pokir');

        $builder->select('*');

        $array = ['pengusul' => $nama_dprd, 'tahun_anggaran' => $yearsvar, 'status_usulan' => $warna_merah];
        $builder->where($array);
        $query = $builder->get();

        $total = $query->getResultArray();

        $count = count($total);

        return $count;
    }

    //get total usulan khusus putih
    public function gettotalusulanputih($nama_dprd)
    {
        $db = \Config\Database::connect();
        $yearsvar = $_SESSION['years'];
        $warna_merah = 99;
        $builder = $db->table('tabel_pokir');

        $builder->select('*');

        $array = ['pengusul' => $nama_dprd, 'tahun_anggaran' => $yearsvar, 'status_usulan' => $warna_merah];
        $builder->where($array);
        $query = $builder->get();

        $total = $query->getResultArray();

        $count = count($total);

        return $count;
    }
}
