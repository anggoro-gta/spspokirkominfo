<?php

namespace App\Models;

use CodeIgniter\Model;

class mastersubunitskpdModel extends Model
{
    protected $table = 'mastersubunit_rkpd2024_subkeg';
    protected $useTimestamps = true;
    protected $allowedFields = ['nama_sub_unit'];
}
