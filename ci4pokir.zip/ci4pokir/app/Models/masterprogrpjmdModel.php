<?php

namespace App\Models;

use CodeIgniter\Model;

class masterprogrpjmdModel extends Model
{
    protected $table = 'master_program_rpjmd_2021sd2026';
    protected $useTimestamps = true;
    // protected $allowedFields = ['nama_skpd'];

    public function getnamaprogbyid($id)
    {
        $db = \Config\Database::connect();
        $builder = $db->table('master_program_rpjmd_2021sd2026');
        $builder->select('nama_program');
        $array = ['id_program' => $id];
        $builder->where($array);
        $query = $builder->get();

        return $query->getResultArray();
    }
}
