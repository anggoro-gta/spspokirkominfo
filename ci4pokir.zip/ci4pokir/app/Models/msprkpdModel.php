<?php

namespace App\Models;

use CodeIgniter\Model;

class msprkpdModel extends Model
{
    protected $table = 'ms_prkpd';
    protected $useTimestamps = true;

    public function urusan($kode_skpd)
    {
        $db = \Config\Database::connect();
        $builder = $db->table('ms_prkpd');

        $builder->select('DISTINCT(kode_urusan), nama_urusan', false);

        $yearsvar = $_SESSION['years'];

        $array = ['kode_sub_unit' => $kode_skpd, 'tahun' => $yearsvar];
        $builder->where($array);
        $query = $builder->get();

        $total = $query->getResultArray();

        return $total;
    }

    public function bidang_urusan($kode_skpd)
    {
        $db = \Config\Database::connect();
        $builder = $db->table('ms_prkpd');

        $builder->select('DISTINCT(kode_bidang_urusan), nama_bidang_urusan, kode_urusan, nama_urusan', false);

        $yearsvar = $_SESSION['years'];

        $array = ['kode_sub_unit' => $kode_skpd, 'tahun' => $yearsvar];
        $builder->where($array);
        $query = $builder->get();

        $total = $query->getResultArray();

        return $total;
    }

    public function program($kode_skpd)
    {
        $db = \Config\Database::connect();
        $builder = $db->table('ms_prkpd');

        $builder->select('DISTINCT(kode_program), nama_program, kode_bidang_urusan, nama_bidang_urusan, indikator_program, volume_program_sebelum, satuan_program_sebelum', false);

        $yearsvar = $_SESSION['years'];

        $array = ['kode_sub_unit' => $kode_skpd, 'tahun' => $yearsvar];
        $builder->where($array);
        $query = $builder->get();

        $total = $query->getResultArray();

        return $total;
    }

    //menghitung jumlah anggaran dari program tertentu
    public function hitunganggaranprogram($kode_skpd, $kode_program)
    {
    }
}
