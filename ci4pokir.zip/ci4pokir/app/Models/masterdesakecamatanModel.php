<?php

namespace App\Models;

use CodeIgniter\Model;

class masterdesakecamatanModel extends Model
{
    protected $table = 'master_desa_kecamatan';
    protected $useTimestamps = true;
    protected $allowedFields = ['nama_desa', 'nama_kecamatan', 'gabungan'];
}
