<?php

namespace App\Models;

use CodeIgniter\Model;

class stateusulanModel extends Model
{
    protected $table = 'state_usulan';
    protected $useTimestamps = true;
    protected $allowedFields = ['kode', 'tahun_anggaran'];

    public function getstateusulan()
    {
        $yearsvar = $_SESSION['years'];

        $db = \Config\Database::connect();
        $builder = $db->table('state_usulan');

        $builder->select('kode');
        $array = ['tahun_anggaran' => $yearsvar];
        $builder->where($array);

        $query = $builder->get();

        $total = $query->getResultArray();

        $count = count($total);

        $dataresults = 0;
        for ($i = 0; $i < $count; $i++) {
            $dataresults = $total[$i]['kode'];
        }
        return $dataresults;
    }
}
