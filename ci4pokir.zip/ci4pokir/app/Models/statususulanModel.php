<?php

namespace App\Models;

use CodeIgniter\Model;

class statususulanModel extends Model
{
    protected $table = 'status_usulan';
    protected $useTimestamps = true;
    protected $allowedFields = ['status_usulan'];
}
