<?php

namespace App\Models;

use CodeIgniter\Model;

class mastersubkegduaempatModel extends Model
{
    protected $table = 'master_sub_kegiatan_2024';
    protected $useTimestamps = true;
    // protected $allowedFields = ['nama_skpd'];   

    public function addbatchsubkeg($arraydata){        
        $db = \Config\Database::connect();
        $builder = $db->table('master_sub_kegiatan_2024');        
        $builder->insertBatch($arraydata);
    }
}
