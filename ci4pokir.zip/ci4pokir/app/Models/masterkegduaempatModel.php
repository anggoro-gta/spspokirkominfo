<?php

namespace App\Models;

use CodeIgniter\Model;

class masterkegduaempatModel extends Model
{
    protected $table = 'master_kegiatan_2024';
    protected $useTimestamps = true;
    // protected $allowedFields = ['nama_skpd'];   

    public function addbatchkeg($arraydata){        
        $db = \Config\Database::connect();
        $builder = $db->table('master_kegiatan_2024');        
        $builder->insertBatch($arraydata);
    }
}
