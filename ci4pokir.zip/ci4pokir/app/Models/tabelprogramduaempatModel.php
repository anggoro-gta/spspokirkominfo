<?php

namespace App\Models;

use CodeIgniter\Model;

class tabelprogramduaempatModel extends Model
{
    protected $table = 'tabel_program_2024';
    protected $useTimestamps = true;
    // protected $allowedFields = ['tahun', 'kode_urusan', 'kode_skpd', 'nama_skpd', 'kode_sub_unit', 'nama_sub_unit', 'kode_bidang_urusan', 'nama_bidang_urusan', 'kode_program', 'nama_program', 'kode_kegiatan', 'nama_kegiatan', 'kode_sub_kegiatan', 'nama_sub_kegiatan', 'kode_sumber_dana', 'nama_sumber_dana', 'kode_rekening', 'nama_rekening', 'pagu'];

    public function getopddetailkode($kode_prog, $namasubunit)
    {
        $db = \Config\Database::connect();
        $builder = $db->table('tabel_program_2024');

        $builder->select('kode_sub_unit');
        $builder->distinct();

        $array = ['kode_program' => $kode_prog, 'nama_sub_unit' => $namasubunit];
        $builder->where($array);
        $query = $builder->get();

        $total = $query->getResultArray();

        $count = count($total);

        $dataresults = '';
        for ($i = 0; $i < $count; $i++) {
            $dataresults = $total[$i]['kode_sub_unit'];
        }
        return $dataresults;
    }

    public function getopddetailnama($kode_prog, $namasubunit)
    {
        $db = \Config\Database::connect();
        $builder = $db->table('tabel_program_2024');

        $builder->select('nama_sub_unit');
        $builder->distinct();

        $array = ['kode_program' => $kode_prog, 'nama_sub_unit' => $namasubunit];
        $builder->where($array);
        $query = $builder->get();

        $total = $query->getResultArray();

        $count = count($total);

        $dataresults = '';
        for ($i = 0; $i < $count; $i++) {
            $dataresults = $total[$i]['nama_sub_unit'];
        }
        return $dataresults;
    }

    public function getprogramperopd($namasubunit)
    {
        $db = \Config\Database::connect();
        $builder = $db->table('tabel_program_2024');

        $builder->select('kode_program,nama_program');
        $builder->distinct();
        $array = ['nama_sub_unit' => $namasubunit];
        $builder->where($array);
        $query = $builder->get();

        $total = $query->getResultArray();

        return $total;
    }
}
