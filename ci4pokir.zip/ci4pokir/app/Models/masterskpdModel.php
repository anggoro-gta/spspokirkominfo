<?php

namespace App\Models;

use CodeIgniter\Model;

class masterskpdModel extends Model
{
    protected $table = 'master_skpd';
    protected $useTimestamps = true;
    protected $allowedFields = ['kode_skpd', 'nama_skpd'];

    public function getnamaskpd($id)
    {
        $db = \Config\Database::connect();
        $builder = $db->table('master_skpd');

        $builder->select('nama_skpd');

        $array = ['id_skpd' => $id];
        $builder->where($array);
        $query = $builder->get();

        $total = $query->getResultArray();

        $count = count($total);

        $dataresults = 0;
        for ($i = 0; $i < $count; $i++) {
            $dataresults = $total[$i]['nama_skpd'];
        }
        return $dataresults;
    }

    public function getnamaopd($kode_opd)
    {
        $db = \Config\Database::connect();
        $yearsvar = $_SESSION['years'];
        $builder = $db->table('master_skpd');

        $builder->select('nama_skpd');

        $array = ['kode_skpd' => $kode_opd];
        $builder->where($array);
        $query = $builder->get();

        $total = $query->getResultArray();

        $count = count($total);

        $dataresults = "";
        for ($i = 0; $i < $count; $i++) {
            $dataresults = $total[$i]['nama_skpd'];
        }
        return $dataresults;
    }

    // public function getvisiarray($id)
    // {
    //     $db = \Config\Database::connect();
    //     $builder = $db->table('ms_visi');
    //     $builder->select('id_visi, visi');
    //     $array = ['id_visi' => $id];
    //     $builder->where($array);
    //     $query = $builder->get();

    //     return $query->getResultArray();
    // }

    // public function getdata($id)
    // {
    //     $db = \Config\Database::connect();
    //     $builder = $db->table('ms_je');
    //     $builder->select('id, jawaban, status_pdf, location_file');
    //     $array = ['id' => $id];
    //     $builder->where($array);
    //     $query = $builder->get();

    //     return $query->getResultArray();
    // }
}
