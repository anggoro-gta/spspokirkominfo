<?php

namespace App\Models;

use CodeIgniter\Model;

class msmusnasModel extends Model
{
    protected $table = 'master_mus_nas';
    protected $useTimestamps = true;
    protected $allowedFields = ['nama_usulan', 'lokasi', 'target', 'satuan', 'nilai', 'keterangan', 'bidang'];
}
