<?php

namespace App\Models;

use CodeIgniter\Model;

class rkpdsubsumberModel extends Model
{
    protected $table = 'tabel_rkpd2024_subkeg_sumberdana';
    protected $useTimestamps = true;
    protected $allowedFields = ['tahun', 'kode_urusan', 'kode_skpd', 'nama_skpd', 'kode_sub_unit', 'nama_sub_unit', 'kode_bidang_urusan', 'nama_bidang_urusan', 'kode_program', 'nama_program', 'kode_kegiatan', 'nama_kegiatan', 'kode_sub_kegiatan', 'nama_sub_kegiatan', 'kode_sumber_dana', 'nama_sumber_dana', 'kode_rekening', 'nama_rekening', 'pagu'];

    public function getdistinct($namaskpd)
    {
        $db = \Config\Database::connect();
        $builder = $db->table('tabel_rkpd2024_subkeg_sumberdana');

        $builder->select('nama_sumber_dana');
        $builder->distinct();
        $array = ['nama_skpd' => $namaskpd];
        $builder->where($array);
        $query = $builder->get();

        $total = $query->getResultArray();

        return $total;
    }

    public function getdistinctsubunit($namasubunit)
    {
        $db = \Config\Database::connect();
        $builder = $db->table('tabel_rkpd2024_subkeg_sumberdana');

        $builder->select('nama_sumber_dana');
        $builder->distinct();
        $array = ['nama_sub_unit' => $namasubunit];
        $builder->where($array);
        $query = $builder->get();

        $total = $query->getResultArray();

        return $total;
    }

    public function hitungjumlahpaguperskpd($namaskpd, $namasumberdana)
    {
        $db = \Config\Database::connect();
        $builder = $db->table('tabel_rkpd2024_subkeg_sumberdana');

        $builder->selectSum('pagu');

        $array = ['nama_skpd' => $namaskpd, 'nama_sumber_dana' => $namasumberdana];
        $builder->where($array);
        $query = $builder->get();

        $total = $query->getResultArray();

        $count = count($total);

        $dataresults = 0;
        for ($i = 0; $i < $count; $i++) {
            $dataresults = $total[$i]['pagu'];
        }
        return $dataresults;
    }

    public function hitungjumlahpagupersubunit($namasubunit, $namasumberdana)
    {
        $db = \Config\Database::connect();
        $builder = $db->table('tabel_rkpd2024_subkeg_sumberdana');

        $builder->selectSum('pagu');

        $array = ['nama_sub_unit' => $namasubunit, 'nama_sumber_dana' => $namasumberdana];
        $builder->where($array);
        $query = $builder->get();

        $total = $query->getResultArray();

        $count = count($total);

        $dataresults = 0;
        for ($i = 0; $i < $count; $i++) {
            $dataresults = $total[$i]['pagu'];
        }
        return $dataresults;
    }

    public function hitungjumlahpagu($namaskpd)
    {
        $db = \Config\Database::connect();
        $builder = $db->table('tabel_rkpd2024_subkeg_sumberdana');

        $builder->selectSum('pagu');

        $array = ['nama_skpd' => $namaskpd];
        $builder->where($array);
        $query = $builder->get();

        $total = $query->getResultArray();

        $count = count($total);

        $dataresults = 0;
        for ($i = 0; $i < $count; $i++) {
            $dataresults = $total[$i]['pagu'];
        }
        return $dataresults;
    }
}
