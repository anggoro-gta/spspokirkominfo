<?php

namespace App\Models;

use CodeIgniter\Model;

class masterprogramduaempatModel extends Model
{
    protected $table = 'master_program_2024';
    protected $useTimestamps = true;
    // protected $allowedFields = ['nama_skpd'];   

    public function addbatchprog($arraydata){        
        $db = \Config\Database::connect();
        $builder = $db->table('master_program_2024');        
        $builder->insertBatch($arraydata);
    }
}
