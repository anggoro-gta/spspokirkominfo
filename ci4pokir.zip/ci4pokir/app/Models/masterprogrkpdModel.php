<?php

namespace App\Models;

use CodeIgniter\Model;

class masterprogrkpdModel extends Model
{
    protected $table = 'master_program_rkpd_2023';
    protected $useTimestamps = true;
    // protected $allowedFields = ['nama_skpd'];

    public function getdatarkpdbynamaprogram($nama_program)
    {
        $db = \Config\Database::connect();
        $builder = $db->table('master_program_rkpd_2023');
        // $builder->select('nama_program');
        $array = ['nama_program_rkpd' => $nama_program];
        $builder->where($array);
        $query = $builder->get();

        return $query->getResultArray();
    }
}
