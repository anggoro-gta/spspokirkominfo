<?php

namespace App\Models;

use CodeIgniter\Model;

class mastermusModel extends Model
{
    protected $table = 'master_mus';
    protected $useTimestamps = true;

    public function getsumpergabungan($nama_gabungan)
    {
        $db = \Config\Database::connect();
        $builder = $db->table('master_mus');

        $builder->selectSum('anggaran');

        $array = ['gabungan' => $nama_gabungan];
        $builder->where($array);
        $query = $builder->get();

        $total = $query->getResultArray();
        // return $query->getResultArray();

        $count = count($total);

        $dataresults = 0;
        for ($i = 0; $i < $count; $i++) {
            $dataresults = $total[$i]['anggaran'];
        }
        return $dataresults;
    }

    public function getusulan($nama_gabungan)
    {
        $db = \Config\Database::connect();
        $builder = $db->table('master_mus');

        $builder->select('masalah');

        $array = ['gabungan' => $nama_gabungan];
        $builder->where($array);
        $query = $builder->get();

        $total = $query->getResultArray();
        // return $query->getResultArray();

        $count = count($total);

        $dataresults = 0;
        for ($i = 0; $i < $count; $i++) {
            $dataresults = $total[$i]['masalah'];
        }
        return $dataresults;
    }
}
