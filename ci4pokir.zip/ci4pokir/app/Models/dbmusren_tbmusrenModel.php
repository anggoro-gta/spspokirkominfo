<?php

namespace App\Models;

use CodeIgniter\Model;

class dbmusren_tbmusrenModel extends Model
{
    protected $table = 'master_mus';
    protected $useTimestamps = true;
    protected $allowedFields = ['id_usulan', 'tanggal_usul', 'pengusul', 'usulan', 'masalah', 'alamat_lokasi', 'kecamatan', 'kelurahan', 'usulan_ke', 'opd_tujuan_awal', 'opd_tujuan_akhir', 'status', 'catatan', 'rekomendasi_mitra', 'rekomendasi_kelurahan', 'rekomendasi_kecamatan', 'rekomendasi_skpd', 'rekomendasi_tapd'];
}
