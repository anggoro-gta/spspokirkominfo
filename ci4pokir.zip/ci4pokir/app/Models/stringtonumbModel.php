<?php

namespace App\Models;

use CodeIgniter\Model;

class stringtonumbModel extends Model
{
    protected $table = 'tabel_stringtonumber';
    protected $useTimestamps = true;
    protected $allowedFields = ['string', 'nilai'];
}
