<?php

namespace App\Models;

use CodeIgniter\Model;

class masterdprdModel extends Model
{
    protected $table = 'master_dprd';
    protected $useTimestamps = true;
    protected $allowedFields = ['nama_dprd', 'batasan_pagu', 'fraksi', 'keterangan_banggar', 'tahun_anggaran'];

    public function selectallbyyears()
    {
        $db = \Config\Database::connect();
        $builder = $db->table('master_dprd');

        $yearsvar = $_SESSION['years'];

        $builder->select('*');

        $array = ['tahun_anggaran' => $yearsvar];
        $builder->where($array);
        $query = $builder->get();

        $total = $query->getResultArray();

        return $total;
    }

    public function getfrkasidprd($nama_dprd)
    {
        $db = \Config\Database::connect();
        $builder = $db->table('master_dprd');

        $builder->select('fraksi');

        $array = ['nama_dprd' => $nama_dprd];
        $builder->where($array);
        $query = $builder->get();

        $total = $query->getResultArray();

        $count = count($total);

        $dataresults = 0;
        for ($i = 0; $i < $count; $i++) {
            $dataresults = $total[$i]['fraksi'];
        }
        return $dataresults;
    }

    public function getbatasanpagudprd($nama_dprd)
    {
        $year = $_SESSION['years'];

        $db = \Config\Database::connect();
        $builder = $db->table('master_dprd');

        $builder->select('batasan_pagu');

        $array = ['nama_dprd' => $nama_dprd, 'tahun_anggaran' => $year];
        $builder->where($array);
        $query = $builder->get();

        $total = $query->getResultArray();

        $count = count($total);

        $dataresults = 0;
        for ($i = 0; $i < $count; $i++) {
            $dataresults = $total[$i]['batasan_pagu'];
        }
        return $dataresults;
    }

    public function getketbanggardprd($nama_dprd)
    {
        $db = \Config\Database::connect();
        $builder = $db->table('master_dprd');

        $builder->select('keterangan_banggar');

        $array = ['nama_dprd' => $nama_dprd];
        $builder->where($array);
        $query = $builder->get();

        $total = $query->getResultArray();

        $count = count($total);

        $dataresults = 0;
        for ($i = 0; $i < $count; $i++) {
            $dataresults = $total[$i]['keterangan_banggar'];
        }
        return $dataresults;
    }
}
